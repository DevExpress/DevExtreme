# DevExtreme Internal Tools #

![](https://github.com/DevExpress/devextreme-internal-tools/workflows/Tests/badge.svg?branch=dev)

This package contains tools used by the DevExtreme team for development.

# License

**DevExtreme Internal Tools are released as MIT-licensed.**
