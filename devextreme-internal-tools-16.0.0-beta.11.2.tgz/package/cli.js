#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var shelljs_1 = require("shelljs");
var typescript_1 = require("typescript");
var tools_1 = require("./ts/scripts/tools");
var args_1 = require("./ts/scripts/args");
var helpers_1 = require("./ts/scripts/helpers");
var package_json_1 = require("./package.json");
var logging_1 = require("./ts/logging");
var scripts = {
    'discover-declarations': [tools_1.runDiscoverers],
    'make-integration-metadata': [tools_1.runImdGenerator],
    'make-angular-metadata': [tools_1.runNgSmdGenerator],
    'make-aspnet-metadata': [tools_1.runSmdGenerator],
    'make-syntax-metadata': [tools_1.runSyntaxDataGenerator],
    'make-content-map': [tools_1.runContentMapGenerator],
    'make-compact-docs': [tools_1.runCompactDocsCreator],
    'generate-ts-bundle': [tools_1.runDtsBundler],
    'generate-reexports': [tools_1.runReexportsGenerator],
    'generate-topics': [tools_1.runDocGenerator],
    'generate-extra-topics': [tools_1.runExtraTopicsGenerator],
    'inject-descriptions': [tools_1.runInjector],
    'convert-links': [tools_1.runLinksConverter],
    'validate-declarations': [tools_1.runTsDiscoverer, tools_1.runValidator],
    'validate-topics': [tools_1.runTopicsValidation],
    'validate-modules-guide': [tools_1.runModulesGuideValidator],
};
if (process.argv.length < 3) {
    (0, logging_1.log)('Script is not specified', { lvl: 'error' });
    (0, shelljs_1.exit)(1);
}
var scriptName = process.argv[2];
if (scriptName === '-v') {
    console.log(package_json_1.version);
    (0, shelljs_1.exit)(0);
}
var allArgs = (0, args_1.parseArgs)(process.argv);
(0, logging_1.setLogDir)(allArgs.artifacts);
(0, logging_1.setAreaName)('CLI');
(0, logging_1.log)("Process args: ".concat(process.argv.join(' ')), { lvl: 'debug' });
var scriptNames = Object.keys(scripts);
if (scriptNames.indexOf(scriptName) === -1) {
    (0, logging_1.log)("Invalid script name: '".concat(scriptName, "'. Use one of the following: \n\n").concat(scriptNames.join('\n')), { lvl: 'error' });
    (0, shelljs_1.exit)(1);
}
(0, helpers_1.ensureDir)(allArgs.artifacts);
allArgs.toolsVersion = package_json_1.version;
(0, logging_1.log)("Tools version: ".concat(package_json_1.version, "\nTS version: ").concat(typescript_1.version));
scripts[scriptName].forEach(function (tool) { return tool(allArgs); });
//# sourceMappingURL=cli.js.map