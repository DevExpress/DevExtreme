"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValues = exports.byKeyComparer = void 0;
function byKeyComparer(getter) {
    return function (objA, objB) { return getter(objA).localeCompare(getter(objB)); };
}
exports.byKeyComparer = byKeyComparer;
function getValues(obj) {
    return obj ? Object.keys(obj).map(function (k) { return obj[k]; }) : undefined;
}
exports.getValues = getValues;
//# sourceMappingURL=helpers.js.map