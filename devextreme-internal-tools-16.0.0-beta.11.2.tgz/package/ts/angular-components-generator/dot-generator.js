"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DotGenerator = exports.createTemplateFromString = void 0;
var fs = require("fs");
var path = require("path");
var mkdirp = require("mkdirp");
var doT = require("dot");
var logger_1 = require("./logger");
var template_1 = require("../components-generation/template");
doT.templateSettings = __assign({ append: true, selfcontained: false }, template_1.commonTemplateSettings);
function createTemplateFromString(templateString) {
    return doT.template(templateString);
}
exports.createTemplateFromString = createTemplateFromString;
var DotGenerator = (function () {
    function DotGenerator() {
        this._encoding = 'utf8';
    }
    DotGenerator.prototype.createTemplate = function (templateFilePath) {
        (0, logger_1.default)("Create doT template from ".concat(templateFilePath));
        var templateString = fs.readFileSync(templateFilePath, this._encoding);
        return createTemplateFromString(templateString);
    };
    DotGenerator.prototype.generate = function (config) {
        var _this = this;
        var outputFolderPath = config.outputFolderPath, metadataFolderPath = config.metadataFolderPath, nestedPathPart = config.nestedPathPart;
        mkdirp.sync(outputFolderPath);
        var componentTemplate = this.createTemplate(config.templateFilePath || path.join(__dirname, './templates/component.tst'));
        var nestedComponentTemplate = this.createTemplate(config.nestedTemplateFilePath || path.join(__dirname, './templates/nested-component.tst'));
        (0, logger_1.default)("List directory: ".concat(metadataFolderPath));
        fs.readdirSync(metadataFolderPath)
            .filter(function (d) { return d !== 'nested'; })
            .forEach(function (dirname) {
            var componentName = dirname;
            var componentMetaPath = path.join(metadataFolderPath, componentName, "".concat(componentName, ".json"));
            var componentOutputPath = path.join(outputFolderPath, componentName, 'index.ts');
            _this.generateComponent(componentMetaPath, componentOutputPath, componentTemplate);
            _this.createEntryPoint(path.dirname(componentOutputPath));
            var nestedComponentsFolder = path.join(metadataFolderPath, componentName, nestedPathPart);
            if (fs.existsSync(nestedComponentsFolder)) {
                var names_1 = [];
                fs.readdirSync(nestedComponentsFolder)
                    .filter(function (f) { return fs.lstatSync(path.join(nestedComponentsFolder, f)).isFile(); })
                    .forEach(function (fileName) {
                    var nestedComponentName = path.parse(fileName).name;
                    var nestedComponentOutputPath = path.join(outputFolderPath, componentName, nestedPathPart, "".concat(nestedComponentName, ".ts"));
                    names_1.push(nestedComponentName);
                    _this.generateComponent(path.join(nestedComponentsFolder, fileName), nestedComponentOutputPath, nestedComponentTemplate);
                });
                var indexFilePath = path.join(outputFolderPath, componentName, nestedPathPart, 'index.ts');
                fs.writeFileSync(indexFilePath, "".concat(names_1.map(function (name) { return "export * from './".concat(name, "';\n"); }).join(''), "\n"), { encoding: _this._encoding });
                _this.createEntryPoint(path.dirname(indexFilePath));
            }
        });
        this.generateLegacyComponents(config.nestedTemplateFilePath || path.join(__dirname, './templates/nested-component.tst'), path.join(config.metadataFolderPath, config.nestedPathPart), path.join(config.outputFolderPath, config.nestedPathPart));
        this.generateLegacyComponents(config.baseNestedTemplateFilePath || path.join(__dirname, './templates/base-nested-component.tst'), path.join(config.metadataFolderPath, config.nestedPathPart, config.basePathPart), path.join(config.outputFolderPath, config.nestedPathPart, config.basePathPart));
        this.createEntryPoint(path.join(config.outputFolderPath, 'nested'));
    };
    DotGenerator.prototype.applyTemplate = function (metadataFilePath, template) {
        (0, logger_1.default)("Read data from ".concat(metadataFilePath));
        var data = fs.readFileSync(metadataFilePath, { encoding: this._encoding });
        (0, logger_1.default)('Apply template');
        return template(JSON.parse(data));
    };
    DotGenerator.prototype.generateComponent = function (metadataPath, outputPath, template) {
        var result = this.applyTemplate(metadataPath, template);
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, result, { encoding: this._encoding });
    };
    DotGenerator.prototype.generateLegacyComponents = function (templateFilePath, metadataFolderPath, outputFolderPath, isSecondaryEntryPoint) {
        var _this = this;
        if (isSecondaryEntryPoint === void 0) { isSecondaryEntryPoint = false; }
        var template = this.createTemplate(templateFilePath);
        mkdirp.sync(outputFolderPath);
        (0, logger_1.default)("List directory: ".concat(metadataFolderPath));
        var names = [];
        fs.readdirSync(metadataFolderPath)
            .filter(function (fileName) { return fs.lstatSync(path.join(metadataFolderPath, fileName)).isFile(); })
            .forEach(function (fileName) {
            var filePath = path.join(metadataFolderPath, fileName);
            var result = _this.applyTemplate(filePath, template);
            var widgetName = path.parse(filePath).name;
            names.push(widgetName);
            var resultFilePath;
            if (isSecondaryEntryPoint) {
                fs.mkdirSync(path.join(outputFolderPath, widgetName));
                resultFilePath = path.join(outputFolderPath, "".concat(widgetName, "/index.ts"));
            }
            else {
                resultFilePath = path.join(outputFolderPath, "".concat(widgetName, ".ts"));
            }
            (0, logger_1.default)("Write result to ".concat(resultFilePath));
            fs.writeFileSync(resultFilePath, result, { encoding: _this._encoding });
        });
        if (!isSecondaryEntryPoint) {
            fs.writeFileSync("".concat(outputFolderPath, "/index.ts"), "".concat(names.map(function (name) { return "export * from './".concat(name, "';\n"); }).join(''), "\n"), { encoding: this._encoding });
        }
    };
    DotGenerator.prototype.createEntryPoint = function (outputFolderPath) {
        fs.writeFileSync(path.join(outputFolderPath, 'ng-package.json'), JSON.stringify({
            lib: {
                entryFile: 'index.ts',
            },
        }, null, '  '), { encoding: this._encoding });
    };
    return DotGenerator;
}());
exports.DotGenerator = DotGenerator;
//# sourceMappingURL=dot-generator.js.map