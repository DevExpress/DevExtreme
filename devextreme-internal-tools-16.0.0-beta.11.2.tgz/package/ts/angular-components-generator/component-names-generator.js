"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComponentNamesGenerator = void 0;
var fs = require("fs");
var path = require("path");
var ComponentNamesGenerator = (function () {
    function ComponentNamesGenerator(config) {
        this.encoding = 'utf8';
        this.config = config;
    }
    ComponentNamesGenerator.prototype.prepareTagName = function (fileName) {
        return "    '".concat(fileName.replace('.ts', ''), "'");
    };
    ComponentNamesGenerator.prototype.validateFileName = function (fileName) {
        return this.config.excludedFileNames.indexOf(fileName) < 0;
    };
    ComponentNamesGenerator.prototype.generate = function () {
        var _this = this;
        var directoryPath = this.config.componentFilesPath;
        var files = fs.readdirSync(directoryPath);
        var fileList = files
            .filter(function (fileName) { return !fs.lstatSync(path.join(directoryPath, fileName)).isFile()
            && _this.validateFileName(fileName); }).map(function (fileName) { return _this.prepareTagName(fileName); })
            .join(',\n');
        var resultContent = "export const componentNames = [\n".concat(fileList, "\n];\n");
        fs.writeFileSync(this.config.outputFileName, resultContent, { encoding: this.encoding });
    };
    return ComponentNamesGenerator;
}());
exports.ComponentNamesGenerator = ComponentNamesGenerator;
//# sourceMappingURL=component-names-generator.js.map