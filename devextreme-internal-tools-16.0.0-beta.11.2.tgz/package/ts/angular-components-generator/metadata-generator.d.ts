import { Metadata } from './metadata-model';
interface Config {
    sourceMetadataFilePath: string;
    deprecatedMetadataFilePath: string;
    outputFolderPath: string;
    nestedPathPart: string;
    basePathPart: string;
    widgetPackageName: string;
    wrapperPackageName: string;
    generateReexports: boolean;
}
export interface IObjectStore {
    read(name: string): Metadata;
    write(name: string, data: Record<string, any>): void;
}
export declare class FSObjectStore implements IObjectStore {
    private encoding;
    read(filePath: any): any;
    write(filePath: any, data: any): void;
}
export declare class ComponentMetadataGenerator {
    private store?;
    constructor(store?: IObjectStore);
    generate(config: Config): void;
    private createEvent;
    private filterWidgetNestedComponents;
    private getTypesDescription;
    private getTypeParts;
    private getObjectType;
    private getEventType;
    private getType;
    private mergeArrayTypes;
    private getExternalObjectInfo;
    private generateComplexOptionByType;
    private generateComplexOption;
    private getBaseComponentPath;
    private getNewNestedClassname;
    private mergeNestedComponents;
    private prepareComponentNestedOptionsMetadata;
    private prepareCommonNestedOptionsMetadata;
    private writeNestedOptionsMetadata;
}
export {};
