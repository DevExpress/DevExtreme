export declare class CommonReexportsGenerator {
    generate(config: any): void;
    private generateReexports;
}
