export declare function createTemplateFromString(templateString: string): any;
export declare class DotGenerator {
    private _encoding;
    createTemplate(templateFilePath: string): any;
    generate(config: any): void;
    private applyTemplate;
    private generateComponent;
    private generateLegacyComponents;
    private createEntryPoint;
}
