"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var yargs = require("yargs");
var argv = yargs
    .default('verbose', false).parseSync();
function default_1() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    if (argv.verbose) {
        console.log.apply(console, args);
    }
}
exports.default = default_1;
//# sourceMappingURL=logger.js.map