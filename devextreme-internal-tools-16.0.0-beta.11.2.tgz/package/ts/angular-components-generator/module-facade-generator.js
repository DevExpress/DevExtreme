"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModuleFacadeGenerator = void 0;
var fs = require("fs");
var path = require("path");
var inflector = require("inflector-js");
var logger_1 = require("./logger");
var ModuleFacadeGenerator = (function () {
    function ModuleFacadeGenerator() {
        this.encoding = 'utf8';
    }
    ModuleFacadeGenerator.prototype.prepareModuleName = function (fileName) {
        var result = fileName.replace(/-/g, '_');
        result = inflector.camelize(result);
        result = "Dx".concat(result, "Module");
        return result;
    };
    ModuleFacadeGenerator.prototype.generate = function (config) {
        var _this = this;
        Object.keys(config.moduleFacades).forEach(function (moduleFilePath) {
            (0, logger_1.default)("Generate facade: ".concat(moduleFilePath));
            var facadeConfig = config.moduleFacades[moduleFilePath];
            var moduleNamesString = '';
            var importModuleString = '';
            facadeConfig.sourceComponentDirectories.forEach(function (directoryPath) {
                (0, logger_1.default)("List directory: ".concat(directoryPath));
                var files = fs.readdirSync(directoryPath);
                files
                    .filter(function (fileName) { return !fs.lstatSync(path.join(directoryPath, fileName)).isFile() && fileName !== 'nested'; })
                    .forEach(function (fileName) {
                    var moduleName = _this.prepareModuleName(fileName);
                    moduleNamesString += "\n    ".concat(moduleName, ",");
                    importModuleString += "import { ".concat(moduleName, " } from 'devextreme-angular/ui/").concat(fileName, "';\n");
                });
            });
            Object.keys(facadeConfig.additionalImports).forEach(function (importName) {
                moduleNamesString += "\n    ".concat(importName, ",");
                importModuleString += "".concat(facadeConfig.additionalImports[importName], ";\n");
            });
            moduleNamesString = moduleNamesString.slice(0, -1);
            importModuleString = importModuleString.slice(0, -1);
            var resultContent = "import { NgModule } from '@angular/core';\n".concat(importModuleString, "\n\n@NgModule({\n    imports: [").concat(moduleNamesString, "\n    ],\n    exports: [").concat(moduleNamesString, "\n    ]\n})\nexport class DevExtremeModule {}\n");
            (0, logger_1.default)("Write result to ".concat(moduleFilePath));
            fs.writeFileSync(moduleFilePath, resultContent, { encoding: _this.encoding });
        });
    };
    return ModuleFacadeGenerator;
}());
exports.ModuleFacadeGenerator = ModuleFacadeGenerator;
//# sourceMappingURL=module-facade-generator.js.map