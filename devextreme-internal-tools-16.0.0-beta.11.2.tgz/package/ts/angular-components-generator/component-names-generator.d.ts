export declare class ComponentNamesGenerator {
    private encoding;
    private config;
    constructor(config: any);
    prepareTagName(fileName: string): string;
    validateFileName(fileName: string): boolean;
    generate(): void;
}
