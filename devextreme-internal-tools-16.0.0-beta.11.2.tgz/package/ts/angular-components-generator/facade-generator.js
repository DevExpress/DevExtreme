"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacadeGenerator = void 0;
var fs = require("fs");
var path = require("path");
var inflector = require("inflector-js");
var logger_1 = require("./logger");
var reexports_generator_1 = require("../components-generation/reexports-generator");
var FacadeGenerator = (function () {
    function FacadeGenerator() {
        this.encoding = 'utf8';
    }
    FacadeGenerator.prototype.generate = function (config) {
        var _this = this;
        Object.keys(config.facades).forEach(function (facadeFilePath) {
            (0, logger_1.default)("Generate facade: ".concat(facadeFilePath));
            var facadeConfig = config.facades[facadeFilePath];
            var resultContent = '';
            resultContent += 'export * from \'devextreme-angular/core\';\n';
            resultContent += 'export * from \'./ui/all\';\n';
            config.commonImports.forEach(function (i) {
                resultContent += "import '".concat(i, "';\n");
            });
            var reexports = fs.readdirSync(facadeConfig.sourceDirectories[0])
                .filter(function (dirName) { return (fs
                .lstatSync(path.join(facadeConfig.sourceDirectories[0], dirName))
                .isDirectory() && dirName !== 'nested'); })
                .map(function (dirName) {
                var name = path.parse(path.join(facadeConfig.sourceDirectories[0], dirName)).name;
                var formattedName = formatName(name);
                return {
                    names: ["Dx".concat(formattedName, "Component"), "Dx".concat(formattedName, "Module")],
                    path: "devextreme-angular/ui/".concat(name),
                };
            });
            resultContent += (0, reexports_generator_1.default)(reexports, { quotes: 'single' });
            (0, logger_1.default)("Write result to ".concat(facadeFilePath));
            fs.writeFileSync(facadeFilePath, resultContent, { encoding: _this.encoding });
        });
    };
    return FacadeGenerator;
}());
exports.FacadeGenerator = FacadeGenerator;
function formatName(name) {
    if (!name.includes('-')) {
        return inflector.camelize(name);
    }
    return name.split('-').map(function (n) { return inflector.camelize(n); }).join('');
}
//# sourceMappingURL=facade-generator.js.map