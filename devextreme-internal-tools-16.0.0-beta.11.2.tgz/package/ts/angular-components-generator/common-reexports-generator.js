"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonReexportsGenerator = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var dot_generator_1 = require("./dot-generator");
var render = (0, dot_generator_1.createTemplateFromString)("\nexport {<#~ it.reexports :reExport #>\n    <#= reExport #>,<#~#>\n} from '<#= it.module #>';\n".trimLeft());
var CommonReexportsGenerator = (function () {
    function CommonReexportsGenerator() {
    }
    CommonReexportsGenerator.prototype.generate = function (config) {
        var _this = this;
        var _a;
        var metadata = JSON.parse((0, fs_1.readFileSync)(config.metadataPath).toString());
        var widgetsPackage = (_a = config.widgetsPackage) !== null && _a !== void 0 ? _a : 'devextreme';
        if (!metadata.CommonReexports) {
            return;
        }
        var commonTargetFolderName = 'common';
        var commonPath = (0, path_1.join)(config.outputPath, commonTargetFolderName);
        if (!(0, fs_1.existsSync)(commonPath)) {
            (0, fs_1.mkdirSync)(commonPath);
        }
        Object.keys(metadata.CommonReexports).forEach(function (key) {
            var targetFolder = (0, path_1.join)(config.outputPath, key);
            (0, fs_1.mkdirSync)(targetFolder, { recursive: true });
            var fileContent = _this.generateReexports("".concat(widgetsPackage, "/").concat(key), metadata.CommonReexports[key]);
            (0, fs_1.writeFileSync)((0, path_1.join)(targetFolder, 'index.ts'), fileContent, { encoding: 'utf8' });
            (0, fs_1.writeFileSync)((0, path_1.join)(targetFolder, 'ng-package.json'), JSON.stringify({
                lib: {
                    entryFile: 'index.ts',
                },
            }, null, '  '), { encoding: 'utf8' });
        });
    };
    CommonReexportsGenerator.prototype.generateReexports = function (module, reexports) {
        var result = render({ module: module, reexports: reexports });
        return result;
    };
    return CommonReexportsGenerator;
}());
exports.CommonReexportsGenerator = CommonReexportsGenerator;
//# sourceMappingURL=common-reexports-generator.js.map