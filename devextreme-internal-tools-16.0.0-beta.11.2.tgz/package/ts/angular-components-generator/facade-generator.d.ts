export declare class FacadeGenerator {
    private encoding;
    generate(config: any): void;
}
