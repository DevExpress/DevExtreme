"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ComponentMetadataGenerator = exports.FSObjectStore = void 0;
var fs = require("fs");
var path = require("path");
var mkdirp = require("mkdirp");
var merge = require("deepmerge");
var inflector = require("inflector-js");
var logger_1 = require("./logger");
var import_helper_1 = require("./import-helper");
var helpers_1 = require("./helpers");
var utils_1 = require("../common/utils");
var OPTION_COMPONENT_PREFIX = 'Dxo';
var ITEM_COMPONENT_PREFIX = 'Dxi';
var TYPES_SEPARATOR = ' | ';
var NON_EXPORTED_NESTED_COMPONENTS = [
    'DxiToolbarItem',
];
function trimDx(value) {
    return trimPrefix('dx-', value);
}
function trimPrefix(prefix, value) {
    if (value.indexOf(prefix) === 0) {
        return value.substr(prefix.length);
    }
    return value;
}
var FSObjectStore = (function () {
    function FSObjectStore() {
        this.encoding = 'utf8';
    }
    FSObjectStore.prototype.read = function (filePath) {
        (0, logger_1.default)("Read from file: ".concat(filePath));
        var dataString = fs.readFileSync(filePath, { encoding: this.encoding });
        (0, logger_1.default)('Parse data');
        return JSON.parse(dataString);
    };
    FSObjectStore.prototype.write = function (filePath, data) {
        (0, logger_1.default)("Write data to file ".concat(filePath));
        var dataString = JSON.stringify(data, null, 4);
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
        fs.writeFileSync(filePath, dataString, { encoding: this.encoding });
    };
    return FSObjectStore;
}());
exports.FSObjectStore = FSObjectStore;
var ComponentMetadataGenerator = (function () {
    function ComponentMetadataGenerator(store) {
        this.store = store;
        if (!this.store) {
            this.store = new FSObjectStore();
        }
    }
    ComponentMetadataGenerator.prototype.generate = function (config) {
        var _a, _b;
        var sourceMetadata = this.store.read(config.sourceMetadataFilePath);
        var deprecatedMetadata = this.store.read(config.deprecatedMetadataFilePath);
        var metadata = merge(sourceMetadata, deprecatedMetadata);
        var widgetsMetadata = metadata.Widgets;
        var allNestedComponents = [];
        mkdirp.sync(config.outputFolderPath);
        mkdirp.sync(path.join(config.outputFolderPath, config.nestedPathPart));
        mkdirp.sync(path.join(config.outputFolderPath, config.nestedPathPart, config.basePathPart));
        for (var widgetName in widgetsMetadata) {
            var widget = widgetsMetadata[widgetName];
            var nestedComponents = [];
            if (!widget.Module) {
                (0, logger_1.default)("Skipping metadata for ".concat(widgetName));
                continue;
            }
            (0, logger_1.default)("Generate metadata for ".concat(widgetName));
            var isTranscludedContent = widget.IsTranscludedContent;
            var isViz = widget.Module.indexOf('viz') === 0;
            var isExtension = widget.IsExtensionComponent || false;
            var className = inflector.camelize(widgetName);
            var dasherizedWidgetName = inflector.dasherize(inflector.underscore(widgetName));
            var outputFilePath = path.join(config.outputFolderPath, trimDx(dasherizedWidgetName), "".concat(trimDx(dasherizedWidgetName), ".json"));
            var events = [];
            var changeEvents = [];
            var properties = [];
            var isEditor = Object.keys(widget.Options).indexOf('onValueChanged') !== -1;
            for (var optionName in widget.Options) {
                var option = widget.Options[optionName];
                if (option.IsEvent) {
                    var eventName = inflector.camelize(optionName.substr('on'.length), true);
                    var eventType = ((_a = option.TypeImports) === null || _a === void 0 ? void 0 : _a.length) ? option.TypeImports[0].Name : 'any';
                    events.push({
                        docID: option.DocID,
                        isDeprecated: option.IsDeprecated,
                        emit: optionName,
                        subscribe: eventName,
                        type: "EventEmitter<".concat(eventType, ">"),
                    });
                }
                else {
                    var typesDescription = this.getTypesDescription(option);
                    var finalizedType = this.getType(typesDescription);
                    var property = {
                        docID: option.DocID,
                        isDeprecated: option.IsDeprecated,
                        name: optionName,
                        type: finalizedType,
                        typesDescription: typesDescription,
                        option: option,
                    };
                    if (!!option.IsCollection || !!option.IsDataSource) {
                        property.isCollection = true;
                    }
                    properties.push(property);
                    changeEvents.push(this.createEvent(optionName, finalizedType, option));
                    var components = this.generateComplexOptionByType(metadata, option, optionName, [], config);
                    nestedComponents = nestedComponents.concat.apply(nestedComponents, components);
                }
            }
            var allEvents = events.concat(changeEvents);
            if (isEditor) {
                allEvents.push({ emit: 'onBlur', type: 'EventEmitter<any>' });
            }
            var parentName = trimDx(dasherizedWidgetName);
            var componentNestedOptions = this.prepareComponentNestedOptionsMetadata(config, nestedComponents, parentName);
            var widgetNestedComponents = this.filterWidgetNestedComponents(componentNestedOptions, properties);
            var widgetLegacyNestedComponents = this.filterWidgetNestedComponents(nestedComponents, properties)
                .filter(function (component) { return !NON_EXPORTED_NESTED_COMPONENTS.includes(component.className); });
            var containsReexports = !!((_b = widget.Reexports) === null || _b === void 0 ? void 0 : _b.filter(function (r) { return r !== 'default'; }).length);
            var widgetMetadata = {
                docID: widget.DocID,
                isDeprecated: widget.IsDeprecated,
                className: className,
                widgetName: widgetName,
                isTranscludedContent: isTranscludedContent,
                isViz: isViz,
                isExtension: isExtension,
                selector: dasherizedWidgetName,
                path: trimDx(dasherizedWidgetName),
                events: allEvents,
                properties: properties,
                isEditor: isEditor,
                module: "".concat(config.widgetPackageName, "/").concat(widget.Module),
                packageName: config.wrapperPackageName,
                imports: (0, import_helper_1.buildImports)((0, helpers_1.getValues)(widget.Options), config.widgetPackageName),
                nestedComponents: widgetNestedComponents,
                legacyNestedComponents: widgetLegacyNestedComponents,
                optionsTypeParams: widget.OptionsTypeParams,
                renderReexports: config.generateReexports && containsReexports,
            };
            (0, logger_1.default)("Write metadata to file ".concat(outputFilePath));
            this.store.write(outputFilePath, normalizeMeta(widgetMetadata));
            this.writeNestedOptionsMetadata(componentNestedOptions, path.join(config.outputFolderPath, parentName, config.nestedPathPart));
            allNestedComponents = allNestedComponents.concat.apply(allNestedComponents, nestedComponents);
        }
        var commonNestedOptions = this.prepareCommonNestedOptionsMetadata(config, allNestedComponents);
        this.writeNestedOptionsMetadata(commonNestedOptions, path.join(config.outputFolderPath, config.nestedPathPart));
    };
    ComponentMetadataGenerator.prototype.createEvent = function (name, type, option) {
        return {
            isInternal: true,
            emit: "".concat(name, "Change"),
            type: "EventEmitter<".concat(type, ">"),
            option: option,
        };
    };
    ComponentMetadataGenerator.prototype.filterWidgetNestedComponents = function (nestedComponents, widgetProperties) {
        return (0, utils_1.distinctByProperty)(nestedComponents, 'className')
            .map(function (component) { return ({
            path: component.path,
            propertyName: component.propertyName,
            className: component.className,
            events: component.events,
            isCollection: component.isCollection,
            hasTemplate: component.hasTemplate,
            root: widgetProperties.filter(function (p) { return p.name === component.propertyName; }).length === 1 ? true : undefined,
        }); });
    };
    ComponentMetadataGenerator.prototype.getTypesDescription = function (optionMetadata) {
        var typeParts = this.getTypeParts(optionMetadata);
        return {
            primitiveTypes: typeParts.primitiveTypes,
            arrayTypes: typeParts.arrayTypes,
        };
    };
    ComponentMetadataGenerator.prototype.getTypeParts = function (optionMetadata) {
        var primitiveTypes = optionMetadata.PrimitiveTypes ? optionMetadata.PrimitiveTypes.slice(0) : [];
        var arrayTypes = [];
        if (optionMetadata.ItemPrimitiveTypes) {
            if (optionMetadata.IsPromise) {
                var promiseType = optionMetadata.ItemPrimitiveTypes.join(TYPES_SEPARATOR);
                primitiveTypes.push("Promise<".concat(promiseType, "> & JQueryPromise<").concat(promiseType, ">"));
            }
            else {
                arrayTypes = arrayTypes.concat(optionMetadata.ItemPrimitiveTypes);
            }
        }
        if (optionMetadata.Options) {
            var optionType = this.getObjectType(optionMetadata.Options);
            if (optionType.length) {
                (optionMetadata.IsCollection ? arrayTypes : primitiveTypes).push(optionType);
            }
        }
        return ({ primitiveTypes: primitiveTypes, arrayTypes: arrayTypes });
    };
    ComponentMetadataGenerator.prototype.getObjectType = function (optionMetadata) {
        var objectType = [];
        for (var option in optionMetadata) {
            var typeParts = this.getTypeParts(optionMetadata[option]);
            var type = this.getType(typeParts);
            objectType.push("".concat(option, "?: ").concat(type));
        }
        if (objectType.length) {
            return "{ ".concat(objectType.join(', '), " }");
        }
        return '';
    };
    ComponentMetadataGenerator.prototype.getEventType = function (typesDescription, option) {
        var _a;
        if (!((option === null || option === void 0 ? void 0 : option.IsEvent) && ((_a = option.TypeImports) === null || _a === void 0 ? void 0 : _a.length))) {
            return this.getType(typesDescription);
        }
        return "((e: ".concat(option.TypeImports[0].Name, ") => void)");
    };
    ComponentMetadataGenerator.prototype.getType = function (typesDescription) {
        var primitiveTypes = typesDescription.primitiveTypes.slice(0);
        var result = 'any';
        if (typesDescription.arrayTypes.length) {
            primitiveTypes.push("Array<".concat(typesDescription.arrayTypes.join(TYPES_SEPARATOR), ">"));
        }
        if (primitiveTypes.length) {
            result = primitiveTypes.join(TYPES_SEPARATOR);
        }
        return result;
    };
    ComponentMetadataGenerator.prototype.mergeArrayTypes = function (array1, array2) {
        var newTypes = array2.filter(function (type) { return array1.indexOf(type) === -1; });
        return [].concat(array1, newTypes);
    };
    ComponentMetadataGenerator.prototype.getExternalObjectInfo = function (metadata, typeName) {
        var externalObject = metadata.ExtraObjects[typeName];
        if (!externalObject) {
            var postfix = 'Options';
            if (typeName.endsWith(postfix)) {
                var widgetName = typeName.substr(0, typeName.length - postfix.length);
                externalObject = metadata.Widgets[widgetName];
                typeName = trimPrefix('dx', typeName);
            }
        }
        if (!externalObject) {
            console.warn("WARN: missed complex type: ".concat(typeName));
        }
        else {
            return {
                Options: externalObject.Options,
                typeName: typeName,
            };
        }
        return undefined;
    };
    ComponentMetadataGenerator.prototype.generateComplexOptionByType = function (metadata, option, optionName, complexTypes, config) {
        var _this = this;
        var optionComplexTypes = option[option.IsCollection ? 'ItemComplexTypes' : 'ComplexTypes'];
        if (option.Options) {
            return this.generateComplexOption(metadata, option.Options, optionName, complexTypes, option, config);
        }
        if (optionComplexTypes && optionComplexTypes.length > 0) {
            if (complexTypes.indexOf(complexTypes[complexTypes.length - 1]) !== complexTypes.length - 1) {
                return undefined;
            }
            var result_1 = [];
            optionComplexTypes.forEach(function (complexType) {
                var externalObjectInfo = _this.getExternalObjectInfo(metadata, complexType);
                if (externalObjectInfo) {
                    var nestedOptions = externalObjectInfo.Options;
                    var nestedComplexTypes = complexTypes.concat(externalObjectInfo.typeName);
                    result_1.push.apply(result_1, _this.generateComplexOption(metadata, nestedOptions, optionName, nestedComplexTypes, option, config));
                }
            });
            if (optionComplexTypes.length === 1) {
                var externalObjectInfo = this.getExternalObjectInfo(metadata, optionComplexTypes[0]);
                if (externalObjectInfo) {
                    result_1[0].baseClass = (option.IsCollection ? ITEM_COMPONENT_PREFIX : OPTION_COMPONENT_PREFIX) + externalObjectInfo.typeName;
                    result_1[0].basePath = inflector.dasherize(inflector.underscore(externalObjectInfo.typeName));
                }
            }
            return result_1;
        }
        return undefined;
    };
    ComponentMetadataGenerator.prototype.generateComplexOption = function (metadata, nestedOptions, optionName, complexTypes, option, config) {
        var _a;
        var _b;
        if (!nestedOptions || !Object.keys(nestedOptions).length) {
            return undefined;
        }
        var pluralName = optionName;
        if (option.IsCollection) {
            pluralName = "".concat(option.SingularName, "Dxi");
        }
        var singularName = option.SingularName || pluralName;
        var underscoreSingular = inflector.underscore(singularName).split('.').join('_');
        var underscorePlural = inflector.underscore(pluralName).split('.').join('_');
        var prefix = "".concat((option.IsCollection ? ITEM_COMPONENT_PREFIX : OPTION_COMPONENT_PREFIX).toLocaleLowerCase(), "_");
        var underscoreSelector = prefix + (option.IsCollection ? underscoreSingular : underscorePlural);
        var selector = inflector.dasherize(underscoreSelector);
        var complexOptionMetadata = {
            docID: option.DocID,
            isDeprecated: option.IsDeprecated,
            className: inflector.camelize(underscoreSelector),
            selector: selector,
            optionName: optionName,
            properties: [],
            events: [],
            path: inflector.dasherize(underscorePlural),
            propertyName: optionName,
            isCollection: option.IsCollection,
            hasTemplate: option.Options && option.Options.template && option.Options.template.IsTemplate,
            collectionNestedComponents: [],
            imports: [],
        };
        var nestedComponents = [complexOptionMetadata];
        for (var optName in nestedOptions) {
            var nestedOption = nestedOptions[optName];
            var typesDescription = this.getTypesDescription(nestedOption);
            var propertyType = this.getType(typesDescription);
            if (nestedOption.IsEvent && ((_b = nestedOption.TypeImports) === null || _b === void 0 ? void 0 : _b.length)) {
                propertyType = "((e: ".concat(nestedOption.TypeImports[0].Name, ") => void)");
            }
            var property = {
                docID: nestedOption.DocID,
                isDeprecated: nestedOption.IsDeprecated,
                name: optName,
                type: propertyType,
                typesDescription: typesDescription,
                option: nestedOption,
            };
            if (nestedOption.IsCollection) {
                property.isCollection = true;
            }
            complexOptionMetadata.properties.push(property);
            if (nestedOption.IsChangeable || nestedOption.IsReadonly) {
                complexOptionMetadata.events.push(this.createEvent(optName, propertyType, nestedOption));
            }
            var components = this.generateComplexOptionByType(metadata, nestedOptions[optName], optName, complexTypes, config) || [];
            nestedComponents = nestedComponents.concat.apply(nestedComponents, components);
            var ownCollectionNestedComponents = components
                .filter(function (c) { return complexOptionMetadata
                .properties
                .filter(function (p) { return p.name === c.propertyName && p.isCollection; }).length === 1; })
                .map(function (c) { return ({
                className: c.className,
                path: c.path,
                propertyName: c.propertyName,
            }); });
            (_a = complexOptionMetadata.collectionNestedComponents).push.apply(_a, ownCollectionNestedComponents);
        }
        complexOptionMetadata.imports = (0, import_helper_1.buildImports)((0, helpers_1.getValues)(nestedOptions), config.widgetPackageName);
        return nestedComponents;
    };
    ComponentMetadataGenerator.prototype.getBaseComponentPath = function (component) {
        return component.basePath + (component.isCollection ? '-dxi' : '');
    };
    ComponentMetadataGenerator.prototype.getNewNestedClassname = function (className, parentName) {
        var _a = inflector.underscore(className).split('_'), prefix = _a[0], rest = _a.slice(1);
        return inflector.camelize(__spreadArray([prefix, inflector.camelize(parentName.replaceAll('-', '_'))], rest, true).join('_'));
    };
    ComponentMetadataGenerator.prototype.mergeNestedComponents = function (components) {
        var _this = this;
        var mergedNestedComponents = {};
        components.forEach(function (component) {
            var _a, _b, _c, _d;
            if (!mergedNestedComponents[component.className]) {
                mergedNestedComponents[component.className] = __assign(__assign({}, component), { options: component.properties.map(function (p) { return p.option; }) });
            }
            else {
                var mergedComponent = mergedNestedComponents[component.className];
                mergedComponent.properties = (_a = mergedComponent.properties)
                    .concat.apply(_a, component.properties).reduce(function (properties, property) {
                    var _a;
                    if (!properties.some(function (_a) {
                        var name = _a.name;
                        return name === property.name;
                    })) {
                        properties.push(property);
                    }
                    else {
                        var existingProperty = properties.find(function (_a) {
                            var name = _a.name;
                            return name === property.name;
                        });
                        var typesDescription = existingProperty.typesDescription;
                        typesDescription.primitiveTypes = _this.mergeArrayTypes(typesDescription.primitiveTypes, property.typesDescription.primitiveTypes);
                        typesDescription.arrayTypes = _this.mergeArrayTypes(typesDescription.arrayTypes, property.typesDescription.arrayTypes);
                        existingProperty.type = ((_a = existingProperty.option) === null || _a === void 0 ? void 0 : _a.IsEvent)
                            ? _this.getEventType(typesDescription, existingProperty.option)
                            : _this.getType(typesDescription);
                    }
                    return properties;
                }, []);
                if (mergedComponent.events != null) {
                    mergedComponent.events = (0, utils_1.distinctByProperty)((_b = mergedComponent.events).concat.apply(_b, component.events), 'emit');
                }
                mergedComponent.baseClass = mergedComponent.baseClass || component.baseClass;
                mergedComponent.basePath = mergedComponent.basePath || component.basePath;
                mergedComponent.hasTemplate = mergedComponent.hasTemplate || component.hasTemplate;
                (_c = mergedComponent.collectionNestedComponents).push.apply(_c, component.collectionNestedComponents);
                (_d = mergedComponent.options).push.apply(_d, component.properties.map(function (p) { return p.option; }));
            }
        });
        return Object.values(mergedNestedComponents);
    };
    ComponentMetadataGenerator.prototype.prepareComponentNestedOptionsMetadata = function (config, nestedComponents, parentName) {
        var _this = this;
        var componentNestedOptions = this.mergeNestedComponents(structuredClone(nestedComponents));
        componentNestedOptions.forEach(function (component) {
            component.collectionNestedComponents = (0, utils_1.distinctByProperty)(component.collectionNestedComponents, 'className')
                .map(function (c) { return (__assign(__assign({}, c), { className: _this.getNewNestedClassname(c.className, parentName) })); });
        });
        return componentNestedOptions
            .map(function (component) {
            if (component.events && !component.events.length) {
                delete component.events;
            }
            var _a = component.selector.split('-'), prefix = _a[0], rest = _a.slice(1);
            component.selector = __spreadArray([prefix, parentName], rest, true).join('-');
            component.className = _this.getNewNestedClassname(component.className, parentName);
            component.baseClass = component.isCollection ? 'CollectionNestedOption' : 'NestedOption';
            component.basePath = 'devextreme-angular/core';
            component.imports = (0, import_helper_1.buildImports)(component.options, config.widgetPackageName);
            return component;
        });
    };
    ComponentMetadataGenerator.prototype.prepareCommonNestedOptionsMetadata = function (config, metadata) {
        var _this = this;
        var commonNestedOptions = this.mergeNestedComponents(metadata);
        commonNestedOptions.forEach(function (component) {
            component.collectionNestedComponents = (0, utils_1.distinctByProperty)(component.collectionNestedComponents, 'className');
        });
        commonNestedOptions
            .reduce(function (result, component) {
            var existingComponent = result.find(function (c) { return c.className === component.baseClass; });
            if (!existingComponent && component.baseClass) {
                var nestedComponent = {
                    properties: component.properties,
                    events: component.events,
                    className: component.baseClass,
                    path: _this.getBaseComponentPath(component),
                    baseClass: component.isCollection ? 'CollectionNestedOption' : 'NestedOption',
                    basePath: 'devextreme-angular/core',
                    imports: (0, import_helper_1.buildImports)(component.options, config.widgetPackageName),
                };
                result.push(nestedComponent);
            }
            return result;
        }, [])
            .forEach(function (component) {
            var outputFilePath = path.join(config.outputFolderPath, config.nestedPathPart, config.basePathPart, "".concat(component.path, ".json"));
            _this.store.write(outputFilePath, normalizeMeta(component));
        });
        return commonNestedOptions
            .map(function (component) {
            if (component.events && !component.events.length) {
                delete component.events;
            }
            if (component.baseClass) {
                component.inputs = component.properties;
                delete component.properties;
                component.basePath = "./base/".concat(_this.getBaseComponentPath(component));
                component.imports = component.events
                    ? component.imports = (0, import_helper_1.buildImports)(component.events.map(function (e) { return e.option; }), config.widgetPackageName)
                    : undefined;
            }
            else {
                component.baseClass = component.isCollection ? 'CollectionNestedOption' : 'NestedOption';
                component.basePath = 'devextreme-angular/core';
                component.hasSimpleBaseClass = true;
                component.imports = (0, import_helper_1.buildImports)(component.options, config.widgetPackageName);
            }
            return component;
        });
    };
    ComponentMetadataGenerator.prototype.writeNestedOptionsMetadata = function (components, outputDir) {
        var _this = this;
        components.forEach(function (component) {
            var outputFilePath = path.join(outputDir, "".concat(component.path, ".json"));
            _this.store.write(outputFilePath, normalizeMeta(component));
        });
    };
    return ComponentMetadataGenerator;
}());
exports.ComponentMetadataGenerator = ComponentMetadataGenerator;
function normalizeMeta(meta) {
    var result = __assign(__assign({}, meta), { properties: meta.properties && meta.properties.map(function (_a) {
            var option = _a.option, rest = __rest(_a, ["option"]);
            return (__assign({}, rest));
        }), events: meta.events && meta.events.map(function (_a) {
            var option = _a.option, rest = __rest(_a, ["option"]);
            return (__assign({}, rest));
        }) });
    if (!result.imports || !result.imports.length) {
        result.imports = undefined;
        delete result.imports;
    }
    (0, logger_1.default)(result);
    return result;
}
//# sourceMappingURL=metadata-generator.js.map