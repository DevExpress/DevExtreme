export declare class ModuleFacadeGenerator {
    private encoding;
    prepareModuleName(fileName: string): string;
    generate(config: any): void;
}
