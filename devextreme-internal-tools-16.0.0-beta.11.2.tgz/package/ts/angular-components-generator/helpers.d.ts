export declare function byKeyComparer<T>(getter: (obj: T) => string): Parameters<Array<T>['sort']>[0];
export declare function getValues<T>(obj: Record<string, T>): T[];
