import { Option } from './metadata-model';
export interface FileImport {
    path: string;
    importString: string;
}
export declare function buildImports(options: Option[], widgetPackageName: string): FileImport[];
