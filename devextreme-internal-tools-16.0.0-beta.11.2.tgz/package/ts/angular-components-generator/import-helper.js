"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildImports = void 0;
var helpers_1 = require("./helpers");
function buildImports(options, widgetPackageName) {
    var importsByPath = extractImportsMeta(options).reduce(function (paths, _a) {
        var Path = _a.Path, Name = _a.Name, Alias = _a.Alias;
        if (!paths[Path]) {
            paths[Path] = {};
        }
        paths[Path]["".concat(Name, "+").concat(Alias)] = { Name: Name, Alias: Alias };
        return paths;
    }, {});
    return Object.keys(importsByPath)
        .map(function (path) {
        var _a = extractDefaultImport((0, helpers_1.getValues)(importsByPath[path])), defaultImport = _a.defaultImport, namedImports = _a.namedImports;
        var parts = [];
        if (defaultImport) {
            parts.push(defaultImport);
        }
        if (namedImports.length) {
            var namedImportsString = namedImports
                .sort((0, helpers_1.byKeyComparer)(function (i) { return i.Name; }))
                .map(function (_a) {
                var Name = _a.Name, Alias = _a.Alias;
                return (Alias ? "".concat(Name, " as ").concat(Alias) : Name);
            })
                .join(', ');
            parts.push("{ ".concat(namedImportsString, " }"));
        }
        return {
            path: "".concat(widgetPackageName, "/").concat(path),
            importString: parts.join(', '),
        };
    })
        .sort((0, helpers_1.byKeyComparer)(function (i) { return i.path; }));
}
exports.buildImports = buildImports;
function extractImportsMeta(options) {
    if (!options || !options.length) {
        return [];
    }
    return options.reduce(function (r, option) {
        if (option) {
            r.push.apply(r, option.TypeImports);
            r.push.apply(r, extractImportsMeta((0, helpers_1.getValues)(option.Options)));
        }
        return r;
    }, []);
}
function extractDefaultImport(imports) {
    var result = {
        defaultImport: undefined,
        namedImports: [],
    };
    for (var _i = 0, imports_1 = imports; _i < imports_1.length; _i++) {
        var entry = imports_1[_i];
        if (isDefaultImport(entry)) {
            if (!entry.Alias) {
                throw new Error("default export must have an alias: ".concat(JSON.stringify(entry)));
            }
            result.defaultImport = entry.Alias;
        }
        else {
            result.namedImports.push(entry);
        }
    }
    return result;
}
function isDefaultImport(importName) {
    return importName.Name.toLowerCase() === 'default';
}
//# sourceMappingURL=import-helper.js.map