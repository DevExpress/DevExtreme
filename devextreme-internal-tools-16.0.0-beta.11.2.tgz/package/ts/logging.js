"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setAreaName = exports.setLogDir = exports.logStart = exports.log = void 0;
var perf_hooks_1 = require("perf_hooks");
var path_1 = require("path");
var winston_1 = require("winston");
var levels = {
    trace: 5,
    debug: 4,
    info: 3,
    warn: 2,
    error: 1,
    fatal: 0,
};
var colors = {
    trace: 'white',
    debug: 'white',
    info: 'white',
    warn: 'yellow',
    error: 'red',
    fatal: 'white redBG',
};
function init() {
    var errorCount = 0;
    var warnCount = 0;
    var areaName = '';
    var fileName = '';
    var startTime = perf_hooks_1.performance.now();
    var separation = '================================================================';
    var logger = (0, winston_1.createLogger)({
        levels: levels,
        format: winston_1.format.combine(winston_1.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSSS' }), winston_1.format.printf(function (info) { return "".concat(info.timestamp, " | ").concat(info.level[0].toUpperCase() + info.level.slice(1), " | ").concat(areaName, "\n").concat(info.message); })),
        transports: [
            new winston_1.transports.Console({
                level: 'info',
                format: winston_1.format.colorize({ all: true, colors: colors }),
            }),
        ],
    });
    return {
        log: function (message, _a) {
            var _b = _a === void 0 ? {} : _a, _c = _b.lvl, lvl = _c === void 0 ? 'info' : _c, node = _b.node, e = _b.e;
            if (lvl === 'warn') {
                warnCount += 1;
            }
            if (lvl === 'error' || lvl === 'fatal') {
                errorCount += 1;
            }
            var paragraphs = [message];
            if (node)
                paragraphs.push(stringifyNode(node));
            if (e)
                paragraphs.push(stringifyException(e));
            logger.log(lvl, paragraphs.join('\n\n'));
        },
        setLogDir: function (dir) {
            fileName = (0, path_1.resolve)(dir, 'internal-tools-log.txt');
            logger.info("Path to log file: ".concat(fileName));
            logger.add(new winston_1.transports.File({
                filename: fileName,
                level: 'trace',
            }));
        },
        setAreaName: function (name) {
            areaName = name;
        },
        logStart: function () {
            var message = '\n'
                + "".concat(separation, "\n")
                + "".concat(areaName, " Started\n")
                + "".concat(separation, "\n");
            logger.log('trace', message);
            var logTotals = function () {
                var elapsed = perf_hooks_1.performance.now() - startTime;
                var seconds = Math.floor(elapsed / 1000);
                var milis = Math.round(elapsed % 1000);
                var resultMessage = errorCount > 0 ? 'FAILED' : 'SUCCEEDED';
                var logLevel = errorCount > 0 ? 'error' : 'info';
                var startMessage = '\n'
                    + "".concat(separation, "\n")
                    + "\n".concat(areaName, " ").concat(resultMessage, "\n")
                    + "\nWarnings: ".concat(warnCount, "\n")
                    + "Errors: ".concat(errorCount, "\n")
                    + "Elapsed time: ".concat(seconds, ".").concat(milis, " sec\n")
                    + '\n';
                errorCount = 0;
                warnCount = 0;
                logger.log(logLevel, startMessage);
            };
            return logTotals;
        },
    };
}
function stringifyNode(node) {
    var text = "\n".concat(node.getText(), "\n\nSyntaxKind: ").concat(node.kind);
    var sourceFile = node.getSourceFile();
    if (sourceFile) {
        var pos = sourceFile.getLineAndCharacterOfPosition(node.pos);
        return "".concat(text, "\n").concat(sourceFile.fileName, ":").concat(pos.line, ":").concat(pos.character);
    }
    return text;
}
function stringifyException(e) {
    if (e instanceof Error)
        return e.message;
    if (typeof e === 'string')
        return e;
    return 'Unknown exception';
}
var _a = init(), log = _a.log, logStart = _a.logStart, setLogDir = _a.setLogDir, setAreaName = _a.setAreaName;
exports.log = log;
exports.logStart = logStart;
exports.setLogDir = setLogDir;
exports.setAreaName = setAreaName;
//# sourceMappingURL=logging.js.map