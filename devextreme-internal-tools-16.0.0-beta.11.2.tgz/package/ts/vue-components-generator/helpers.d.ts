export declare function removeExtension(path: string): string;
export declare function removePrefix(value: string, prefix: string): string;
export declare function toKebabCase(value: string): string;
export declare function uppercaseFirst(value: string): string;
export declare function lowercaseFirst(value: string): string;
export declare function compareStrings(a: string, b: string): number;
