"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertTypes = void 0;
function convertTypes(types, customTypes) {
    if (types === undefined || types === null || types.length === 0) {
        return undefined;
    }
    var actualTypes = customTypes
        ? types.concat(expandTypes(types, customTypes))
        : types;
    var convertedTypes = new Set(actualTypes.map(convertType));
    if (convertedTypes.has('Any')) {
        return undefined;
    }
    return Array.from(convertedTypes);
}
exports.convertTypes = convertTypes;
function expandTypes(types, customTypes) {
    var expandedTypes = [];
    types.forEach(function (t) {
        if (t.isCustomType) {
            var aliases = customTypes[t.type].types;
            if (aliases) {
                expandedTypes.push.apply(expandedTypes, aliases);
            }
        }
    });
    return expandedTypes;
}
function convertType(typeDescr) {
    switch (typeDescr.type) {
        case 'String':
        case 'Date':
        case 'Number':
        case 'Boolean':
        case 'Array':
        case 'Object':
        case 'Function':
        case 'RegExp':
            return typeDescr.type;
    }
    if (typeDescr.isCustomType) {
        return 'Object';
    }
    return 'Any';
}
//# sourceMappingURL=converter.js.map