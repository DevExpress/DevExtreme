interface IImport {
    name: string;
    path: string;
}
interface IExpectedChild {
    isCollectionItem: boolean;
    optionName: string;
}
interface IComponent {
    name: string;
    widgetComponent: IImport;
    createComponentFn: IImport;
    prepareComponentConfigFn: IImport;
    prepareConfigurationComponentConfigFn: IImport;
    props?: IProp[];
    hasModel?: boolean;
    hasExplicitTypes?: boolean;
    nestedComponents?: INestedComponent[];
    expectedChildren?: Record<string, IExpectedChild>;
    containsReexports?: boolean;
}
interface INestedComponent {
    name: string;
    optionName: string;
    props: IProp[];
    isCollectionItem: boolean;
    expectedChildren?: Record<string, IExpectedChild>;
    predefinedProps?: Record<string, any>;
}
interface IProp {
    name: string;
    types?: string[];
    acceptableValues?: string[];
    acceptableValueType?: string;
    isArray?: boolean;
}
export declare const USE_SYNC_TEMPLATES: Set<string>;
declare function generate(component: IComponent, widgetsPackage?: string, vueVersion?: number, renderReexports?: boolean): string;
declare function renderProps(props: IProp[]): string;
export default generate;
export { IImport, IComponent, IExpectedChild, INestedComponent, IProp, renderProps, };
