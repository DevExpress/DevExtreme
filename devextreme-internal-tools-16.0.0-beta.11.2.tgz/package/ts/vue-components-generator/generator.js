"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapWidget = exports.generate = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var component_generator_1 = require("./component-generator");
var converter_1 = require("./converter");
var helpers_1 = require("./helpers");
var reexports_generator_1 = require("../components-generation/reexports-generator");
var common_reexports_generator_1 = require("../components-generation/common-reexports-generator");
function generate(rawData, _a, out, widgetsPackage, vueVersion, generateReexports) {
    var createComponentFn = _a.createComponentFn, prepareComponentConfigFn = _a.prepareComponentConfigFn, prepareExtensionComponentConfigFn = _a.prepareExtensionComponentConfigFn, prepareConfigurationComponentConfigFn = _a.prepareConfigurationComponentConfigFn;
    var modulePaths = [];
    rawData.widgets.forEach(function (data) {
        var widgetFile = mapWidget(data, createComponentFn, data.isExtension ? prepareExtensionComponentConfigFn : prepareComponentConfigFn, prepareConfigurationComponentConfigFn, rawData.customTypes);
        var widgetFilePath = (0, path_1.join)(out.componentsDir, widgetFile.fileName);
        var indexFileDir = (0, path_1.dirname)(out.indexFileName);
        (0, fs_1.writeFileSync)(widgetFilePath, (0, component_generator_1.default)(widgetFile.component, widgetsPackage, vueVersion, generateReexports), { encoding: 'utf8' });
        modulePaths.push({
            names: [widgetFile.component.name],
            path: "./".concat((0, helpers_1.removeExtension)((0, path_1.relative)(indexFileDir, widgetFilePath)).replace(path_1.sep, '/')),
        });
    });
    (0, fs_1.writeFileSync)(out.indexFileName, (0, reexports_generator_1.default)(modulePaths), { encoding: 'utf8' });
    if (generateReexports && rawData.commonReexports) {
        (0, common_reexports_generator_1.generateCommonReexports)({
            componentsDir: out.componentsDir,
            widgetsPackage: widgetsPackage,
            commonReexports: rawData.commonReexports,
        });
    }
}
exports.generate = generate;
function mapWidget(raw, createComponentFn, prepareComponentConfigFn, prepareConfigurationComponentConfigFn, customTypes) {
    var _a, _b, _c;
    var name = (0, helpers_1.removePrefix)(raw.name, 'dx');
    var customTypeHash = customTypes.reduce(function (result, type) {
        result[type.name] = type;
        return result;
    }, {});
    return {
        fileName: "".concat((0, helpers_1.toKebabCase)(name), ".ts"),
        component: {
            name: "Dx".concat(name),
            widgetComponent: {
                name: name,
                path: raw.exportPath,
            },
            createComponentFn: createComponentFn,
            prepareComponentConfigFn: prepareComponentConfigFn,
            prepareConfigurationComponentConfigFn: prepareConfigurationComponentConfigFn,
            props: getProps(raw.options, customTypeHash),
            hasModel: !!raw.isEditor,
            hasExplicitTypes: !!((_a = raw.optionsTypeParams) === null || _a === void 0 ? void 0 : _a.length),
            nestedComponents: raw.complexOptions
                ? raw.complexOptions.map(function (o) { return mapNestedComponent(o, customTypeHash); })
                : undefined,
            expectedChildren: mapExpectedChildren(raw.nesteds),
            containsReexports: !!((_c = (_b = raw.reexports) === null || _b === void 0 ? void 0 : _b.filter(function (r) { return r !== 'default'; })) === null || _c === void 0 ? void 0 : _c.length),
        },
    };
}
exports.mapWidget = mapWidget;
function mapNestedComponent(complexOption, customTypes) {
    return {
        name: "Dx".concat((0, helpers_1.uppercaseFirst)(complexOption.name)),
        optionName: complexOption.optionName,
        props: getProps(complexOption.props, customTypes),
        isCollectionItem: complexOption.isCollectionItem,
        predefinedProps: complexOption.predefinedProps,
        expectedChildren: mapExpectedChildren(complexOption.nesteds),
    };
}
function getProps(options, customTypes) {
    var reservedPropNames = ['key'];
    return options
        .filter(function (o) { return reservedPropNames.indexOf(o.name) < 0; })
        .map(function (o) { return mapProp(o, customTypes); });
}
function buildValueRestriction(restrictedTypes) {
    var valueRestriction = restrictedTypes.length > 0 ? restrictedTypes[0] : undefined;
    var acceptableValueType = valueRestriction && valueRestriction.type.toLowerCase();
    if (!valueRestriction || acceptableValueType === 'string') {
        return {};
    }
    return {
        acceptableValueType: acceptableValueType,
        acceptableValues: valueRestriction.acceptableValues,
    };
}
function mapProp(rawOption, customTypes) {
    var types = (0, converter_1.convertTypes)(rawOption.types, customTypes);
    var restrictedTypes = rawOption.types.filter(function (t) { return t.acceptableValues && t.acceptableValues.length > 0; });
    var valueRestriction = buildValueRestriction(restrictedTypes);
    return {
        name: rawOption.name,
        acceptableValues: valueRestriction.acceptableValues,
        types: types,
        isArray: types && types.length === 1 && types[0] === 'Array',
        acceptableValueType: valueRestriction.acceptableValueType,
    };
}
function mapExpectedChildren(nesteds) {
    if (!nesteds || nesteds.length === 0) {
        return undefined;
    }
    var expectedChildren = {};
    nesteds.forEach(function (n) {
        expectedChildren[n.componentName] = {
            isCollectionItem: !!n.isCollectionItem,
            optionName: n.optionName,
        };
    });
    return expectedChildren;
}
//# sourceMappingURL=generator.js.map