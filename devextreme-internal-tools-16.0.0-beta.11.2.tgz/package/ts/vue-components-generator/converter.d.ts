import { ICustomType, ITypeDescr } from '../../integration-data-model';
declare function convertTypes(types: ITypeDescr[] | undefined | null, customTypes?: Record<string, ICustomType>): string[] | undefined;
export { convertTypes };
