import { ICustomType, IModel, IWidget } from '../../integration-data-model';
import { IImport, IComponent } from './component-generator';
declare function generate(rawData: IModel, { createComponentFn, prepareComponentConfigFn, prepareExtensionComponentConfigFn, prepareConfigurationComponentConfigFn, }: Record<string, IImport>, out: {
    componentsDir: string;
    indexFileName: string;
}, widgetsPackage: string, vueVersion: number, generateReexports?: boolean): void;
declare function mapWidget(raw: IWidget, createComponentFn: IImport, prepareComponentConfigFn: IImport, prepareConfigurationComponentConfigFn: IImport, customTypes: ICustomType[]): {
    fileName: string;
    component: IComponent;
};
export { generate, mapWidget, };
