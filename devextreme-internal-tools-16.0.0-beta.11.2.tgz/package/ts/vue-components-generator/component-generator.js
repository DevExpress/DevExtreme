"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderProps = exports.USE_SYNC_TEMPLATES = void 0;
var helpers_1 = require("./helpers");
var template_1 = require("../components-generation/template");
exports.USE_SYNC_TEMPLATES = new Set([
    'DxScheduler',
    'DxDataGrid',
    'DxTreeList',
]);
function generate(component, widgetsPackage, vueVersion, renderReexports) {
    if (widgetsPackage === void 0) { widgetsPackage = 'devextreme'; }
    if (vueVersion === void 0) { vueVersion = 3; }
    if (renderReexports === void 0) { renderReexports = false; }
    var nestedComponents = component.nestedComponents
        ? component.nestedComponents.map(createNestedComponentModel)
        : undefined;
    var namedExports = [component.name];
    if (nestedComponents && nestedComponents.length) {
        namedExports.push.apply(namedExports, nestedComponents.map(function (c) { return c.name; }));
    }
    var componentModel = __assign(__assign({}, component), { widgetImport: component.widgetComponent, component: component.name, renderedProps: component.props
            ? renderProps(component.props)
            : undefined, nestedComponents: nestedComponents, defaultExport: component.name, namedExports: namedExports, expectedChildren: formatExpectedChildren(component.expectedChildren), widgetsPackage: widgetsPackage, templatesRenderAsynchronously: !exports.USE_SYNC_TEMPLATES.has(component.name), isVue3: vueVersion === 3, renderReexports: renderReexports && component.containsReexports });
    return renderComponent(componentModel);
}
function createNestedComponentModel(component) {
    var predefinedProps;
    if (component.predefinedProps) {
        predefinedProps = Object.keys(component.predefinedProps).map(function (name) { return ({
            name: name,
            value: component.predefinedProps && component.predefinedProps[name],
        }); });
    }
    return {
        name: component.name,
        optionName: component.optionName,
        renderedProps: component.props
            ? renderProps(component.props)
            : undefined,
        props: component.props ? getPropsList(component.props) : undefined,
        isCollectionItem: component.isCollectionItem,
        expectedChildren: formatExpectedChildren(component.expectedChildren),
        predefinedProps: predefinedProps,
    };
}
function formatExpectedChildren(dict) {
    if (!dict) {
        return undefined;
    }
    return Object.keys(dict).map(function (name) { return ({
        name: name,
        isCollectionItem: dict[name].isCollectionItem,
        optionName: dict[name].optionName,
    }); });
}
var renderComponent = (0, template_1.createTemplate)("".concat('<#? it.hasExplicitTypes #>'
    + 'export { ExplicitTypes } from "<#= it.widgetsPackage #>/<#= it.widgetImport.path #>";\n'
    + '<#?#>'
    + 'import <#= it.widgetImport.name #><#? it.props #>, { Properties }<#?#> from "<#= it.widgetsPackage #>/<#= it.widgetImport.path #>";\n'
    + 'import { <#= it.createComponentFn.name #> } from "<#= it.createComponentFn.path #>";\n'
    + 'import { <#= it.prepareComponentConfigFn.name #> } from "<#= it.prepareComponentConfigFn.path #>";\n'
    + '<#? it.nestedComponents #>'
    + 'import { <#= it.prepareConfigurationComponentConfigFn.name #> } from "<#= it.prepareConfigurationComponentConfigFn.path #>";\n'
    + '<#?#>'
    + '\n'
    + '<#? it.props #>'
    + 'type AccessibleOptions = Pick<Properties,'
    + '<#~ it.props: prop #>').concat(template_1.L1, "\"<#= prop.name #>\" |")
    + '<#~#>'
    + '\b\b\n>;\n\n'
    + '<#?#>'
    + "interface <#= it.component #><#? it.props #> extends AccessibleOptions<#?#> {".concat(template_1.L1, "readonly instance?: <#= it.widgetImport.name #>;\n")
    + '}\n\n'
    + 'const componentConfig = {'
    + "<#? it.props #>".concat(template_1.L1, "props: {\n")
    + "<#= it.renderedProps #>".concat(template_1.L1, "},")
    + '<#?#>'
    + "<#? it.props #>".concat(template_1.L1, "emits: {").concat(template_1.L2, "\"update:isActive\": null,").concat(template_1.L2, "\"update:hoveredElement\": null,")
    + "<#~ it.props: prop #>".concat(template_1.L2, "\"update:<#= prop.name #>\": null,")
    + "<#~#>".concat(template_1.L1, "},")
    + '<#?#>'
    + "<#? it.hasModel #>".concat(template_1.L1, "model: { prop: \"value\", event: \"update:value\" },")
    + "<#?#>".concat(template_1.L1, "computed: {").concat(template_1.L2, "instance(): <#= it.widgetImport.name #> {").concat(template_1.L3, "return (this as any).$_instance;").concat(template_1.L2, "}").concat(template_1.L1, "},").concat(template_1.L1, "beforeCreate() {").concat(template_1.L2, "(this as any).$_WidgetClass = <#= it.widgetImport.name #>;")
    + "<#? it.isVue3 #>".concat(template_1.L2, "(this as any).$_hasAsyncTemplate = <#= it.templatesRenderAsynchronously #>;")
    + '<#?#>'
    + "<#? it.expectedChildren #>".concat(template_1.L2, "(this as any).$_expectedChildren = {")
    + "<#~ it.expectedChildren : child #>".concat(template_1.L3, "<#= child.name #>: { isCollectionItem: <#= child.isCollectionItem #>, optionName: \"<#= child.optionName #>\" },")
    + '<#~#>' + "\b".concat(template_1.L2, "};")
    + "<#?#>".concat(template_1.L1, "}").concat(template_1.L0, "};\n\n")
    + '<#= it.prepareComponentConfigFn.name #>(componentConfig);\n\n'
    + 'const <#= it.component #> = <#= it.createComponentFn.name #>(componentConfig);\n\n'
    + '<#? it.nestedComponents #>'
    + '<#~ it.nestedComponents : nested #>\n'
    + 'const <#= nested.name #>Config = {'
    + "<#? nested.props #>".concat(template_1.L1, "emits: {").concat(template_1.L2, "\"update:isActive\": null,").concat(template_1.L2, "\"update:hoveredElement\": null,")
    + "<#~ nested.props: prop #>".concat(template_1.L2, "\"update:<#= prop #>\": null,")
    + "<#~#>".concat(template_1.L1, "},")
    + "<#?#>".concat(template_1.L1, "props: {\n")
    + "<#= nested.renderedProps #>".concat(template_1.L1, "}\n")
    + '};\n\n'
    + '<#= it.prepareConfigurationComponentConfigFn.name #>(<#= nested.name #>Config);\n\n'
    + 'const <#= nested.name #> = <#= it.createComponentFn.name #>(<#= nested.name #>Config);\n\n'
    + '(<#= nested.name #> as any).$_optionName = "<#= nested.optionName #>";\n'
    + '<#? nested.isCollectionItem #>'
    + '(<#= nested.name #> as any).$_isCollectionItem = true;\n'
    + '<#?#>'
    + '<#? nested.predefinedProps #>'
    + '(<#= nested.name #> as any).$_predefinedProps = {'
    + "<#~ nested.predefinedProps : prop #>".concat(template_1.L1, "<#= prop.name #>: \"<#= prop.value #>\",")
    + '<#~#>' + '\b\n'
    + '};\n'
    + '<#?#>'
    + '<#? nested.expectedChildren #>'
    + '(<#= nested.name #> as any).$_expectedChildren = {'
    + "<#~ nested.expectedChildren : child #>".concat(template_1.L1, "<#= child.name #>: { isCollectionItem: <#= child.isCollectionItem #>, optionName: \"<#= child.optionName #>\" },")
    + '<#~#>' + '\b\n'
    + '};\n'
    + '<#?#>'
    + '<#~#>'
    + '\n<#?#>'
    + '<#? it.defaultExport #>'
    + 'export default <#= it.defaultExport #>;\n'
    + '<#?#>'
    + 'export {'
    + "<#~ it.namedExports :namedExport #>".concat(template_1.L1, "<#= namedExport #>,")
    + '<#~#>' + '\b' + '\n'
    + '};\n'
    + '<#? it.renderReexports #>'
    + 'import type * as <#= it.component #>Types from "<#= it.widgetsPackage #>/<#= it.widgetImport.path #>_types";\n'
    + 'export { <#= it.component #>Types };\n'
    + '<#?#>');
function compareProps(a, b) {
    return (0, helpers_1.compareStrings)(a.name, b.name);
}
function getPropsList(props) {
    return props.map(function (item) { return item.name; });
}
function renderProps(props) {
    return renderPropsTemplate(props.sort(compareProps));
}
exports.renderProps = renderProps;
var renderPropsTemplate = (0, template_1.createTemplate)("<#~ it :prop #>".concat(template_1.TAB2, "<#? prop.types && prop.types.length > 0 && !prop.acceptableValues #>")
    + '<#= prop.name #>: '
    + '<#? prop.types.length > 1 #>' + '[' + '<#?#>'
    + '<#= prop.types.join(\', \') #>'
    + '<#? prop.types.length > 1 #>' + ']' + '<#?#>'
    + '<#??#>'
    + '<#= prop.name #>: {'
    + "<#? prop.types #>".concat(template_1.L3, "type: ")
    + '<#? prop.types.length > 1 #>' + '[' + '<#?#>'
    + '<#= prop.types.join(\', \') #>'
    + '<#? prop.types.length > 1 #>' + ']' + '<#?#>'
    + '<#?#>'
    + '<#? prop.acceptableValues #>'
    + ",".concat(template_1.L3, "validator: (v) => ")
    + '<#? prop.isArray #>'
    + '!Array.isArray(v) || v.filter(i => ['
    + "<#~ prop.acceptableValues : value #>".concat(template_1.L4, "<#= value #>,")
    + '<#~#>' + "\b".concat(template_1.L3, "].indexOf(i) === -1).length === 0")
    + '<#??#>'
    + 'typeof(v) !== '
    + '<#? prop.acceptableValueType #>'
    + '"<#= prop.acceptableValueType #>"'
    + '<#??#>'
    + '"string"'
    + '<#?#>'
    + ' || ['
    + "<#~ prop.acceptableValues : value #>".concat(template_1.L4, "<#= value #>,")
    + '<#~#>' + "\b".concat(template_1.L3, "].indexOf(v) !== -1")
    + "<#?#>".concat(template_1.L2, "<#?#>")
    + '}'
    + '<#?#>,\n'
    + '<#~#>' + '\b\b');
exports.default = generate;
//# sourceMappingURL=component-generator.js.map