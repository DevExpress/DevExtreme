"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var template_1 = require("./template");
var render = (0, template_1.createTemplate)("<#~ it.reexports :reExport #>export {"
    + "<#? it.multiline #>"
    + "<#~ reExport.names: name #>".concat(template_1.L2, "<#= name #>") + ","
    + "<#~#>"
    + "\n"
    + '<#??#>'
    + ' ' + "<#= reExport.names.join(', ') #>" + ' '
    + '<#?#>'
    + "} from <#= it.quotesChar #><#= reExport.path #><#= it.quotesChar #>;\n<#~#>\n".trim());
function generate(reexports, _a) {
    var _b = _a === void 0 ? {} : _a, _c = _b.multiline, multiline = _c === void 0 ? false : _c, _d = _b.quotes, quotes = _d === void 0 ? 'double' : _d;
    return render({ reexports: reexports, multiline: multiline, quotesChar: quotes === 'single' ? "'" : "\"" });
}
exports.default = generate;
//# sourceMappingURL=reexports-generator.js.map