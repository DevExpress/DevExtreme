import { ICustomType, IProp, ITypeDescr } from '../../integration-data-model';
export type ImportOverridesMetadata = {
    importOverrides?: Record<string, string>;
    genericTypes?: Record<string, unknown>;
    defaultImports?: Record<string, string>;
    nameConflictsResolutionNamespaces?: Record<string, string>;
    typeResolutions?: Record<string, string>;
};
export type TypeResolver = (typeDescriptor: ITypeDescr) => string;
export declare enum BaseTypes {
    Any = "any",
    String = "string",
    Date = "Date",
    Number = "number",
    Boolean = "boolean",
    Object = "Record<string, any>",
    RegExp = "RegExp",
    Null = "null",
    True = "true",
    False = "false",
    void = "void"
}
export declare function convertToBaseType(type: string): BaseTypes;
export declare function isNestedOptionArray(prop: IProp): boolean;
export declare function getComplexOptionType(types: ITypeDescr[], resolveCustomType: TypeResolver, { trimTypeParams }: {
    trimTypeParams: boolean;
}): string | undefined;
export declare function createCustomTypeResolver(customTypeHash: Record<string, ICustomType>, importOverridesMetadata: ImportOverridesMetadata, resolveNameConflicts?: (typeName: string, module?: string) => string): [TypeResolver, Record<string, string[]>];
export declare function createCustomTypeHash(customTypes: ICustomType[]): Record<string, ICustomType>;
export type ConflictResolver = (typeName: string, module: string) => string;
export declare function createComponentNamesConflictResolver(nameClassMap: Record<string, string>): [ConflictResolver, Record<string, Record<string, string>>];
