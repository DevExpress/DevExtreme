"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TAB5 = exports.TAB4 = exports.TAB3 = exports.TAB2 = exports.TAB1 = exports.L5 = exports.L4 = exports.L3 = exports.L2 = exports.L1 = exports.L0 = exports.createTemplate = exports.commonTemplateSettings = void 0;
var dot_1 = require("dot");
var commonTemplateSettings = {
    conditional: /\<#\?(\?)?\s*([\s\S]*?)\s*#\>/g,
    define: /\<###\s*([\w\.$]+)\s*(\:|=)([\s\S]+?)##\>/g,
    encode: /\<#!([\s\S]+?)#\>/g,
    evaluate: /\<#([\s\S]+?)#\>/g,
    interpolate: /\<#=([\s\S]+?)#\>/g,
    iterate: /\<#~\s*(?:#\>|([\s\S]+?)\s*\:\s*([\w$]+)\s*(?:\:\s*([\w$]+))?\s*#\>)/g,
    strip: false,
    use: /\<##([\s\S]+?)#\>/g,
    varname: 'it',
};
exports.commonTemplateSettings = commonTemplateSettings;
var defaultSettings = __assign(__assign({}, dot_1.templateSettings), commonTemplateSettings);
var createTemplate = function (templateStr) {
    var templateFunc = (0, dot_1.template)(templateStr, defaultSettings);
    return function (model) { return templateFunc(model)
        .replace(/[\s\S]{1}\x08{1}|[\s\S]{2}\x08{2}|[\s\S]{3}\x08{3}/g, '')
        .replace(/\x08/, ''); };
};
exports.createTemplate = createTemplate;
function tab(i) {
    return Array(i * 2 + 1).join(' ');
}
var L0 = '\n';
exports.L0 = L0;
var L1 = "\n".concat(tab(1));
exports.L1 = L1;
var L2 = "\n".concat(tab(2));
exports.L2 = L2;
var L3 = "\n".concat(tab(3));
exports.L3 = L3;
var L4 = "\n".concat(tab(4));
exports.L4 = L4;
var L5 = "\n".concat(tab(5));
exports.L5 = L5;
var TAB1 = tab(1);
exports.TAB1 = TAB1;
var TAB2 = tab(2);
exports.TAB2 = TAB2;
var TAB3 = tab(3);
exports.TAB3 = TAB3;
var TAB4 = tab(4);
exports.TAB4 = TAB4;
var TAB5 = tab(5);
exports.TAB5 = TAB5;
//# sourceMappingURL=template.js.map