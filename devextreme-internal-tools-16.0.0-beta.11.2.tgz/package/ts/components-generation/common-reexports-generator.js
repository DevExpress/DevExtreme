"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateCommonReexports = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var reexports_generator_1 = require("./reexports-generator");
function generateCommonReexports(_a) {
    var componentsDir = _a.componentsDir, widgetsPackage = _a.widgetsPackage, commonReexports = _a.commonReexports;
    var commonTargetFolderName = 'common';
    var commonPath = (0, path_1.join)(componentsDir, commonTargetFolderName);
    if (!(0, fs_1.existsSync)(commonPath)) {
        (0, fs_1.mkdirSync)(commonPath);
    }
    Object.keys(commonReexports).forEach(function (key) {
        var targetFileName = key === commonTargetFolderName ? 'index.ts' : "".concat(key.replace("".concat(commonTargetFolderName, "/"), ''), ".ts");
        var fullPath = (0, path_1.join)(commonPath, targetFileName);
        (0, fs_1.mkdirSync)((0, path_1.dirname)(fullPath), { recursive: true });
        (0, fs_1.writeFileSync)(fullPath, (0, reexports_generator_1.default)([
            {
                names: commonReexports[key],
                path: "".concat(widgetsPackage, "/").concat(key),
            },
        ], { multiline: true }), { encoding: 'utf8' });
    });
}
exports.generateCommonReexports = generateCommonReexports;
//# sourceMappingURL=common-reexports-generator.js.map