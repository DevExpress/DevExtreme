import { IModel } from '../../integration-data-model';
export declare function generateCommonReexports({ componentsDir, widgetsPackage, commonReexports, }: {
    componentsDir: string;
    widgetsPackage: string;
    commonReexports: IModel['commonReexports'];
}): void;
