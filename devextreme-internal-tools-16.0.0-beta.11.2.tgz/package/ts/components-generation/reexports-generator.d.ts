interface IReExport {
    names: string[];
    path: string;
}
declare function generate(reexports: IReExport[], { multiline, quotes }?: {
    multiline?: boolean;
    quotes?: 'single' | 'double';
}): string;
export default generate;
export { IReExport, };
