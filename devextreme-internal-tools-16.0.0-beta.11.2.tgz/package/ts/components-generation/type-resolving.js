"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createComponentNamesConflictResolver = exports.createCustomTypeHash = exports.createCustomTypeResolver = exports.getComplexOptionType = exports.isNestedOptionArray = exports.convertToBaseType = exports.BaseTypes = void 0;
var helpers_1 = require("../react-components-generator/helpers");
var UNKNOWN_MODULE = 'UNKNOWN_MODULE';
var LOCAL_MODULE = 'LOCAL_MODULE';
var BaseTypes;
(function (BaseTypes) {
    BaseTypes["Any"] = "any";
    BaseTypes["String"] = "string";
    BaseTypes["Date"] = "Date";
    BaseTypes["Number"] = "number";
    BaseTypes["Boolean"] = "boolean";
    BaseTypes["Object"] = "Record<string, any>";
    BaseTypes["RegExp"] = "RegExp";
    BaseTypes["Null"] = "null";
    BaseTypes["True"] = "true";
    BaseTypes["False"] = "false";
    BaseTypes["void"] = "void";
})(BaseTypes || (exports.BaseTypes = BaseTypes = {}));
function isFunctionDescriptor(typeDescriptor) {
    return typeDescriptor.type === 'Function';
}
function isArrayDescriptor(typeDescriptor) {
    return typeDescriptor.type === 'Array';
}
function isObjectDescriptor(typeDescriptor) {
    return typeDescriptor.type === 'Object' && typeDescriptor.fields !== undefined;
}
function convertToBaseType(type) {
    return BaseTypes[type];
}
exports.convertToBaseType = convertToBaseType;
function isNestedOptionArray(prop) {
    return (0, helpers_1.isNotEmptyArray)(prop.types) && (prop.types[0].type === 'Array');
}
exports.isNestedOptionArray = isNestedOptionArray;
function getComplexOptionType(types, resolveCustomType, _a) {
    var trimTypeParams = _a.trimTypeParams;
    function formatTypeDescriptor(typeDescriptor) {
        function formatArrayDescriptor(arrayDescriptor) {
            var _a;
            var filteredDescriptors = (_a = arrayDescriptor.itemTypes) === null || _a === void 0 ? void 0 : _a.map(function (t) { return formatTypeDescriptor(t); }).filter(function (t) { return t !== undefined; });
            var itemTypes = filteredDescriptors && filteredDescriptors.length
                ? Array.from(new Set(filteredDescriptors)).join(' | ')
                : BaseTypes.Any;
            return "Array<".concat(itemTypes, ">");
        }
        function formatFunctionDescriptor(functionDescriptor) {
            var _a;
            var parameters = ((_a = functionDescriptor.params) === null || _a === void 0 ? void 0 : _a.map(function (p) {
                var parameterType = getComplexOptionType(p.types, resolveCustomType, { trimTypeParams: trimTypeParams })
                    || BaseTypes.Any;
                return "".concat(p.name, ": ").concat(parameterType === BaseTypes.Object ? BaseTypes.Any : parameterType);
            }).join(', ')) || '';
            var returnType = functionDescriptor.returnValueTypes
                ? functionDescriptor.returnValueTypes.map(function (t) { return formatTypeDescriptor(t); }).join(' | ')
                : BaseTypes.Any;
            return "(".concat(parameters, ") => ").concat(returnType);
        }
        function formatObjectDescriptor(objectDescriptor) {
            var fields = objectDescriptor.fields.map(function (f) { return "".concat(f.name, ": ").concat(getComplexOptionType(f.types, resolveCustomType, { trimTypeParams: trimTypeParams }) || BaseTypes.Any); });
            return fields ? "{ ".concat(fields.join(', '), " }") : BaseTypes.Object;
        }
        if (isArrayDescriptor(typeDescriptor)) {
            return formatArrayDescriptor(typeDescriptor);
        }
        if (isFunctionDescriptor(typeDescriptor)) {
            var result = formatFunctionDescriptor(typeDescriptor);
            return "(".concat(result, ")");
        }
        if (isObjectDescriptor(typeDescriptor)) {
            return formatObjectDescriptor(typeDescriptor);
        }
        if (typeDescriptor.acceptableValues !== undefined
            && typeDescriptor.acceptableValues.length > 0) {
            return Array.from(new Set(typeDescriptor.acceptableValues)).join(' | ');
        }
        if ((typeDescriptor.isCustomType || typeDescriptor.isImportedType) && resolveCustomType) {
            var resolvedType = resolveCustomType(typeDescriptor);
            if (typeDescriptor.typeParams && !trimTypeParams) {
                var typeArguments = typeDescriptor.typeParams.length
                    ? "<".concat(typeDescriptor.typeParams.join(', '), ">")
                    : '';
                return "".concat(resolvedType).concat(typeArguments);
            }
            return resolvedType;
        }
        return convertToBaseType(typeDescriptor.type);
    }
    return types && (0, helpers_1.isNotEmptyArray)(types) ? Array.from(new Set(types))
        .map(function (t) { return formatTypeDescriptor(t); })
        .filter(function (t) { return t !== undefined; })
        .join(' | ') : undefined;
}
exports.getComplexOptionType = getComplexOptionType;
function createCustomTypeResolver(customTypeHash, importOverridesMetadata, resolveNameConflicts) {
    if (resolveNameConflicts === void 0) { resolveNameConflicts = function (typeName) { return typeName; }; }
    var customTypeModulesCollector = {};
    return [function (typeDescriptor) {
            var _a, _b, _c;
            var resolvedType = ((_a = importOverridesMetadata.typeResolutions) === null || _a === void 0 ? void 0 : _a[typeDescriptor.type])
                || typeDescriptor.type;
            var customType = customTypeHash[resolvedType];
            var moduleImport = typeDescriptor.type === resolvedType && typeDescriptor.isImportedType
                ? typeDescriptor.importPath
                : customType && customType.module;
            var fullModuleImport = moduleImport ? "devextreme/".concat(moduleImport) : UNKNOWN_MODULE;
            customTypeModulesCollector[resolvedType] = __spreadArray(__spreadArray([], (customTypeModulesCollector[resolvedType] || []), true), [
                fullModuleImport,
            ], false);
            var resultingType = ((_b = importOverridesMetadata.nameConflictsResolutionNamespaces) === null || _b === void 0 ? void 0 : _b[resolvedType])
                ? "".concat(importOverridesMetadata.nameConflictsResolutionNamespaces[resolvedType], ".").concat(resolvedType)
                : resolveNameConflicts(resolvedType, fullModuleImport);
            return ((_c = importOverridesMetadata.genericTypes) === null || _c === void 0 ? void 0 : _c[resultingType]) ? "".concat(resultingType, "<any>") : resultingType;
        }, customTypeModulesCollector];
}
exports.createCustomTypeResolver = createCustomTypeResolver;
function createCustomTypeHash(customTypes) {
    return customTypes.reduce(function (result, type) {
        result[type.name] = type;
        return result;
    }, {});
}
exports.createCustomTypeHash = createCustomTypeHash;
function createComponentNamesConflictResolver(nameClassMap) {
    var existingTypes = Object.values(nameClassMap)
        .reduce(function (result, current) {
        result[current] = [LOCAL_MODULE];
        return result;
    }, {});
    var typeAliases = {};
    return [function (typeName, module) {
            var _a;
            if (module === void 0) { module = UNKNOWN_MODULE; }
            var existingTypeEntry = existingTypes[typeName] || [];
            var isModuleProcessed = existingTypeEntry.includes(module);
            var isConflicted = existingTypeEntry.length && (existingTypeEntry[0] === LOCAL_MODULE || !isModuleProcessed);
            if (!isModuleProcessed) {
                existingTypeEntry.push(module);
                existingTypes[typeName] = existingTypeEntry;
            }
            if (isConflicted) {
                var typePrefix = module === UNKNOWN_MODULE || !module.length
                    ? 'Aliased'
                    : module
                        .substring(module.lastIndexOf('/') + 1)
                        .split(/[-_]+/)
                        .map(function (s) { return (s.charAt(0).toUpperCase() + s.slice(1)); })
                        .join('');
                var aliasedTypeName = "".concat(typePrefix).concat(typeName);
                var moduleKey = module && module.length ? module : UNKNOWN_MODULE;
                typeAliases[typeName] = __assign(__assign({}, (typeAliases[typeName] || {})), (_a = {}, _a[moduleKey] = aliasedTypeName, _a));
                return aliasedTypeName;
            }
            return typeName;
        }, typeAliases];
}
exports.createComponentNamesConflictResolver = createComponentNamesConflictResolver;
//# sourceMappingURL=type-resolving.js.map