"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensureArgs = exports.stringifyNetcoreArgs = exports.stringifyArgs = exports.parseArgs = void 0;
var shelljs_1 = require("shelljs");
var helpers_1 = require("./helpers");
var logging_1 = require("../logging");
var utils_1 = require("../common/utils");
var argsMap = {
    artifacts: 'artifacts',
    collapseTags: 'collapse-tags',
    docsRoot: 'docs-root-path',
    sources: 'sources',
    version: 'version',
    declarations: 'declarations-path',
    output: 'output-path',
    target: 'target-path',
    tsOnly: 'ts',
    searchPattern: 'search-pattern',
    exclude: 'exclude',
    enumsJson: 'enums-path',
    contentMap: 'content-map-path',
    validateOnly: 'validate',
    descriptions: 'descriptions-path',
    toolsVersion: 'tools-version',
    modulesMeta: 'modules-meta-path',
    modulesGuide: 'modules-guide-path',
    syntaxMeta: 'syntax-meta-path',
    compilerOptions: 'compiler-options',
};
function parseArgs(rawArgs) {
    var normalizedArgs = rawArgs.map(function (arg) { return ((0, utils_1.isEscapedUncPath)(arg) ? (0, utils_1.revertEscaping)(arg) : arg); });
    var allArgs = {
        artifacts: helpers_1.paths.artifactsDir,
    };
    for (var argKey in argsMap) {
        var indexKey = normalizedArgs.indexOf("--".concat(argsMap[argKey]));
        if (indexKey !== -1) {
            allArgs[argKey] = normalizedArgs[indexKey + 1] || 'true';
        }
    }
    return allArgs;
}
exports.parseArgs = parseArgs;
function stringifyArgs(args) {
    return stringifyNetcoreArgs(args, argsMap);
}
exports.stringifyArgs = stringifyArgs;
function stringifyNetcoreArgs(args, namesMap) {
    return Object.keys(args)
        .filter(function (argName) { return args[argName]; })
        .map(function (argName) { return "--".concat(namesMap[argName], "=\"").concat(args[argName], "\""); })
        .join(' ');
}
exports.stringifyNetcoreArgs = stringifyNetcoreArgs;
function ensureArgs(args, keys) {
    var result = {};
    var missingKeys = [];
    if (keys.required) {
        for (var _i = 0, _a = keys.required; _i < _a.length; _i++) {
            var key = _a[_i];
            var value = args[key];
            if (typeof value === 'string') {
                result[key] = parse(key, value);
            }
            else {
                missingKeys.push(key);
            }
        }
    }
    if (missingKeys.length > 0) {
        (0, logging_1.log)("Args missing: ".concat(missingKeys.map(function (k) { return argsMap[k]; }).join(', ')), { lvl: 'error' });
        (0, shelljs_1.exit)(1);
    }
    if (keys.optional) {
        for (var _b = 0, _c = keys.optional; _b < _c.length; _b++) {
            var key = _c[_b];
            var value = args[key];
            if (typeof value === 'string') {
                result[key] = parse(key, value);
            }
        }
    }
    return result;
}
exports.ensureArgs = ensureArgs;
function parse(key, value) {
    if (key === 'exclude') {
        try {
            return new RegExp(value);
        }
        catch (e) {
            (0, logging_1.log)("".concat(argsMap.exclude, " must be a valid RegExp"), { lvl: 'fatal', e: e });
            throw e;
        }
    }
    if (key === 'compilerOptions') {
        try {
            return JSON.parse(value);
        }
        catch (e) {
            (0, logging_1.log)("".concat(argsMap.compilerOptions, " must be a valid JSON"), { lvl: 'fatal', e: e });
            throw e;
        }
    }
    if (key === 'collapseTags' || key === 'tsOnly') {
        return true;
    }
    return value;
}
//# sourceMappingURL=args.js.map