"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runValidator = exports.runTsDiscoverer = exports.runReexportsGenerator = exports.runModulesGuideValidator = exports.runTopicsValidation = exports.runSyntaxDataGenerator = exports.runSmdGenerator = exports.runNgSmdGenerator = exports.runLinksConverter = exports.runInjector = exports.runImdGenerator = exports.runExtraTopicsGenerator = exports.runDtsBundler = exports.runDocGenerator = exports.runDiscoverers = exports.runCompactDocsCreator = exports.runContentMapGenerator = void 0;
var path_1 = require("path");
var helpers_1 = require("./helpers");
var args_1 = require("./args");
var discovering_1 = require("../discoverer/discovering");
var collapser_1 = require("../collapser/collapser");
var bundler_1 = require("../bundler/bundler");
var logging_1 = require("../logging");
var modules_meta_generator_1 = require("../modules-meta-generator/modules-meta-generator");
var utils_1 = require("../common/utils");
var generator_1 = require("../component-exports-generator/generator");
function runCollapser(allArgs) {
    (0, logging_1.setAreaName)('TS Collapser');
    var logTotal = (0, logging_1.logStart)();
    var args = (0, args_1.ensureArgs)(allArgs, {
        required: ['sources'],
        optional: ['exclude', 'compilerOptions'],
    });
    (0, collapser_1.collapse)(args.sources, args.exclude, args.compilerOptions);
    logTotal();
}
function runContentMapGenerator(args) {
    runNetcoreTool('DevExtreme.WebSite.ContentMapCreator.dll', args);
}
exports.runContentMapGenerator = runContentMapGenerator;
function runCompactDocsCreator(args) {
    runNetcoreTool('DevExtreme.WebSite.CompactDocsCreator.dll', args);
}
exports.runCompactDocsCreator = runCompactDocsCreator;
function runDiscoverers(allArgs) {
    runTsDiscoverer(allArgs);
    var args = (0, args_1.ensureArgs)(allArgs, { optional: ['tsOnly'] });
    if (!args.tsOnly) {
        runNetcoreTool('DevExtreme.Declarations.Discoverer.dll', allArgs);
    }
}
exports.runDiscoverers = runDiscoverers;
function runDocGenerator(args) {
    runNetcoreTool('DevExtreme.Topics.Generator.dll', args);
}
exports.runDocGenerator = runDocGenerator;
function runDtsBundler(allArgs) {
    (0, logging_1.setAreaName)('TS Bundler');
    var logTotal = (0, logging_1.logStart)();
    var args = (0, args_1.ensureArgs)(allArgs, {
        required: ['sources', 'output'],
        optional: ['exclude', 'compilerOptions'],
    });
    (0, helpers_1.deleteFile)(args.output);
    (0, bundler_1.bundle)({
        scriptsDir: args.sources,
        outputFile: args.output,
    }, args.exclude, args.compilerOptions);
    logTotal();
}
exports.runDtsBundler = runDtsBundler;
function runExtraTopicsGenerator(allArgs) {
    runNetcoreTool('DevExtreme.Topics.ExtraFilesGenerator.dll', allArgs);
}
exports.runExtraTopicsGenerator = runExtraTopicsGenerator;
function runImdGenerator(args) {
    runNetcoreTool('DevExtreme.IntegrationDataGenerator.dll', args);
}
exports.runImdGenerator = runImdGenerator;
function runInjector(allArgs) {
    var args = (0, args_1.ensureArgs)(allArgs, { optional: ['collapseTags'] });
    if (args.collapseTags) {
        runCollapser(allArgs);
    }
    runNetcoreTool('DevExtreme.Descriptions.Injector.dll', allArgs);
}
exports.runInjector = runInjector;
function runLinksConverter(args) {
    runNetcoreTool('DevExtreme.WebSite.LinksConverter.dll', args);
}
exports.runLinksConverter = runLinksConverter;
function runNgSmdGenerator(args) {
    runNetcoreTool('DevExtreme.NgSmdGenerator.dll', args);
}
exports.runNgSmdGenerator = runNgSmdGenerator;
function runSmdGenerator(args) {
    runNetcoreTool('DevExtreme.StrongMetaDataGenerator.dll', args);
}
exports.runSmdGenerator = runSmdGenerator;
function runSyntaxDataGenerator(args) {
    runNetcoreTool('DevExtreme.WebSite.SyntaxDataGenerator.dll', args);
}
exports.runSyntaxDataGenerator = runSyntaxDataGenerator;
function runTopicsValidation(args) {
    runNetcoreTool('DevExtreme.Topics.Validation.dll', args);
}
exports.runTopicsValidation = runTopicsValidation;
function runModulesGuideValidator(args) {
    runNetcoreTool('DevExtreme.Topics.ModulesGuideValidator.dll', args);
}
exports.runModulesGuideValidator = runModulesGuideValidator;
function runReexportsGenerator(allArgs) {
    (0, logging_1.setAreaName)('Reexports generation');
    var logTotal = (0, logging_1.logStart)();
    var args = (0, args_1.ensureArgs)(allArgs, { required: ['sources'], optional: ['exclude', 'compilerOptions'] });
    var fileNames = (0, utils_1.enumerateFiles)(args.sources, '(ui|viz)[\\\\/]([^\\\\/]+(?<!(_types(.d)?)).ts)$', args.exclude);
    (0, generator_1.generateComponentReexports)(fileNames, args.compilerOptions);
    logTotal();
}
exports.runReexportsGenerator = runReexportsGenerator;
function runTsDiscoverer(allArgs) {
    (0, logging_1.setAreaName)('TS Declarations Discovering');
    var logTotal = (0, logging_1.logStart)();
    var args = (0, args_1.ensureArgs)(allArgs, { required: ['sources', 'artifacts'], optional: ['exclude', 'compilerOptions'] });
    var modulesMetaPath = (0, path_1.join)(args.artifacts, 'modules-meta.json');
    var tsMetaPath = (0, path_1.join)(args.artifacts, 'ts-members-meta.json');
    var fileExtension = '.ts';
    var fileNames = (0, utils_1.enumerateFiles)(args.sources, fileExtension, args.exclude);
    (0, logging_1.log)("".concat(fileNames.length, " files discovered"));
    (0, helpers_1.deleteFile)(modulesMetaPath);
    (0, modules_meta_generator_1.generateModulesMeta)(fileNames, args.sources, modulesMetaPath, args.compilerOptions, allArgs.toolsVersion);
    (0, helpers_1.deleteFile)(tsMetaPath);
    (0, discovering_1.discover)(fileNames, args.sources, tsMetaPath, allArgs.toolsVersion, args.compilerOptions);
    logTotal();
}
exports.runTsDiscoverer = runTsDiscoverer;
function runValidator(args) {
    runNetcoreTool('DevExtreme.Declarations.IntegrityValidator.dll', args);
}
exports.runValidator = runValidator;
function runNetcoreTool(dllName, args) {
    var dllPath = (0, path_1.join)(helpers_1.paths.binDir, dllName);
    var toolName = dllName.replace(/^DevExtreme\.(.*)\.dll$/i, '$1');
    (0, helpers_1.exec)("dotnet \"".concat(dllPath, "\" ").concat((0, args_1.stringifyArgs)(args)));
    (0, logging_1.log)("".concat(toolName, " OK"));
}
//# sourceMappingURL=tools.js.map