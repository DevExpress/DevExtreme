import { CompilerOptions } from 'typescript';
interface Args {
    artifacts: string;
    docsRoot?: string;
    sources?: string;
    version?: string;
    declarations?: string;
    output?: string;
    target?: string;
    searchPattern?: string;
    exclude?: RegExp;
    enumsJson?: string;
    contentMap?: string;
    validateOnly?: string;
    descriptions?: string;
    toolsVersion?: string;
    modulesMeta?: string;
    modulesGuide?: string;
    syntaxMeta?: string;
    compilerOptions?: CompilerOptions;
    collapseTags?: boolean;
    tsOnly?: boolean;
}
type ArgKeys = keyof Args;
type ArgsMap = {
    [key in ArgKeys]: string;
};
export type RawArgs = Partial<ArgsMap> & Pick<ArgsMap, 'artifacts'>;
export declare function parseArgs(rawArgs: string[]): RawArgs;
export declare function stringifyArgs(args: Partial<ArgsMap>): string;
export declare function stringifyNetcoreArgs<TKey extends PropertyKey>(args: Partial<Record<TKey, any>>, namesMap: Record<TKey, string>): string;
export declare function ensureArgs<TRequired extends ArgKeys, TOptional extends ArgKeys = never>(args: RawArgs, keys: {
    required?: TRequired[];
    optional?: TOptional[];
}): TFilteredArgs<TRequired, TOptional>;
type TFilteredArgs<TRequired extends ArgKeys, TOptional extends ArgKeys> = Required<Pick<Args, TRequired>> & Partial<Pick<Args, TOptional>>;
export {};
