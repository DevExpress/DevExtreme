export declare const paths: {
    binDir: string;
    workDir: string;
    jsDir: string;
    artifactsDir: string;
};
export declare function getPackageMajorVersion(): string | undefined;
export declare function deleteFile(path: string): void;
export declare function ensureDir(path: string): void;
export declare function exec(command: string): void;
