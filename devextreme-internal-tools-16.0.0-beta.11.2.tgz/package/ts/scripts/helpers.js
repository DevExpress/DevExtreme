"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exec = exports.ensureDir = exports.deleteFile = exports.getPackageMajorVersion = exports.paths = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var shelljs_1 = require("shelljs");
var logging_1 = require("../logging");
function getAllPaths() {
    var workDir = process.cwd();
    var binDir = (0, path_1.join)(__dirname, '../../bin');
    return {
        binDir: binDir,
        workDir: workDir,
        jsDir: (0, path_1.join)(workDir, 'js'),
        artifactsDir: (0, path_1.join)(workDir, 'artifacts', 'internal-tools'),
    };
}
exports.paths = getAllPaths();
function getPackageMajorVersion() {
    var packageContent = (0, fs_1.readFileSync)((0, path_1.join)(exports.paths.workDir, 'package.json')).toString();
    var packageInfo = JSON.parse(packageContent);
    if (!packageInfo)
        return undefined;
    return packageInfo.version.substring(0, 'XX.X'.length);
}
exports.getPackageMajorVersion = getPackageMajorVersion;
function deleteFile(path) {
    if ((0, fs_1.existsSync)(path)) {
        (0, fs_1.unlinkSync)(path);
    }
}
exports.deleteFile = deleteFile;
function ensureDir(path) {
    if (!(0, fs_1.existsSync)(path)) {
        (0, fs_1.mkdirSync)(path, { recursive: true });
    }
}
exports.ensureDir = ensureDir;
function exec(command) {
    var proc = (0, shelljs_1.exec)(command, { silent: true });
    if (proc.code !== 0) {
        (0, logging_1.log)(proc.stdout, { lvl: 'info' });
        (0, logging_1.log)(proc.stderr, { lvl: 'error' });
        (0, shelljs_1.exit)(proc.code);
    }
}
exports.exec = exec;
//# sourceMappingURL=helpers.js.map