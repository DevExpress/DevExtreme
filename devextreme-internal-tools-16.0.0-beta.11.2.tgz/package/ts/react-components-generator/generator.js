"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generate = exports.mapWidget = exports.collectSubscribableRecursively = exports.collectIndependentEvents = exports.extractNestedComponents = exports.mapOption = exports.mapConfigComponentOption = exports.mapRootComponentOption = exports.isNestedOptionArray = exports.mapIndependentEvents = exports.mapSubscribableOption = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var defaultImportOverridesMetadata = require("./import-overrides.json");
var index_generator_1 = require("./index-generator");
var component_generator_1 = require("./component-generator");
var helpers_1 = require("./helpers");
var common_reexports_generator_1 = require("../components-generation/common-reexports-generator");
var type_resolving_1 = require("../components-generation/type-resolving");
var UNKNOWN_MODULE = 'UNKNOWN_MODULE';
function mapSubscribableOption(prop, typeResolver) {
    return {
        name: prop.name,
        type: (0, type_resolving_1.getComplexOptionType)(prop.types, typeResolver, { trimTypeParams: false }) || type_resolving_1.BaseTypes.Any,
        isSubscribable: prop.isSubscribable || undefined,
    };
}
exports.mapSubscribableOption = mapSubscribableOption;
function mapIndependentEvents(prop) {
    return {
        name: prop.name,
    };
}
exports.mapIndependentEvents = mapIndependentEvents;
function isNestedOptionArray(prop) {
    return (0, helpers_1.isNotEmptyArray)(prop.types) && (prop.types[0].type === 'Array');
}
exports.isNestedOptionArray = isNestedOptionArray;
function mapRootComponentOption(prop, typeResolver) {
    return mapOption(prop, false, typeResolver);
}
exports.mapRootComponentOption = mapRootComponentOption;
function mapConfigComponentOption(prop, typeResolver) {
    return mapOption(prop, true, typeResolver);
}
exports.mapConfigComponentOption = mapConfigComponentOption;
function mapOption(prop, trimTypeParams, typeResolver) {
    return (0, helpers_1.isEmptyArray)(prop.props)
        ? {
            name: prop.name,
            type: (0, type_resolving_1.getComplexOptionType)(prop.types, typeResolver, { trimTypeParams: trimTypeParams }) || type_resolving_1.BaseTypes.Any,
            isSubscribable: prop.isSubscribable || undefined,
        } : {
        name: prop.name,
        isSubscribable: prop.isSubscribable || undefined,
        type: (0, type_resolving_1.getComplexOptionType)(prop.types, typeResolver, { trimTypeParams: trimTypeParams }),
        nested: prop.props
            .map(function (p) { return mapOption(p, trimTypeParams, typeResolver); }),
        isArray: isNestedOptionArray(prop),
    };
}
exports.mapOption = mapOption;
function getWidgetComponentNames(rawWidgetName, widgetName, props) {
    var nameClassMap = {};
    nameClassMap[rawWidgetName] = widgetName;
    props.forEach(function (p) {
        nameClassMap[p.name] = (0, helpers_1.uppercaseFirst)(p.name);
    });
    return nameClassMap;
}
function extractNestedComponents(props, rawWidgetName, widgetName, typeResolver) {
    var nameClassMap = getWidgetComponentNames(rawWidgetName, widgetName, props);
    return props.map(function (p) { return ({
        componentName: nameClassMap[p.name],
        owners: p.owners.map(function (o) { return nameClassMap[o]; }),
        optionName: p.optionName,
        options: p.props.map(function (prop) { return mapConfigComponentOption(prop, typeResolver); }),
        isCollectionItem: p.isCollectionItem,
        templates: p.templates,
        predefinedProps: p.predefinedProps,
        expectedChildren: p.nesteds,
    }); });
}
exports.extractNestedComponents = extractNestedComponents;
function collectIndependentEvents(options) {
    return options.reduce(function (acc, option) {
        if (option.types.filter(function (type) { return type.type === 'Function'; }).length === 1
            && (!option.firedEvents || option.firedEvents.length === 0)
            && option.name.substr(0, 2) === 'on'
            && !option.name.match(/^(?!.*Value).*Changed/)) {
            acc.push(option);
        }
        return acc;
    }, []);
}
exports.collectIndependentEvents = collectIndependentEvents;
function collectSubscribableRecursively(options, prefix) {
    if (prefix === void 0) { prefix = ''; }
    return options.reduce(function (acc, option) {
        var _a;
        if (option.isSubscribable) {
            acc.push(__assign(__assign({}, option), { name: "".concat(prefix).concat(option.name) }));
        }
        if ((_a = option.props) === null || _a === void 0 ? void 0 : _a.length) {
            acc.push.apply(acc, collectSubscribableRecursively(option.props, "".concat(option.name, ".")));
        }
        return acc;
    }, []);
}
exports.collectSubscribableRecursively = collectSubscribableRecursively;
function mapWidget(raw, baseComponent, extensionComponent, configComponent, customTypes, widgetPackage, typeGenerationOptions) {
    var _a;
    var _b, _c;
    var name = (0, helpers_1.removePrefix)(raw.name, 'dx');
    var _d = typeGenerationOptions || {}, importOverridesMetadata = _d.importOverridesMetadata, generateCustomTypes = _d.generateCustomTypes;
    var nameClassMap = getWidgetComponentNames(raw.name, name, raw.complexOptions || []);
    var _e = (0, type_resolving_1.createComponentNamesConflictResolver)(nameClassMap), resolveGeneratedComponentNamesConflict = _e[0], typeAliases = _e[1];
    var getTypeImportStatement = function (typeName, module) {
        var _a;
        if (module === void 0) { module = UNKNOWN_MODULE; }
        return (((_a = typeAliases[typeName]) === null || _a === void 0 ? void 0 : _a[module]) ? "".concat(typeName, " as ").concat(typeAliases[typeName][module]) : typeName);
    };
    var customTypeHash = (0, type_resolving_1.createCustomTypeHash)(customTypes);
    var customTypeModules = {};
    var typeResolver;
    if (generateCustomTypes) {
        _a = (0, type_resolving_1.createCustomTypeResolver)(customTypeHash, importOverridesMetadata || {}, resolveGeneratedComponentNamesConflict), typeResolver = _a[0], customTypeModules = _a[1];
    }
    var subscribableOptions = collectSubscribableRecursively(raw.options)
        .map(function (option) { return mapSubscribableOption(option, typeResolver); });
    var eventOptions = collectIndependentEvents(raw.options);
    var hasNarrowedEventArgument = function (option) { return option.types[0].params[0].types[0].isImportedType; };
    var narrowedEvents = eventOptions
        .filter(hasNarrowedEventArgument)
        .map(function (prop) { return mapRootComponentOption(prop, typeResolver); });
    var independentEvents = eventOptions.map(mapIndependentEvents);
    var nestedOptions = raw.complexOptions
        ? extractNestedComponents(raw.complexOptions, raw.name, name, typeResolver)
        : null;
    var customTypeImports = {};
    var defaultTypeImports = {};
    var wildcardTypeImports = {};
    Object.keys(customTypeModules).forEach(function (t) {
        var _a;
        if ((_a = importOverridesMetadata === null || importOverridesMetadata === void 0 ? void 0 : importOverridesMetadata.defaultImports) === null || _a === void 0 ? void 0 : _a[t]) {
            defaultTypeImports[t] = importOverridesMetadata.defaultImports[t];
            return;
        }
        var modules = customTypeModules[t].map(function (m) { var _a, _b; return ((_b = (_a = importOverridesMetadata === null || importOverridesMetadata === void 0 ? void 0 : importOverridesMetadata.importOverrides) === null || _a === void 0 ? void 0 : _a[t]) !== null && _b !== void 0 ? _b : m); });
        if (modules.length) {
            modules
                .forEach(function (module, index) {
                var _a;
                var importNamespace = (_a = importOverridesMetadata === null || importOverridesMetadata === void 0 ? void 0 : importOverridesMetadata.nameConflictsResolutionNamespaces) === null || _a === void 0 ? void 0 : _a[t];
                if (importNamespace) {
                    wildcardTypeImports[module] = importNamespace;
                }
                else {
                    var moduleImports = new Set(customTypeImports[module]);
                    var initialModule = customTypeModules[t][index];
                    moduleImports.add(getTypeImportStatement(t, initialModule));
                    customTypeImports[module] = Array.from(moduleImports);
                }
            });
        }
    });
    var dxExportPath = "".concat(widgetPackage, "/").concat(raw.exportPath);
    return {
        fileName: "".concat((0, helpers_1.toKebabCase)(name), ".ts"),
        component: {
            name: name,
            baseComponentPath: baseComponent,
            extensionComponentPath: extensionComponent,
            configComponentPath: configComponent,
            dxExportPath: dxExportPath,
            isExtension: raw.isExtension,
            templates: raw.templates,
            subscribableOptions: subscribableOptions.length > 0 ? subscribableOptions : undefined,
            independentEvents: independentEvents.length > 0 ? independentEvents : undefined,
            nestedComponents: nestedOptions && nestedOptions.length > 0 ? nestedOptions : undefined,
            expectedChildren: raw.nesteds,
            optionsTypeParams: raw.optionsTypeParams,
            containsReexports: !!((_c = (_b = raw.reexports) === null || _b === void 0 ? void 0 : _b.filter(function (r) { return r !== 'default'; })) === null || _c === void 0 ? void 0 : _c.length),
            narrowedEvents: narrowedEvents,
        },
        customTypeImports: customTypeImports,
        defaultTypeImports: defaultTypeImports,
        wildcardTypeImports: wildcardTypeImports,
    };
}
exports.mapWidget = mapWidget;
function generate(_a) {
    var rawData = _a.metaData, _b = _a.components, baseComponent = _b.baseComponent, extensionComponent = _b.extensionComponent, configComponent = _b.configComponent, out = _a.out, widgetsPackage = _a.widgetsPackage, _c = _a.typeGenerationOptions, typeGenerationOptions = _c === void 0 ? {} : _c;
    var modulePaths = [];
    var generateReexports = typeGenerationOptions.generateReexports, generateCustomTypes = typeGenerationOptions.generateCustomTypes, importOverridesMetadata = typeGenerationOptions.importOverridesMetadata;
    rawData.widgets.forEach(function (data) {
        var widgetFile = mapWidget(data, baseComponent, extensionComponent, configComponent, rawData.customTypes, widgetsPackage, {
            generateCustomTypes: generateCustomTypes,
            importOverridesMetadata: importOverridesMetadata || defaultImportOverridesMetadata,
        });
        var widgetFilePath = (0, path_1.join)(out.componentsDir, widgetFile.fileName);
        var indexFileDir = (0, path_1.dirname)(out.indexFileName);
        (0, fs_1.writeFileSync)(widgetFilePath, (0, component_generator_1.default)(widgetFile.component, generateReexports, widgetFile.customTypeImports, widgetFile.defaultTypeImports, widgetFile.wildcardTypeImports), { encoding: 'utf8' });
        modulePaths.push({
            names: [widgetFile.component.name],
            path: "./".concat((0, helpers_1.removeExtension)((0, path_1.relative)(indexFileDir, widgetFilePath)).replace(path_1.sep, '/')),
        });
    });
    (0, fs_1.writeFileSync)(out.indexFileName, (0, index_generator_1.default)(modulePaths), { encoding: 'utf8' });
    if (generateReexports && rawData.commonReexports) {
        (0, common_reexports_generator_1.generateCommonReexports)({
            componentsDir: out.componentsDir,
            widgetsPackage: widgetsPackage,
            commonReexports: rawData.commonReexports,
        });
    }
}
exports.generate = generate;
//# sourceMappingURL=generator.js.map