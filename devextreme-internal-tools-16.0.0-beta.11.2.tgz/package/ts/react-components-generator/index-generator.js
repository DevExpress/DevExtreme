"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
var reexports_generator_1 = require("../components-generation/reexports-generator");
function generate(paths) {
    return (0, reexports_generator_1.default)(__spreadArray([
        {
            names: ['Template'],
            path: './core/template',
        }
    ], paths, true));
}
exports.default = generate;
//# sourceMappingURL=index-generator.js.map