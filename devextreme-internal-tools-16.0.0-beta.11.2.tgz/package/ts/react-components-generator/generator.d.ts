import { IComplexProp, ICustomType, IModel, IProp, ITypeDescr, IWidget } from '../../integration-data-model';
import { IComponent, IIndependentEvents, INestedComponent, IOption, ISubscribableOption } from './component-generator';
export type ImportOverridesMetadata = {
    importOverrides?: Record<string, string>;
    genericTypes?: Record<string, unknown>;
    defaultImports?: Record<string, string>;
    nameConflictsResolutionNamespaces?: Record<string, string>;
    typeResolutions?: Record<string, string>;
};
export type TypeResolver = (typeDescriptor: ITypeDescr) => string;
type TypeGenerationOptions = {
    generateReexports?: boolean;
    generateCustomTypes?: boolean;
    importOverridesMetadata?: ImportOverridesMetadata;
};
export declare function mapSubscribableOption(prop: IProp, typeResolver?: TypeResolver): ISubscribableOption;
export declare function mapIndependentEvents(prop: IProp): IIndependentEvents;
export declare function isNestedOptionArray(prop: IProp): boolean;
export declare function mapRootComponentOption(prop: IProp, typeResolver: TypeResolver): IOption;
export declare function mapConfigComponentOption(prop: IProp, typeResolver: TypeResolver): IOption;
export declare function mapOption(prop: IProp, trimTypeParams: boolean, typeResolver?: TypeResolver): IOption;
export declare function extractNestedComponents(props: IComplexProp[], rawWidgetName: string, widgetName: string, typeResolver?: TypeResolver): INestedComponent[];
export declare function collectIndependentEvents(options: IProp[]): IProp[];
export declare function collectSubscribableRecursively(options: IProp[], prefix?: string): IProp[];
export declare function mapWidget(raw: IWidget, baseComponent: string, extensionComponent: string, configComponent: string, customTypes: ICustomType[], widgetPackage: string, typeGenerationOptions?: TypeGenerationOptions): {
    fileName: string;
    component: IComponent;
    customTypeImports?: Record<string, Array<string>>;
    defaultTypeImports?: Record<string, string>;
    wildcardTypeImports?: Record<string, string>;
};
export declare function generate({ metaData: rawData, components: { baseComponent, extensionComponent, configComponent }, out, widgetsPackage, typeGenerationOptions, }: {
    metaData: IModel;
    components: {
        baseComponent: string;
        extensionComponent: string;
        configComponent: string;
    };
    out: {
        componentsDir: string;
        indexFileName: string;
    };
    widgetsPackage: string;
    typeGenerationOptions?: TypeGenerationOptions;
}): void;
export {};
