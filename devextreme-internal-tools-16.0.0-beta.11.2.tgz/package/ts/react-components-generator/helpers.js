"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPlainObject = exports.isNotEmptyArray = exports.isEmptyArray = exports.removeElement = exports.createKeyComparator = exports.compareStrings = exports.lowercaseFirst = exports.uppercaseFirst = exports.toKebabCase = exports.removePrefix = exports.removeExtension = void 0;
var dasherize = require("dasherize");
var path_1 = require("path");
function removeExtension(path) {
    return path.slice(0, -(0, path_1.extname)(path).length);
}
exports.removeExtension = removeExtension;
function removePrefix(value, prefix) {
    return new RegExp("^".concat(prefix), 'i').test(value) ? value.substring(prefix.length) : value;
}
exports.removePrefix = removePrefix;
function toKebabCase(value) {
    return dasherize(value);
}
exports.toKebabCase = toKebabCase;
function uppercaseFirst(value) {
    return value[0].toUpperCase() + value.substr(1);
}
exports.uppercaseFirst = uppercaseFirst;
function lowercaseFirst(value) {
    return value[0].toLowerCase() + value.substr(1);
}
exports.lowercaseFirst = lowercaseFirst;
function compareStrings(a, b) {
    return a.localeCompare(b, undefined, { caseFirst: 'upper' });
}
exports.compareStrings = compareStrings;
function createKeyComparator(keyGetter) {
    return function (a, b) { return compareStrings(keyGetter(a), keyGetter(b)); };
}
exports.createKeyComparator = createKeyComparator;
function removeElement(array, element) {
    var index = array.indexOf(element);
    if (index > -1) {
        array.splice(index, 1);
    }
}
exports.removeElement = removeElement;
function isEmptyArray(array) {
    return array === undefined || array === null || array.length === 0;
}
exports.isEmptyArray = isEmptyArray;
function isNotEmptyArray(array) {
    return !isEmptyArray(array);
}
exports.isNotEmptyArray = isNotEmptyArray;
function isPlainObject(value) {
    return value.constructor === Object;
}
exports.isPlainObject = isPlainObject;
//# sourceMappingURL=helpers.js.map