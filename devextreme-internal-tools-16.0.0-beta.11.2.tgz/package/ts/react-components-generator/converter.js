"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertTypes = void 0;
var helpers_1 = require("./helpers");
var inputTypes = {
    array: 'Array',
    string: 'String',
    date: 'Date',
    number: 'Number',
    object: 'Object',
    regexp: 'RegExp',
    bool: 'Boolean',
    func: 'Function',
};
function expandTypes(types, customTypes) {
    var expandedTypes = [];
    types.forEach(function (t) {
        if (t.isCustomType) {
            var aliases = customTypes[t.type].types;
            if (aliases) {
                expandedTypes.push.apply(expandedTypes, aliases);
            }
        }
    });
    return expandedTypes;
}
function convertType(typeDescr) {
    var type = typeDescr.type;
    switch (type) {
        case inputTypes.string:
        case inputTypes.number:
        case inputTypes.array:
        case inputTypes.object:
            return (0, helpers_1.lowercaseFirst)(type);
        case inputTypes.date:
            return 'Date';
        case inputTypes.regexp:
            return 'RegExp';
        case inputTypes.bool:
            return 'bool';
        case inputTypes.func:
            return 'func';
        default:
            break;
    }
    if (typeDescr.isCustomType) {
        return 'object';
    }
    return 'Any';
}
function convertTypes(types, customTypes) {
    if (types === undefined || types === null || types.length === 0) {
        return undefined;
    }
    if (customTypes) {
        types.push.apply(types, expandTypes(types, customTypes));
    }
    var convertedTypes = new Set(types.map(convertType));
    if (convertedTypes.has('Any')) {
        return undefined;
    }
    return Array.from(convertedTypes);
}
exports.convertTypes = convertTypes;
//# sourceMappingURL=converter.js.map