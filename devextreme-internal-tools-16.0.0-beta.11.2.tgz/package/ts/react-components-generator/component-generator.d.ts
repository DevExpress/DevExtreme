type IComponent = {
    name: string;
    baseComponentPath: string;
    extensionComponentPath: string;
    dxExportPath: string;
    expectedChildren?: IExpectedChild[];
    isExtension?: boolean;
    subscribableOptions?: ISubscribableOption[];
    independentEvents?: IIndependentEvents[];
    templates?: string[];
    optionsTypeParams?: string[];
} & {
    nestedComponents?: INestedComponent[];
    configComponentPath?: string;
    containsReexports?: boolean;
    narrowedEvents?: IOption[];
};
interface INestedComponent {
    componentName: string;
    optionName: string;
    owners: string[];
    options: IOption[];
    templates?: string[];
    expectedChildren?: IExpectedChild[];
    predefinedProps?: Record<string, string>;
    isCollectionItem?: boolean;
}
interface ISubscribableOption {
    name: string;
    type: string;
    isSubscribable?: true;
}
interface IIndependentEvents {
    name: string;
}
type IOption = {
    name: string;
    isSubscribable?: true;
    isArray?: boolean;
    type?: any;
} & ({
    type: string;
    nested?: undefined;
} | {
    type?: undefined;
    nested: IOption[];
});
interface IExpectedChild {
    componentName: string;
    optionName: string;
    isCollectionItem?: boolean;
}
declare function generate(component: IComponent, generateReexports?: boolean, customTypeImports?: Record<string, Array<string>>, defaultTypeImports?: Record<string, string>, wildcardTypeImports?: Record<string, string>): string;
export default generate;
export { IComponent, IIndependentEvents, INestedComponent, IOption, ISubscribableOption, };
