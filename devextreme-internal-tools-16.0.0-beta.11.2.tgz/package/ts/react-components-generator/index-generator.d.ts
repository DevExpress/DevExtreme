import { IReExport } from '../components-generation/reexports-generator';
declare function generate(paths: IReExport[]): string;
export default generate;
