"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
var template_1 = require("../components-generation/template");
var helpers_1 = require("./helpers");
var TYPE_RENDER = '(...params: any) => React.ReactNode';
var TYPE_COMPONENT = 'React.ComponentType<any>';
var PORTAL_COMPONENTS = new Set([
    'dxLoadPanel',
    'dxOverlay',
    'dxPopover',
    'dxPopup',
    'dxToast',
    'dxTooltip',
    'dxValidationMessage',
]);
var USE_REQUEST_ANIMATION_FRAME = new Set([
    'dxChart',
    'dxDateBox',
    'dxDataGrid',
    'dxFilterBuilder',
]);
function getIndent(indent) {
    return Array(indent * 2 + 1).join(' ');
}
var renderObjectEntry = (0, template_1.createTemplate)("\n<#= it.indent #><#= it.key #>: \"<#= it.value #>\"\n".trimRight());
function renderObject(props, baseIndent) {
    var result = '{';
    var indent = baseIndent + 1;
    props.forEach(function (opt) {
        result += "\n".concat(getIndent(indent)).concat(opt.name, "?: ");
        if (opt.nested && (0, helpers_1.isNotEmptyArray)(opt.nested)) {
            var type = opt.type ? "".concat(opt.type, " | ") : '';
            result += "".concat(type).concat(renderObject(opt.nested, indent));
            if (opt.isArray) {
                result += '[]';
            }
        }
        else {
            result += opt.type;
        }
        result += ';';
    });
    result += "\n".concat(getIndent(baseIndent), "}");
    return result;
}
function renderNarrowedEvents(events) {
    var result = '{';
    var indent = 1;
    events.forEach(function (event) {
        result += "\n".concat(getIndent(indent)).concat(event.name, "?: ").concat(event.type, ";");
    });
    indent -= 1;
    result += "\n".concat(getIndent(indent), "}");
    return result;
}
var renderTemplateOption = (0, template_1.createTemplate)("\n{\n    <#= it.additionalIndent #>tmplOption: \"<#= it.actualOptionName #>\",\n    <#= it.additionalIndent #>render: \"<#= it.render #>\",\n    <#= it.additionalIndent #>component: \"<#= it.component #>\"\n<#= it.additionalIndent #>  }\n".trim());
var renderStringEntry = (0, template_1.createTemplate)('"<#= it #>"');
var renderModule = (0, template_1.createTemplate)('"use client"\n'
    + '<#= it.renderedImports #>\n'
    + '<#? it.renderedOptionsInterface #>'
    + '<#= it.renderedOptionsInterface #>\n\n'
    + '<#?#>'
    + '<#= it.renderedComponent #>'
    + '<#? it.renderedNestedComponents #>'
    + '<#~ it.renderedNestedComponents :nestedComponent #>\n\n'
    + '<#= nestedComponent #>'
    + '<#~#>\n\n'
    + '<#?#>'
    + 'export default <#= it.defaultExport #>;\n'
    + "export {\n<#= it.renderedExports #>\n};\n"
    + '<#? it.renderedReExports #>'
    + '<#= it.renderedReExports #>\n\n'
    + '<#?#>');
var renderImports = (0, template_1.createTemplate)('<#? it.hasExplicitTypes #>'
    + 'export { ExplicitTypes } from "<#= it.dxExportPath #>";\n'
    + '<#?#>'
    + 'import * as React from "react";\n'
    + 'import { memo, forwardRef, useImperativeHandle, useRef, useMemo, ForwardedRef, Ref, ReactElement } from "react";\n'
    + 'import <#= it.widgetName #>, {\n'
    + '    Properties\n'
    + '} from "<#= it.dxExportPath #>";\n\n'
    + '<#? it.htmlOptionsPath === it.baseComponentPath #>'
    + 'import { <#= it.baseComponentName #> as BaseComponent, IHtmlOptions, ComponentRef<#? it.configComponentPath || it.isExtensionComponent #>, NestedComponentMeta<#?#> } from "<#= it.baseComponentPath #>";\n'
    + '<#??#>'
    + 'import { <#= it.baseComponentName #> as BaseComponent } from "<#= it.baseComponentPath #>";\n'
    + 'import { IHtmlOptions, ComponentRef<#? it.configComponentPath || it.isExtensionComponent #>, NestedComponentMeta<#?#> } from "<#= it.htmlOptionsPath #>";\n'
    + '<#?#>'
    + '<#? it.configComponentPath #>'
    + 'import NestedOption from "<#= it.configComponentPath #>";\n'
    + '<#?#>'
    + '<#? it.customTypeImports && Object.keys(it.customTypeImports).length #>\n'
    + '<#~ Object.keys(it.customTypeImports) : module #>'
    + 'import type { <#= it.customTypeImports[module].join(", ")#> } from "<#= module #>";\n'
    + '<#~#>'
    + '<#?#>'
    + '<#? it.defaultTypeImports && Object.keys(it.defaultTypeImports).length #>\n'
    + '<#~ Object.keys(it.defaultTypeImports) : defaultImport #>'
    + '<#? defaultImport !== it.widgetName #>'
    + 'import type <#= defaultImport #> from "<#= it.defaultTypeImports[defaultImport] #>";\n'
    + '<#?#>'
    + '<#~#>'
    + '<#?#>'
    + '<#? it.wildcardTypeImports && Object.keys(it.wildcardTypeImports).length #>\n'
    + '<#~ Object.keys(it.wildcardTypeImports) : wildcardImportModule #>'
    + 'import type * as <#= it.wildcardTypeImports[wildcardImportModule] #> from "<#= wildcardImportModule #>";\n'
    + '<#~#>'
    + '<#?#>');
var renderNestedComponent = (0, template_1.createTemplate)('// owners:\n'
    + '<#~ it.owners : owner #>'
    + '// <#= owner #>\n'
    + '<#~#>'
    + 'type <#= it.propsType #> = React.PropsWithChildren<<#= it.renderedType #>>\n'
    + "const _component<#= it.componentName #> = (props: <#= it.propsType #>) => {\n  return React.createElement(NestedOption<<#= it.propsType #>>, {\n    ...props,\n    elementDescriptor: {\n      OptionName: \"<#= it.optionName #>\","
    + "<#? it.isCollectionItem #>".concat(template_1.L3, "IsCollectionItem: true,")
    + '<#?#>'
    + "<#? it.renderedSubscribableOptions #>".concat(template_1.L3, "DefaultsProps: {<#= it.renderedSubscribableOptions.join(',') #>").concat(template_1.L3, "},")
    + '<#?#>'
    + "<#? it.expectedChildren #>".concat(template_1.L3, "ExpectedChildren: {")
    + "<#~ it.expectedChildren : child #>".concat(template_1.L4, "<#= child.componentName #>:")
    + ' { optionName: "<#= child.optionName #>", isCollectionItem: <#= !!child.isCollectionItem #> },'
    + "<#~#>\b".concat(template_1.L3, "},")
    + '<#?#>'
    + "<#? it.renderedTemplateProps #>".concat(template_1.L3, "TemplateProps: [<#= it.renderedTemplateProps.join(', ') #>],")
    + '<#?#>'
    + "<#? it.predefinedProps #>".concat(template_1.L3, "PredefinedProps: {")
    + "<#~ it.predefinedProps : prop #>".concat(template_1.L4, "<#= prop.name #>: \"<#= prop.value #>\",")
    + "<#~#>\b".concat(template_1.L3, "},")
    + '<#?#>'
    + "\n    },\n  });\n};\n\nconst <#= it.componentName #> = Object.assign<typeof _component<#= it.componentName #>, NestedComponentMeta>(_component<#= it.componentName #>, {\n  componentType: \"option\",\n});");
var TYPE_PARAMS = '<#? it.typeParams #>'
    + '<<#= it.typeParams.join(", ") #>>'
    + '<#?#>';
var TYPE_PARAMS_WITH_DEFAULTS = '<#? it.typeParams #>'
    + '<<#= it.typeParams.map(p => `${p} = any`).join(", ") #>>'
    + '<#?#>';
var renderOptionsInterface = (0, template_1.createTemplate)('<#? it.renderedNarrowedEvents #>'
    + 'type ReplaceFieldTypes<TSource, TReplacement> = {\n'
    + '  [P in keyof TSource]: P extends keyof TReplacement ? TReplacement[P] : TSource[P];\n'
    + '}\n\n'
    + "type <#= it.optionsName #>NarrowedEvents".concat(TYPE_PARAMS_WITH_DEFAULTS, " = <#= it.renderedNarrowedEvents #>\n\n")
    + '<#?#>'
    + "type <#= it.optionsName #>".concat(TYPE_PARAMS_WITH_DEFAULTS, " = React.PropsWithChildren<<#? it.renderedNarrowedEvents #>ReplaceFieldTypes<<#?#>Properties").concat(TYPE_PARAMS, "<#? it.renderedNarrowedEvents #>, <#= it.optionsName #>NarrowedEvents").concat(TYPE_PARAMS, "><#?#> & IHtmlOptions")
    + '<#? it.typeParams || it.templates?.length || it.defaultProps?.length || it.onChangeEvents?.length #>'
    + ' & {\n'
    + '<#? it.typeParams #>'
    + "  dataSource?: Properties".concat(TYPE_PARAMS, "[\"dataSource\"];\n")
    + '<#?#>'
    + '<#~ it.templates :template #>'
    + "  <#= template.render #>?: ".concat(TYPE_RENDER, ";\n")
    + "  <#= template.component #>?: ".concat(TYPE_COMPONENT, ";\n")
    + '<#~#>'
    + '<#~ it.defaultProps :prop #>'
    + '  <#= prop.name #>?: <#= prop.type #>;\n'
    + '<#~#>'
    + '<#~ it.onChangeEvents :prop #>'
    + '  <#= prop.name #>?: <#= prop.type #>;\n'
    + '<#~#>'
    + '}'
    + '<#?#>'
    + '>');
var renderComponent = (0, template_1.createTemplate)("interface <#= it.refName #>".concat(TYPE_PARAMS_WITH_DEFAULTS, " {\n  instance: () => <#= it.widgetName #>").concat(TYPE_PARAMS, ";\n}\n\nconst <#? it.isExtension #>_component<#= it.componentName #><#??#><#= it.componentName #><#?#> = memo(\n  forwardRef(\n    ").concat(TYPE_PARAMS_WITH_DEFAULTS, "(props: React.PropsWithChildren<<#= it.optionsName #>").concat(TYPE_PARAMS, ">, ref: ForwardedRef<<#= it.refName #>").concat(TYPE_PARAMS, ">) => {\n      const baseRef = useRef<ComponentRef>(null);\n\n      useImperativeHandle(ref, () => (\n        {\n          instance() {\n            return baseRef.current?.getInstance();\n          }\n        }\n      ), [baseRef.current]);\n")
    + "<#? it.subscribableOptions #>".concat(template_1.L3, "const subscribableOptions = useMemo(() => ([<#= it.subscribableOptions.join(',') #>]), []);")
    + '<#?#>'
    + "<#? it.independentEvents #>".concat(template_1.L3, "const independentEvents = useMemo(() => ([<#= it.independentEvents.join(',') #>]), []);\n")
    + '<#?#>'
    + "<#? it.renderedDefaultProps #>".concat(template_1.L3, "const defaults = useMemo(() => ({")
    + '<#~ it.renderedDefaultProps : defaultProp #>'
    + '<#= defaultProp #>,'
    + "<#~#>".concat(template_1.L3, "}), []);\n")
    + '<#?#>'
    + "<#? it.expectedChildren #>".concat(template_1.L3, "const expectedChildren = useMemo(() => ({")
    + "<#~ it.expectedChildren : child #>".concat(template_1.L4, "<#= child.componentName #>:")
    + ' { optionName: "<#= child.optionName #>", isCollectionItem: <#= !!child.isCollectionItem #> },'
    + "<#~#>\b".concat(template_1.L3, "}), []);\n")
    + '<#?#>'
    + "<#? it.renderedTemplateProps #>".concat(template_1.L3, "const templateProps = useMemo(() => ([")
    + "<#~ it.renderedTemplateProps : templateProp #>".concat(template_1.L4, "<#= templateProp #>,")
    + "<#~#>".concat(template_1.L3, "]), []);\n")
    + '<#?#>'
    + "".concat(template_1.L3, "return (\n        React.createElement(BaseComponent<React.PropsWithChildren<<#= it.optionsName #>").concat(TYPE_PARAMS, ">>, {\n          WidgetClass: <#= it.widgetName #>,\n          ref: baseRef,")
    + "<#? it.useRequestAnimationFrameFlag #>".concat(template_1.L5, "useRequestAnimationFrameFlag: true,")
    + '<#?#>'
    + "<#? it.isPortalComponent #>".concat(template_1.L5, "isPortalComponent: true,")
    + '<#?#>'
    + "<#? it.subscribableOptions #>".concat(template_1.L5, "subscribableOptions,")
    + '<#?#>'
    + "<#? it.independentEvents #>".concat(template_1.L5, "independentEvents,")
    + '<#?#>'
    + "<#? it.renderedDefaultProps #>".concat(template_1.L5, "defaults,")
    + '<#?#>'
    + "<#? it.expectedChildren #>".concat(template_1.L5, "expectedChildren,")
    + '<#?#>'
    + "<#? it.renderedTemplateProps #>".concat(template_1.L5, "templateProps,")
    + '<#?#>'
    + "".concat(template_1.L5, "...props,")
    + "".concat(template_1.L4, "})").concat(template_1.L3, ");").concat(template_1.L2, "},").concat(template_1.L1, "),").concat(template_1.L0, ") as ").concat(TYPE_PARAMS_WITH_DEFAULTS, "(props: React.PropsWithChildren<<#= it.optionsName #>").concat(TYPE_PARAMS, "> & { ref?: Ref<<#= it.refName #>").concat(TYPE_PARAMS, "> }) => ReactElement | null;\n")
    + "<#? it.isExtension #>\nconst <#= it.componentName #> = Object.assign<typeof _component<#= it.componentName #>, NestedComponentMeta>(_component<#= it.componentName #>, {\n  componentType: \"extension\",\n});\n<#?#>");
function renderExports(exportsNames) {
    return exportsNames
        .map(function (exportName) { return getIndent(1) + exportName; })
        .join(',\n');
}
function renderReExports(componentName, exportPath) {
    return "import type * as ".concat(componentName, "Types from '").concat(exportPath, "_types';\n")
        + "export { ".concat(componentName, "Types };");
}
function formatTemplatePropName(name, suffix) {
    return (0, helpers_1.lowercaseFirst)(name.replace(/template$/i, suffix));
}
function createTemplateDto(templates, indent) {
    return templates
        ? templates.map(function (actualOptionName) { return ({
            actualOptionName: actualOptionName,
            render: formatTemplatePropName(actualOptionName, 'Render'),
            component: formatTemplatePropName(actualOptionName, 'Component'),
            additionalIndent: indent,
        }); })
        : undefined;
}
function buildPropsTypeName(componentName) {
    return "I".concat(componentName, "Props");
}
function generate(component, generateReexports, customTypeImports, defaultTypeImports, wildcardTypeImports) {
    var _a, _b, _c, _d, _e, _f;
    if (generateReexports === void 0) { generateReexports = false; }
    var nestedComponents = component.nestedComponents
        ? component.nestedComponents
            .sort((0, helpers_1.createKeyComparator)(function (o) { return o.componentName; }))
            .map(function (c) {
            var options = __spreadArray([], c.options, true);
            var nestedSubscribableOptions = options.filter(function (o) { return o.isSubscribable; });
            var renderedSubscribableOptions;
            if ((0, helpers_1.isNotEmptyArray)(nestedSubscribableOptions)) {
                nestedSubscribableOptions.forEach(function (o) {
                    options.push(__assign(__assign({}, o), { name: "default".concat((0, helpers_1.uppercaseFirst)(o.name)) }), {
                        name: "on".concat((0, helpers_1.uppercaseFirst)(o.name), "Change"),
                        type: "(value: ".concat(o.type, ") => void"),
                    });
                });
                renderedSubscribableOptions = nestedSubscribableOptions.map(function (o) { return renderObjectEntry({
                    key: "default".concat((0, helpers_1.uppercaseFirst)(o.name)),
                    value: o.name,
                    indent: template_1.TAB4,
                }); });
            }
            var nestedTemplates = createTemplateDto(c.templates, template_1.TAB2);
            if (nestedTemplates) {
                nestedTemplates.forEach(function (t) {
                    options.push({
                        name: t.render,
                        type: TYPE_RENDER,
                    }, {
                        name: t.component,
                        type: TYPE_COMPONENT,
                    });
                });
            }
            var predefinedProps;
            if (c.predefinedProps) {
                predefinedProps = [];
                if (c.predefinedProps) {
                    predefinedProps = [];
                    Object.entries(c.predefinedProps).forEach(function (prop) {
                        var name = prop[0], value = prop[1];
                        predefinedProps === null || predefinedProps === void 0 ? void 0 : predefinedProps.push({ name: name, value: value });
                    });
                }
            }
            return {
                componentName: c.componentName,
                propsType: buildPropsTypeName(c.componentName),
                optionName: c.optionName,
                ownerName: c.owners,
                renderedType: renderObject(options, 0),
                renderedSubscribableOptions: renderedSubscribableOptions,
                renderedTemplateProps: nestedTemplates && nestedTemplates.map(renderTemplateOption),
                isCollectionItem: c.isCollectionItem,
                predefinedProps: predefinedProps,
                expectedChildren: c.expectedChildren,
                owners: c.owners,
            };
        })
        : undefined;
    var optionsName = "I".concat(component.name, "Options");
    var refName = "".concat(component.name, "Ref");
    var exportNames = [
        component.name,
        optionsName,
        refName,
    ];
    if (component.nestedComponents && (0, helpers_1.isNotEmptyArray)(component.nestedComponents)) {
        component.nestedComponents.forEach(function (c) {
            exportNames.push(c.componentName);
            exportNames.push(buildPropsTypeName(c.componentName));
        });
    }
    var templates = createTemplateDto(component.templates, template_1.TAB3);
    var firstLevelSubscribableOptions = (_a = component.subscribableOptions) === null || _a === void 0 ? void 0 : _a.filter(function (_a) {
        var name = _a.name;
        return !name.includes('.');
    });
    var defaultProps = firstLevelSubscribableOptions
        ? firstLevelSubscribableOptions.map(function (o) { return ({
            name: "default".concat((0, helpers_1.uppercaseFirst)(o.name)),
            type: o.type,
            actualOptionName: o.name,
        }); })
        : undefined;
    var onChangeEvents = firstLevelSubscribableOptions
        ? firstLevelSubscribableOptions.map(function (o) { return ({
            name: "on".concat((0, helpers_1.uppercaseFirst)(o.name), "Change"),
            type: "(value: ".concat(o.type, ") => void"),
            actualOptionName: o.name,
        }); })
        : undefined;
    var widgetName = "dx".concat((0, helpers_1.uppercaseFirst)(component.name));
    var hasExplicitTypes = !!((_b = component.optionsTypeParams) === null || _b === void 0 ? void 0 : _b.length);
    var typeParams = ((_c = component.optionsTypeParams) === null || _c === void 0 ? void 0 : _c.length) ? component.optionsTypeParams : undefined;
    return renderModule({
        renderedImports: renderImports({
            dxExportPath: component.dxExportPath,
            htmlOptionsPath: component.baseComponentPath,
            isExtensionComponent: component.isExtension,
            baseComponentPath: component.isExtension
                ? component.extensionComponentPath
                : component.baseComponentPath,
            baseComponentName: component.isExtension ? 'ExtensionComponent' : 'Component',
            widgetName: widgetName,
            hasExplicitTypes: hasExplicitTypes,
            configComponentPath: (0, helpers_1.isNotEmptyArray)(nestedComponents)
                ? component.configComponentPath
                : undefined,
            customTypeImports: customTypeImports,
            defaultTypeImports: defaultTypeImports,
            wildcardTypeImports: wildcardTypeImports,
        }),
        renderedOptionsInterface: renderOptionsInterface({
            optionsName: optionsName,
            defaultProps: defaultProps || [],
            onChangeEvents: onChangeEvents || [],
            templates: templates || [],
            typeParams: typeParams,
            renderedNarrowedEvents: component.narrowedEvents && component.narrowedEvents.length
                ? renderNarrowedEvents(component.narrowedEvents) : undefined,
        }),
        renderedComponent: renderComponent({
            componentName: component.name,
            widgetName: widgetName,
            refName: refName,
            optionsName: optionsName,
            subscribableOptions: (_d = component.subscribableOptions) === null || _d === void 0 ? void 0 : _d.map(function (o) { return renderStringEntry(o.name); }),
            independentEvents: (_e = component.independentEvents) === null || _e === void 0 ? void 0 : _e.map(function (f) { return renderStringEntry(f.name); }),
            renderedTemplateProps: templates && templates.map(renderTemplateOption),
            renderedDefaultProps: defaultProps && defaultProps.map(function (o) { return renderObjectEntry({
                key: o.name,
                value: o.actualOptionName,
                indent: template_1.TAB4,
            }); }),
            expectedChildren: component.expectedChildren,
            useRequestAnimationFrameFlag: USE_REQUEST_ANIMATION_FRAME.has(widgetName),
            isPortalComponent: PORTAL_COMPONENTS.has(widgetName),
            typeParams: ((_f = component.optionsTypeParams) === null || _f === void 0 ? void 0 : _f.length) ? component.optionsTypeParams : undefined,
            isExtension: component.isExtension,
        }),
        renderedNestedComponents: nestedComponents && nestedComponents.map(renderNestedComponent),
        defaultExport: component.name,
        renderedExports: renderExports(exportNames),
        renderedReExports: generateReexports && component.containsReexports
            ? renderReExports(component.name, component.dxExportPath)
            : undefined,
    });
}
exports.default = generate;
//# sourceMappingURL=component-generator.js.map