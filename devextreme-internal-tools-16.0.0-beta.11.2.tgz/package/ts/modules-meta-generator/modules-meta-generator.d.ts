import { CompilerOptions } from 'typescript';
export declare function generateModulesMeta(targetFiles: string[], targetDir: string, output: string, compilerOptions: CompilerOptions | undefined, toolsVersion?: string): void;
export declare function getModulesData(fileNames: string[], baseDir: string, compilerOptions?: CompilerOptions): Record<string, Record<string, unknown>>;
