"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getModulesData = exports.generateModulesMeta = void 0;
var fs_1 = require("fs");
var typescript_1 = require("typescript");
var logging_1 = require("../logging");
var ts_utils_1 = require("../common/ts-utils");
var common_resolving_1 = require("../common/common-resolving");
function generateModulesMeta(targetFiles, targetDir, output, compilerOptions, toolsVersion) {
    (0, logging_1.log)('Discovering modules');
    var modulesData = getModulesData(targetFiles, targetDir, compilerOptions);
    var modulesCount = Object.entries(modulesData).length;
    if (!modulesCount)
        throw new Error('No modules found');
    (0, logging_1.log)("".concat(modulesCount, " modules discovered"));
    var metaData = {
        ToolsVersion: toolsVersion,
        Modules: modulesData,
    };
    (0, fs_1.writeFileSync)(output, JSON.stringify(metaData, null, 2));
}
exports.generateModulesMeta = generateModulesMeta;
function getModulesData(fileNames, baseDir, compilerOptions) {
    var program = (0, typescript_1.createProgram)(fileNames, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {});
    var checker = program.getTypeChecker();
    return fileNames.reduce(function (modules, module) {
        var sourceFile = program.getSourceFile(module);
        if (!sourceFile) {
            return modules;
        }
        var moduleName = (0, ts_utils_1.getModule)(sourceFile, baseDir);
        if (!moduleName) {
            return modules;
        }
        var fileSymbol = checker.getSymbolAtLocation(sourceFile);
        if (!fileSymbol) {
            return modules;
        }
        var exports = getModuleExports(fileSymbol);
        if (Object.entries(exports).length) {
            modules[moduleName] = exports;
        }
        return modules;
    }, {});
    function getModuleExports(fileSymbol) {
        return checker.getExportsOfModule(fileSymbol).reduce(function (exports, symbol) {
            if (hasPublicTags(symbol) || hasDeclarationsWithPublicTags(symbol)) {
                exports[symbol.escapedName.toString()] = {};
            }
            return exports;
        }, {});
    }
    function hasDeclarationsWithPublicTags(symbol) {
        return symbol.declarations
            .filter(typescript_1.isExportAssignment)
            .some(function (d) {
            var exportedSymbol = checker.getSymbolAtLocation(d.expression);
            return !!exportedSymbol && hasPublicTags(exportedSymbol);
        });
    }
    function hasPublicTags(symbol) {
        return (0, common_resolving_1.hasTag)(symbol, 'public')
            || (0, common_resolving_1.hasTag)(symbol, 'docid');
    }
}
exports.getModulesData = getModulesData;
//# sourceMappingURL=modules-meta-generator.js.map