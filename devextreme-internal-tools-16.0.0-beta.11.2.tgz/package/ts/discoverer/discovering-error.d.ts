import { Node } from 'typescript';
export declare class DiscoveringError extends Error {
    constructor(message: string, nodes: Node[]);
}
