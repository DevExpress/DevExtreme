import { CompilerOptions } from 'typescript';
import { TypeDeclaration, EnumLikeType, GenericParamDeclaration } from './data-model';
import { GeneralType } from './types';
import { DocTag } from '../common/tags/types';
import { ID } from '../common/id';
export { CompilerOptions } from 'typescript';
export type Descriptor = OptionDescriptor | WidgetDescriptor;
interface OptionDescriptor extends DescriptorBase {
    kind: 'option';
    optional: boolean;
    type?: GeneralType;
}
export interface WidgetDescriptor extends DescriptorBase {
    kind: 'widget';
    optionsType: string;
}
interface DescriptorBase {
    [ID]: string;
    exported: boolean;
    tags: DocTag[];
    location?: {
        file: string;
    };
    typeParameters?: Record<string, GenericParamDeclaration>;
}
export declare function parseFiles(files: string[], baseDir: string, compilerOptions: CompilerOptions | undefined): [
    Descriptor[],
    Record<string, TypeDeclaration | EnumLikeType>
];
