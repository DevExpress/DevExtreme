"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.discoverMembers = exports.discover = void 0;
var fs_1 = require("fs");
var utils_1 = require("../common/utils");
var parsing_1 = require("./parsing");
var tags_1 = require("../common/tags");
var logging_1 = require("../logging");
var id_1 = require("../common/id");
function discover(targetFiles, targetDir, outputFile, toolsVersion, compilerOptions) {
    if (compilerOptions === void 0) { compilerOptions = {}; }
    (0, logging_1.log)('Discovering members');
    var normalizedResult = discoverMembers(targetFiles, targetDir, compilerOptions);
    (0, logging_1.log)("".concat(normalizedResult.members.length, " members descriptors discovered"));
    (0, fs_1.writeFileSync)(outputFile, JSON.stringify(__assign({ ToolsVersion: toolsVersion }, normalizedResult), null, 2));
}
exports.discover = discover;
function discoverMembers(fileNames, baseDir, compilerOptions) {
    var _a = (0, parsing_1.parseFiles)(fileNames, baseDir, compilerOptions), descriptors = _a[0], types = _a[1];
    var members = descriptors
        .filter(function (e) { return Object.entries(e.tags).length > 0; })
        .map(function (descriptor) {
        var member = { id: descriptor[id_1.ID], tags: (0, tags_1.buildMemberTags)(descriptor.tags) };
        switch (descriptor.kind) {
            case 'option': {
                var type = descriptor.type, optional = descriptor.optional;
                if (type) {
                    member.type = { name: type.name };
                    if (type.cat === 'custom' || type.cat === 'custom-generic')
                        member.type.file = type.file;
                }
                if (optional)
                    member.optional = true;
                break;
            }
            case 'widget':
                member.optionsType = descriptor.optionsType;
                break;
        }
        if (descriptor.location)
            member.location = descriptor.location;
        if (descriptor.typeParameters)
            member.typeParameters = descriptor.typeParameters;
        if (!member.id) {
            throw new Error("Empty ID discovered: ".concat(JSON.stringify(member)));
        }
        return member;
    })
        .sort(compare);
    return {
        members: members,
        types: (0, utils_1.toSortedRecord)(types),
    };
}
exports.discoverMembers = discoverMembers;
function compare(a, b) {
    var result = compareAttrValues(getNameForComparison(a), getNameForComparison(b));
    return result !== 0 ? result : compareAttrValues(a.tags.name, b.tags.name);
}
function getNameForComparison(doc) {
    return doc.tags.const || doc.tags.docid;
}
function compareAttrValues(a, b) {
    if (a === undefined && b === undefined)
        return 0;
    if (a === undefined)
        return -1;
    if (b === undefined)
        return 1;
    return a[0].localeCompare(b[0]);
}
//# sourceMappingURL=discovering.js.map