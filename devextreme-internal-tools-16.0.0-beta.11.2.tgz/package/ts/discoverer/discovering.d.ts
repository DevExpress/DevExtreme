import { CompilerOptions } from './parsing';
import { Root } from './data-model';
export declare function discover(targetFiles: string[], targetDir: string, outputFile: string, toolsVersion?: string, compilerOptions?: CompilerOptions): void;
export declare function discoverMembers(fileNames: string[], baseDir: string, compilerOptions?: CompilerOptions): Root;
