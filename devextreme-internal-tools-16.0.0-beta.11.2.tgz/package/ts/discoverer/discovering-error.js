"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscoveringError = void 0;
var DiscoveringError = (function (_super) {
    __extends(DiscoveringError, _super);
    function DiscoveringError(message, nodes) {
        var extraData = [];
        for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
            var node = nodes_1[_i];
            var file = node.getSourceFile();
            var _a = file.getLineAndCharacterOfPosition(node.getStart()), line = _a.line, character = _a.character;
            extraData.push("".concat(file.fileName, ":").concat(line, ":").concat(character, "\n\n").concat(node.getText()));
        }
        return _super.call(this, "".concat(message, "\n\n").concat(extraData.join('\n'), "\n\n")) || this;
    }
    return DiscoveringError;
}(Error));
exports.DiscoveringError = DiscoveringError;
//# sourceMappingURL=discovering-error.js.map