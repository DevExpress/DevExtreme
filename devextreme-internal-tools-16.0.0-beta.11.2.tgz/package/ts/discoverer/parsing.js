"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseFiles = void 0;
var path_1 = require("path");
var typescript_1 = require("typescript");
var tags_1 = require("../common/tags");
var merging_1 = require("../common/tags/merging");
var common_resolving_1 = require("../common/common-resolving");
var ts_utils_1 = require("../common/ts-utils");
var logging_1 = require("../logging");
var ts_type_resolving_1 = require("../common/ts-type-resolving");
var enum_collecting_1 = require("./parsing/enum-collecting");
var discovering_error_1 = require("./discovering-error");
var id_1 = require("../common/id");
var file_reader_1 = require("./parsing/file-reader");
var widget_parsing_1 = require("./parsing/widget-parsing");
var utils_1 = require("../common/utils");
function parseFiles(files, baseDir, compilerOptions) {
    var program = (0, typescript_1.createProgram)(files, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {});
    var descriptors = [];
    var tsTypes = {};
    var checker = program.getTypeChecker();
    var processTypes = (0, ts_type_resolving_1.createTypeProcessor)(checker, baseDir);
    var _a = (0, enum_collecting_1.createEnumsCollector)(baseDir), addEnum = _a.addEnum, toRecord = _a.toRecord;
    files.forEach(function (filePath) {
        processFile(filePath);
    });
    function addDescriptor(descriptor, file) {
        if (descriptor === undefined)
            return;
        descriptors.push(__assign(__assign({}, descriptor), { location: descriptor.location || { file: file } }));
    }
    function processFile(filePath) {
        var sourceFile = program.getSourceFile(filePath);
        if (sourceFile.text.length === 0)
            throw new Error("Empty file: ".concat(filePath));
        var file = (0, utils_1.toInvariantPath)((0, path_1.relative)(baseDir, filePath));
        var addFileDescriptor = function (d) { return addDescriptor(d, file); };
        for (var _i = 0, _a = (0, file_reader_1.getDiscoverableSymbols)(sourceFile, checker); _i < _a.length; _i++) {
            var member = _a[_i];
            proccessMemberDescriptors(member, sourceFile.fileName, checker, baseDir, addFileDescriptor);
            if (!file.includes('renovation')) {
                addEnum(member);
            }
            if ((0, common_resolving_1.hasTag)(member, 'docid') || (0, ts_type_resolving_1.isPublicType)(member)) {
                processTypes(member, tsTypes);
            }
        }
    }
    return [descriptors, __assign(__assign({}, tsTypes), toRecord())];
}
exports.parseFiles = parseFiles;
function proccessMemberDescriptors(member, fileName, checker, baseDir, addDescriptor) {
    var _a = getModuleAndExport(member, baseDir), moduleName = _a[0], exportName = _a[1];
    var moduleAndExportTags = [
        { name: 'module', value: moduleName },
        { name: 'export', value: exportName },
    ];
    var reportDuplicateTag = function (message, lvl) {
        if (lvl === void 0) { lvl = 'warn'; }
        (0, logging_1.log)(message, { lvl: lvl, node: member.declarations[0] });
    };
    var exportedDescriptors = getExportedDescriptors(member, fileName, checker, baseDir).filter(function (d) { return !!(d === null || d === void 0 ? void 0 : d.tags.length); });
    exportedDescriptors.forEach(function (d) {
        var descriptor = __assign({}, d);
        if (descriptor.exported) {
            descriptor.tags = (0, merging_1.mergeTags)(descriptor.tags, moduleAndExportTags, reportDuplicateTag);
        }
        addDescriptor(descriptor);
    });
    if (hasMultipleDeclarations(member))
        return;
    var descriptor = getDescriptorFromSymbol(member, checker, baseDir);
    if (descriptor === null || descriptor === void 0 ? void 0 : descriptor.tags.length) {
        descriptor.tags = (0, merging_1.mergeTags)(descriptor.tags, moduleAndExportTags, reportDuplicateTag);
        addDescriptor(descriptor);
    }
}
function getExportedDescriptors(member, fileName, checker, baseDir) {
    var declarations = member.declarations
        .filter(function (d) { return d.getSourceFile().fileName === fileName; });
    if (declarations.length > 1) {
        return declarations.map(function (d) { return ((0, typescript_1.isFunctionDeclaration)(d)
            ? getMemberFromFunctionDeclaration(d, checker, baseDir)
            : undefined); }).filter(function (d) { return d; });
    }
    var declaration = member.declarations[0];
    if ((0, typescript_1.isExportSpecifier)(declaration))
        return [getMemberFromExportSpecifier(declaration, baseDir)];
    if ((0, typescript_1.isExportAssignment)(declaration)) {
        return getMembersFromExportAssignment(checker, declaration, baseDir);
    }
    if ((0, typescript_1.isTypeAliasDeclaration)(declaration)) {
        return getMembersFromTypeAliasDeclaration(declaration, checker, baseDir);
    }
    return getMembersFromDeclaration(declaration, checker, baseDir);
}
function getDescriptorFromSymbol(symbol, checker, baseDir) {
    var _a, _b;
    if (hasMultipleDeclarations(symbol))
        return undefined;
    var declaration = symbol.declarations[0];
    var tags = (0, tags_1.getSymbolTags)(checker, symbol, baseDir);
    if (!(tags === null || tags === void 0 ? void 0 : tags.length))
        return undefined;
    var id = (0, id_1.getIdFromSymbol)(symbol, baseDir);
    var _c = (0, widget_parsing_1.parseWidgetExtras)(declaration, tags, checker, baseDir), isWidget = _c.isWidget, optionsType = _c.optionsType, widgetTags = _c.tags;
    if (!id) {
        throw new Error("Unable to build ID for ".concat(JSON.stringify(tags)));
    }
    var typeParameters = getTypeParameters(checker, symbol, baseDir);
    if (isWidget) {
        return _a = {},
            _a[id_1.ID] = id,
            _a.kind = 'widget',
            _a.exported = true,
            _a.tags = widgetTags,
            _a.typeParameters = typeParameters,
            _a.optionsType = optionsType,
            _a;
    }
    return _b = {},
        _b[id_1.ID] = id,
        _b.kind = 'option',
        _b.exported = true,
        _b.tags = tags,
        _b.typeParameters = typeParameters,
        _b.optional = false,
        _b;
}
function getMembersFromDeclaration(declaration, checker, baseDir) {
    if ((0, typescript_1.isFunctionDeclaration)(declaration)) {
        return [getMemberFromFunctionDeclaration(declaration, checker, baseDir)];
    }
    if ((0, typescript_1.isVariableDeclaration)(declaration)
        || (0, typescript_1.isTypeLiteralNode)(declaration)
        || (0, typescript_1.isClassDeclaration)(declaration)
        || (0, typescript_1.isInterfaceDeclaration)(declaration)) {
        return (0, ts_utils_1.getNestedSymbols)(checker.getTypeAtLocation(declaration))
            .map(function (s) {
            var members = getMembersFromSymbol(s, checker, baseDir);
            return members.map(function (m) { return (__assign(__assign({}, m), { exported: false })); });
        })
            .flat();
    }
    return [];
}
function getMemberFromFunctionDeclaration(declaration, checker, baseDir) {
    var _a;
    return _a = {},
        _a[id_1.ID] = (0, id_1.getIdFromNode)(declaration, baseDir),
        _a.kind = 'option',
        _a.exported = true,
        _a.tags = (0, tags_1.getSignatureDeclarationTags)(checker, declaration, baseDir),
        _a.optional = false,
        _a;
}
function getMembersFromTypeAliasDeclaration(declaration, checker, targetDir) {
    return getMembersFromPropType(checker.getTypeAtLocation(declaration.type), checker, declaration.getSourceFile().fileName, targetDir);
}
function getMembersFromSymbol(symbol, checker, baseDir) {
    var _a, _b;
    if (!symbol.declarations) {
        return [];
    }
    var propDeclarations = [];
    var result = [];
    var id = (0, id_1.getIdFromSymbol)(symbol, baseDir);
    for (var _i = 0, _c = symbol.declarations; _i < _c.length; _i++) {
        var declaration = _c[_i];
        if (!registerDeclaration(declaration)) {
            continue;
        }
        if ((0, typescript_1.isMethodDeclaration)(declaration) || (0, typescript_1.isMethodSignature)(declaration)) {
            result.push((_a = {},
                _a[id_1.ID] = (0, id_1.getIdFromNode)(declaration, baseDir),
                _a.kind = 'option',
                _a.exported = true,
                _a.tags = (0, tags_1.getSignatureDeclarationTags)(checker, declaration, baseDir),
                _a.optional = (0, ts_utils_1.isOptional)(symbol),
                _a.location = {
                    file: (0, utils_1.toInvariantPath)((0, path_1.relative)(baseDir, declaration.getSourceFile().fileName)),
                },
                _a));
        }
        else {
            var propType = checker.getTypeAtLocation(declaration);
            if ((0, ts_utils_1.isStructuredType)(propType)) {
                result.push.apply(result, getMembersFromPropType(propType, checker, declaration.getSourceFile().fileName, baseDir));
            }
            propDeclarations.push(declaration);
        }
    }
    if (id && propDeclarations.length !== 0) {
        result.push((_b = {},
            _b[id_1.ID] = id,
            _b.kind = 'option',
            _b.exported = true,
            _b.tags = (0, tags_1.getSymbolTags)(checker, symbol, baseDir),
            _b.type = extractType(propDeclarations, checker, baseDir),
            _b.optional = (0, ts_utils_1.isOptional)(symbol),
            _b.location = {
                file: (0, utils_1.toInvariantPath)((0, path_1.relative)(baseDir, symbol.declarations[0].getSourceFile().fileName)),
            },
            _b));
    }
    return result;
}
function getMembersFromPropType(type, checker, targetFileName, targetDir) {
    var symbols = (0, ts_utils_1.getTypeSymbols)(type);
    var declarations = symbols
        .map(function (symbol) { return symbol.getDeclarations(); })
        .filter(Boolean)
        .flat()
        .filter(function (declaration) { return targetFileName === declaration.getSourceFile().fileName; });
    return declarations.flatMap(function (declaration) { return getMembersFromDeclaration(declaration, checker, targetDir); });
}
function getMemberFromExportSpecifier(exportSpecifier, baseDir) {
    var _a;
    var adjacentExportSpecifiers = getAdjacentExportSpecifiers(exportSpecifier);
    var isSingleExport = adjacentExportSpecifiers && adjacentExportSpecifiers.length === 1;
    if (!isSingleExport)
        return undefined;
    var declaration = exportSpecifier.parent.parent;
    var tags = (0, typescript_1.getJSDocTags)(declaration);
    if (!(tags === null || tags === void 0 ? void 0 : tags.length))
        return undefined;
    return _a = {},
        _a[id_1.ID] = (0, id_1.getIdFromNode)(exportSpecifier, baseDir),
        _a.kind = 'option',
        _a.exported = true,
        _a.tags = tags.map(tags_1.normalizeTag),
        _a.optional = false,
        _a;
}
function getAdjacentExportSpecifiers(node) {
    if (!node.parent)
        return undefined;
    var exportsListNodes = node.parent
        .getChildren()
        .filter(function (n) { return n.kind === typescript_1.SyntaxKind.SyntaxList; });
    if (exportsListNodes.length !== 1)
        return undefined;
    return exportsListNodes[0]
        .getChildren()
        .filter(function (n) { return n.kind === typescript_1.SyntaxKind.ExportSpecifier; });
}
function getMembersFromExportAssignment(checker, declaration, baseDir) {
    var _a;
    var result = [];
    if (declaration.expression.kind !== typescript_1.SyntaxKind.Identifier)
        return result;
    var declarationSymbol = checker.getSymbolAtLocation(declaration.expression);
    var declarationId = (0, id_1.getIdFromSymbol)(declarationSymbol, baseDir);
    if (declarationId && declarationSymbol && !hasMultipleDeclarations(declarationSymbol)) {
        result.push((_a = {},
            _a[id_1.ID] = declarationId,
            _a.kind = 'option',
            _a.exported = true,
            _a.tags = (0, tags_1.getSymbolTags)(checker, declarationSymbol, baseDir),
            _a.optional = false,
            _a));
    }
    var type = checker.getTypeAtLocation(declaration.expression);
    result.push.apply(result, getMembersFromPropType(type, checker, declaration.getSourceFile().fileName, baseDir));
    return result;
}
function hasMultipleDeclarations(symbol) {
    var _a;
    return ((_a = symbol.getDeclarations()) === null || _a === void 0 ? void 0 : _a.length) > 1;
}
var visitedDeclarations = new Set();
function registerDeclaration(d) {
    var name = "".concat(d.getSourceFile().fileName, "|").concat(d.getStart().toString());
    if ((0, ts_type_resolving_1.isExternalDeclaration)(d) || visitedDeclarations.has(name)) {
        return false;
    }
    visitedDeclarations.add(name);
    return true;
}
function getModuleAndExport(symbol, baseDir) {
    var moduleName = (0, ts_utils_1.getModule)(symbol.declarations[0], baseDir);
    var exportName = symbol.escapedName.toString();
    return [moduleName, exportName];
}
function getTypeParameters(checker, member, baseDir) {
    var typeParams = getGenericParameters(member);
    if (!typeParams.length)
        return undefined;
    return Object.fromEntries(typeParams.map(function (p) { return [
        p.name.escapedText.toString(),
        getGenericParamDeclaration(p, checker, baseDir),
    ]; }));
}
function extractType(declarations, checker, targetDir) {
    var symbol = extractTypeSymbol(declarations, checker, targetDir);
    var targetFlags = typescript_1.SymbolFlags.Interface | typescript_1.SymbolFlags.TypeAlias
        | typescript_1.SymbolFlags.Class | typescript_1.SymbolFlags.Enum;
    if ((symbol === null || symbol === void 0 ? void 0 : symbol.flags) & targetFlags) {
        var file = (0, utils_1.toInvariantPath)((0, path_1.relative)(targetDir, symbol.declarations[0].getSourceFile().fileName));
        return {
            cat: 'custom',
            name: symbol.name,
            file: file,
        };
    }
    return undefined;
}
function extractTypeSymbol(nodes, checker, targetDir) {
    var symbol = (0, ts_utils_1.getTypeSymbol)(checker.getTypeAtLocation(nodes[0]));
    if (!symbol)
        return undefined;
    if (symbol.flags & typescript_1.SymbolFlags.TypeLiteral)
        return undefined;
    if (!symbol.declarations)
        throw new discovering_error_1.DiscoveringError('Unable to find type declaration', nodes);
    var file = (0, path_1.relative)(targetDir, symbol.declarations[0].getSourceFile().fileName);
    if (/node_modules\\typescript\\.*\\lib\..*\.d\.ts/.test(file) || /node_modules\/typescript\/.*\/lib\..*\.d\.ts/.test(file))
        return undefined;
    return symbol;
}
function getGenericParamDeclaration(genericParam, checker, baseDir) {
    return {
        defaultValue: genericParam.default
            ? (0, ts_type_resolving_1.resolveType)(genericParam.default, checker, baseDir)
            : undefined,
    };
}
function getGenericParameters(member) {
    var declaration = member.declarations[0];
    if (((0, typescript_1.isTypeAliasDeclaration)(declaration) || (0, typescript_1.isInterfaceDeclaration)(declaration))
        && declaration.typeParameters) {
        return __spreadArray([], declaration.typeParameters, true);
    }
    return [];
}
//# sourceMappingURL=parsing.js.map