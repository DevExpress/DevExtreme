"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypingKind = void 0;
exports.TypingKind = {
    Value: 0,
    Reference: 1,
    Union: 2,
    Intersection: 3,
    Literal: 4,
    GenericArgument: 5,
    Function: 6,
};
//# sourceMappingURL=data-model.js.map