"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEnumsCollector = void 0;
var typescript_1 = require("typescript");
var logging_1 = require("../../logging");
var type_resolving_1 = require("../../common/type-resolving");
var utils_1 = require("../../common/utils");
var id_1 = require("../../common/id");
function getValuesFromEnumLikeType(declaration, baseDir) {
    if ((0, typescript_1.isTypeAliasDeclaration)(declaration)) {
        var type = declaration.type;
        var types = (0, typescript_1.isUnionTypeNode)(type) ? __spreadArray([], type.types, true) : [type];
        if (types && (0, utils_1.everyOf)(types, typescript_1.isLiteralTypeNode)) {
            var literals = types.map(type_resolving_1.resolveLiteralType);
            if ((0, utils_1.everyOf)(literals, type_resolving_1.isStringLiteralMemberType)) {
                return {
                    id: (0, id_1.getIdFromNode)(declaration, baseDir),
                    kind: 'enum',
                    values: literals.map(function (l) { return l.value; }),
                    valueType: 'string',
                };
            }
            if ((0, utils_1.everyOf)(literals, type_resolving_1.isNumberLiteralMemberType)) {
                return {
                    id: (0, id_1.getIdFromNode)(declaration, baseDir),
                    kind: 'enum',
                    values: literals.map(function (l) { return l.value; }),
                    valueType: 'number',
                };
            }
        }
    }
    return undefined;
}
function createEnumsCollector(baseDir) {
    var enumLikeTypes = new Map();
    function update(enumName, enumValues) {
        var typeName = "Enums.".concat(enumName);
        if (enumLikeTypes.has(typeName)) {
            var enumType = enumLikeTypes.get(typeName);
            if (enumType.valueType === 'string' && enumValues.valueType === 'string') {
                enumType.values = __spreadArray(__spreadArray([], enumType.values, true), enumValues.values, true);
            }
            else if (enumType.valueType === 'number' && enumValues.valueType === 'number') {
                enumType.values = __spreadArray(__spreadArray([], enumType.values, true), enumValues.values, true);
            }
            else {
                (0, logging_1.log)("Enums with the same name ".concat(enumName, ", but different values"), { lvl: 'error' });
            }
        }
        else {
            enumLikeTypes.set(typeName, enumValues);
        }
    }
    function addEnum(symbol) {
        var enumValues = symbol.declarations
            .filter(typescript_1.isTypeAliasDeclaration)
            .map(function (declaration) { return getValuesFromEnumLikeType(declaration, baseDir); })
            .find(Boolean);
        if (!enumValues)
            return;
        var enumName = symbol.escapedName.toString();
        update(enumName, enumValues);
    }
    function toRecord() {
        return Object.fromEntries(enumLikeTypes.entries());
    }
    return { addEnum: addEnum, toRecord: toRecord };
}
exports.createEnumsCollector = createEnumsCollector;
//# sourceMappingURL=enum-collecting.js.map