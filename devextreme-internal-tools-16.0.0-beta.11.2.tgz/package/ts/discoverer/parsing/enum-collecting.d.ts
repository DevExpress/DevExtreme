import { Symbol } from 'typescript';
import { EnumLikeType } from '../data-model';
export declare function createEnumsCollector(baseDir: string): {
    addEnum(symbol: Symbol): void;
    toRecord(): Record<string, EnumLikeType>;
};
