import { SourceFile, Symbol, TypeChecker } from 'typescript';
export declare function getDiscoverableSymbols(sourceFile: SourceFile, checker: TypeChecker): Symbol[];
