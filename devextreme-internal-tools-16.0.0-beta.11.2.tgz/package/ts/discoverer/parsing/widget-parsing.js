"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseWidgetExtras = void 0;
var typescript_1 = require("typescript");
var common_resolving_1 = require("../../common/common-resolving");
var id_1 = require("../../common/id");
var tags_1 = require("../../common/tags");
var ts_utils_1 = require("../../common/ts-utils");
function parseWidgetExtras(node, tags, checker, baseDir) {
    var optionsTag = tags.find(function (t) { return t.name === tags_1.TAG_OPTIONS; });
    if (optionsTag) {
        var optionsType = optionsTag.value.indexOf(':') === -1
            ? "".concat((0, id_1.getNodeFilePrefix)(node, baseDir), ":").concat(optionsTag.value)
            : optionsTag.value;
        return {
            optionsType: optionsType,
            isWidget: true,
            tags: tags.filter(function (t) { return t !== optionsTag; }),
        };
    }
    var optionsTypeSymbol = getOptionsTypeSymbol(node, checker);
    if (optionsTypeSymbol) {
        if (optionsTypeSymbol.declarations.length !== 1) {
            throw new Error("Partial declaration of options type not expected: ".concat(optionsTypeSymbol.name));
        }
        var prefix = (0, id_1.getNodeFilePrefix)(optionsTypeSymbol.declarations[0], baseDir);
        return {
            optionsType: "".concat(prefix, ":").concat(optionsTypeSymbol.name),
            isWidget: true,
            tags: tags,
        };
    }
    return { isWidget: false };
}
exports.parseWidgetExtras = parseWidgetExtras;
function getOptionsTypeSymbol(node, checker) {
    var _a;
    var type = checker.getTypeAtLocation(node);
    if (!((_a = getAllBaseTypes(type)) === null || _a === void 0 ? void 0 : _a.some((isWrappable))))
        return undefined;
    var optionsPropSymbol = type.getProperty('option');
    if (optionsPropSymbol === undefined)
        return undefined;
    var resolvedType = checker.getTypeOfSymbolAtLocation(optionsPropSymbol, optionsPropSymbol.valueDeclaration);
    if (resolvedType === undefined)
        return undefined;
    var returnType = checker
        .getSignaturesOfType(resolvedType, typescript_1.SignatureKind.Call)
        .find(function (s) { return s.parameters.length === 0; })
        .getReturnType()
        .symbol;
    if (returnType === undefined)
        return undefined;
    var paramDeclarations = returnType.declarations.filter(typescript_1.isTypeParameterDeclaration);
    if (paramDeclarations.length === returnType.declarations.length) {
        if (paramDeclarations.length !== 1)
            throw new Error('Partial declaration of type parameter not expected');
        return paramDeclarations[0].default
            ? checker.getTypeAtLocation(paramDeclarations[0].default).symbol
            : undefined;
    }
    return returnType;
}
function getAllBaseTypes(type) {
    var _a;
    var baseTypes = (0, ts_utils_1.isTypeReference)(type)
        ? type.target.getBaseTypes()
        : type.getBaseTypes();
    return (_a = baseTypes === null || baseTypes === void 0 ? void 0 : baseTypes.flatMap(function (baseType) { return __spreadArray([baseType], getAllBaseTypes(baseType), true); })) !== null && _a !== void 0 ? _a : [];
}
function isWrappable(type) {
    return (0, common_resolving_1.hasTag)(type.symbol, 'wrappable');
}
//# sourceMappingURL=widget-parsing.js.map