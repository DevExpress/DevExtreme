"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDiscoverableSymbols = void 0;
var typescript_1 = require("typescript");
var ts_utils_1 = require("../../common/ts-utils");
function getDiscoverableSymbols(sourceFile, checker) {
    var _a, _b, _c, _d;
    var result = new Set();
    var fileSymbol = checker.getSymbolAtLocation(sourceFile);
    if (fileSymbol) {
        for (var _i = 0, _e = checker.getExportsOfModule(fileSymbol); _i < _e.length; _i++) {
            var symbol = _e[_i];
            result.add(symbol);
        }
    }
    var notExportedSymbolsWithTags = (_d = (_c = (_b = (_a = sourceFile === null || sourceFile === void 0 ? void 0 : sourceFile.statements) === null || _a === void 0 ? void 0 : _a.filter(function (n) {
        var _a;
        return ((0, ts_utils_1.isStatementWithModifiers)(n)
            ? !((_a = n.modifiers) === null || _a === void 0 ? void 0 : _a.some(function (m) { return m.kind === typescript_1.SyntaxKind.ExportKeyword; }))
            : false);
    })) === null || _b === void 0 ? void 0 : _b.filter(function (n) { return (0, typescript_1.getJSDocTags)(n).length > 0; })) === null || _c === void 0 ? void 0 : _c.map(function (n) {
        if ((0, typescript_1.isTypeAliasDeclaration)(n)) {
            return checker.getSymbolAtLocation(n.name);
        }
        return null;
    })) === null || _d === void 0 ? void 0 : _d.filter(function (s) { return s; });
    if (notExportedSymbolsWithTags) {
        for (var _f = 0, notExportedSymbolsWithTags_1 = notExportedSymbolsWithTags; _f < notExportedSymbolsWithTags_1.length; _f++) {
            var symbol = notExportedSymbolsWithTags_1[_f];
            result.add(symbol);
        }
    }
    return Array.from(result);
}
exports.getDiscoverableSymbols = getDiscoverableSymbols;
//# sourceMappingURL=file-reader.js.map