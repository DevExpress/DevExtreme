import { Node, TypeChecker } from 'typescript';
import { DocTag } from '../../common/tags/types';
export declare function parseWidgetExtras(node: Node, tags: DocTag[], checker: TypeChecker, baseDir: string): {
    optionsType: string;
    isWidget: true;
    tags: DocTag[];
} | {
    isWidget: false;
    optionsType?: undefined;
    tags?: undefined;
};
