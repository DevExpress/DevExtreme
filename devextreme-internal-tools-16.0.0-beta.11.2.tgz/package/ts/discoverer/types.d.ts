interface Standard {
    name: 'string' | 'number' | 'any' | 'Array' | 'Record';
}
interface Custom {
    name: string;
    file: string;
}
interface Generic {
    params: GeneralType[];
}
export type GeneralType = {
    cat: 'standard';
} & Standard | {
    cat: 'standard-generic';
} & Standard & Generic | {
    cat: 'custom';
} & Custom | {
    cat: 'custom-generic';
} & Custom & Generic;
export {};
