export type EnumLikeType = {
    kind: 'enum';
    id: string;
    valueType: 'string';
    values: string[];
} | {
    kind: 'enum';
    id: string;
    valueType: 'number';
    values: number[];
};
export interface Root {
    members: Member[];
    types: Record<string, TypeDeclaration | EnumLikeType>;
}
export type Member = {
    id: string;
    tags: MemberTags;
    optional?: boolean;
    type?: TypeRef;
    optionsType?: string;
    typeParameters?: Record<string, GenericParamDeclaration>;
    location?: {
        file: string;
    };
};
export interface MemberTags {
    deprecated?: string[];
    docid?: string[];
    [key: string]: string[];
}
export interface TypeRef {
    name: string;
    file?: string;
}
export type Typing = ValueTyping | ReferenceTyping | GenericTyping | Union | Intersection | FunctionTyping | LiteralTyping;
export interface TypingBase {
    array?: boolean;
    kind: typeof TypingKind[keyof typeof TypingKind];
}
export declare const TypingKind: {
    readonly Value: 0;
    readonly Reference: 1;
    readonly Union: 2;
    readonly Intersection: 3;
    readonly Literal: 4;
    readonly GenericArgument: 5;
    readonly Function: 6;
};
export interface NamedTyping extends TypingBase {
    id: string;
    args?: Typing[];
}
export interface ValueTyping extends NamedTyping {
    kind: typeof TypingKind.Value;
}
export interface ReferenceTyping extends NamedTyping {
    kind: typeof TypingKind.Reference;
    memberId?: string;
}
export interface GenericTyping extends NamedTyping {
    kind: typeof TypingKind.GenericArgument;
    memberId?: string;
}
interface CompositeTyping extends TypingBase {
    types: Typing[];
}
export interface Union extends CompositeTyping {
    kind: typeof TypingKind.Union;
}
export interface Intersection extends CompositeTyping {
    kind: typeof TypingKind.Intersection;
}
export interface LiteralTyping extends TypingBase {
    kind: typeof TypingKind.Literal;
    value: string | number | null;
}
export interface FunctionTyping extends TypingBase {
    kind: typeof TypingKind.Function;
    params?: Record<string, FunctionParam>;
    returnType: Typing;
}
interface FunctionParam {
    type: Typing;
    spread?: boolean;
}
export interface GenericParamDeclaration {
    defaultValue?: Typing;
}
export interface TypeDeclaration {
    kind: 'object';
    typeParams?: Record<string, Typing>;
    props: Record<string, PropDeclaration>;
}
export type PropDeclaration = {
    type: Typing;
} & (OwnProp | InheritedProp);
interface OwnProp {
    readonly?: boolean;
    optional?: boolean;
}
interface InheritedProp {
    inheritedFrom: string;
}
export {};
