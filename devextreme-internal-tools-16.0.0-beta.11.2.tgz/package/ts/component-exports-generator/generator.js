"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createReexportsGenerator = exports.generateComponentReexports = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var typescript_1 = require("typescript");
var prettier_1 = require("prettier");
var logging_1 = require("../logging");
var common_resolving_1 = require("../common/common-resolving");
var helpers_1 = require("../scripts/helpers");
var ts_utils_1 = require("../common/ts-utils");
function generateComponentReexports(targetFiles, compilerOptions) {
    if (compilerOptions === void 0) { compilerOptions = {}; }
    (0, logging_1.log)('Generating component export files...');
    var generateReexports = createReexportsGenerator((0, typescript_1.createProgram)(targetFiles, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {}));
    targetFiles.forEach(function (filePath) {
        var parsedPath = (0, path_1.parse)(filePath);
        var fileName = parsedPath.base.replace(/((.d)?.ts)$/, '');
        var targetFile = "".concat(parsedPath.dir, "/").concat(fileName, "_types.d.ts");
        (0, helpers_1.deleteFile)(targetFile);
        var reexportsFileContents = generateReexports(filePath);
        if (reexportsFileContents) {
            (0, fs_1.writeFileSync)(targetFile, reexportsFileContents);
        }
    });
}
exports.generateComponentReexports = generateComponentReexports;
function createReexportsGenerator(program) {
    var checker = program.getTypeChecker();
    function getExportedMembers(sourceFile) {
        var fileSymbol = checker.getSymbolAtLocation(sourceFile);
        if (!fileSymbol)
            return [];
        return checker.getExportsOfModule(fileSymbol);
    }
    function generateReexports(filePath) {
        var sourceFile = program.getSourceFile(filePath);
        if (sourceFile.text.length === 0) {
            (0, logging_1.log)("Empty file: ".concat(filePath), { lvl: 'warn' });
            return undefined;
        }
        var isPublic = function (s) { return (0, common_resolving_1.hasTag)(s, 'public'); };
        var ignoredExports = new Set(['default', 'ExplicitTypes']);
        var membersToExport = getExportedMembers(sourceFile)
            .filter(function (m) { return !ignoredExports.has(m.name); })
            .reduce(function (result, member) {
            if (isPublic((0, ts_utils_1.getAliasSymbol)(member, checker))) {
                result.push(member.name);
            }
            return result;
        }, []);
        var parsedPath = (0, path_1.parse)(filePath);
        var moduleName = parsedPath.base.replace(/((.d)?.ts)$/, '');
        if (membersToExport.length) {
            (0, logging_1.log)("".concat(membersToExport.length, " public exports found in ").concat(parsedPath.base));
            var fileContents = "export {".concat(membersToExport.join(', '), "} from './").concat(moduleName, "';");
            return (0, prettier_1.format)(fileContents, { parser: 'typescript', singleQuote: true });
        }
        (0, logging_1.log)("No public exports found in ".concat(parsedPath.base));
        return undefined;
    }
    return generateReexports;
}
exports.createReexportsGenerator = createReexportsGenerator;
//# sourceMappingURL=generator.js.map