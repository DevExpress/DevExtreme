import { CompilerOptions, Program } from 'typescript';
export declare function generateComponentReexports(targetFiles: string[], compilerOptions?: CompilerOptions): void;
export declare function createReexportsGenerator(program: Program): (filePath: string) => string;
