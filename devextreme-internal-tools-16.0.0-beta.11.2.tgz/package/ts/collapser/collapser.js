"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCollapseFunction = exports.collapseJSDocs = exports.collapse = void 0;
var fs_1 = require("fs");
var typescript_1 = require("typescript");
var utils_1 = require("../common/utils");
var ts_utils_1 = require("../common/ts-utils");
var logging_1 = require("../logging");
var id_1 = require("../common/id");
var INTERNAL_MEMBER_WARNING = 'Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.';
function collapse(targetDir, exclude, compilerOptions) {
    (0, logging_1.log)('Collapsing Declarations');
    var fileNames = (0, utils_1.enumerateFiles)(targetDir, '.d.ts', exclude);
    var collapseFile = createCollapseFunction((0, ts_utils_1.createProgram)(fileNames, compilerOptions));
    fileNames.forEach(function (path) {
        var content = collapseFile(path);
        if (content) {
            (0, fs_1.writeFileSync)(path, content);
        }
    });
    (0, logging_1.log)("".concat(fileNames.length, " files updated"));
}
exports.collapse = collapse;
function collapseJSDocs(content, compilerOptions) {
    var filePath = 'bundle.d.ts';
    var outputFile = (0, typescript_1.createSourceFile)(filePath, content, typescript_1.ScriptTarget.Latest);
    return createCollapseFunction((0, ts_utils_1.createProgram)([outputFile], compilerOptions))(filePath);
}
exports.collapseJSDocs = collapseJSDocs;
var JSDocableNodesCache = (function () {
    function JSDocableNodesCache() {
        this.items = new Map();
    }
    JSDocableNodesCache.prototype.nodes = function () {
        return Array.from(this.items.values());
    };
    JSDocableNodesCache.prototype.add = function (node) {
        var existingNode = this.items.get(node.node);
        if (!existingNode || node.isExportedNode) {
            this.items.set(node.node, node);
        }
        return existingNode === undefined;
    };
    JSDocableNodesCache.prototype.push = function (nodes) {
        var _this = this;
        nodes.forEach(function (node) { return _this.add(node); });
    };
    return JSDocableNodesCache;
}());
function getDeclarationsFromStatement(statement, checker) {
    if (!(0, typescript_1.isModuleDeclaration)(statement)) {
        return [statement];
    }
    var moduleDeclaration = statement;
    while ((0, typescript_1.isModuleDeclaration)(moduleDeclaration.body)) {
        moduleDeclaration = moduleDeclaration.body;
    }
    if (moduleDeclaration.flags & typescript_1.NodeFlags.GlobalAugmentation) {
        return undefined;
    }
    return getModuleStatements(moduleDeclaration)
        .map(function (node) { return node && getDeclarationsFromStatement(node, checker); }).flat();
    function getModuleStatements(module) {
        var _a;
        var symbol = (_a = checker.getTypeAtLocation(module)) === null || _a === void 0 ? void 0 : _a.getSymbol();
        if (symbol) {
            return checker
                .getExportsOfModule(symbol)
                .map(function (s) { return s.getDeclarations(); })
                .flat();
        }
        if ((0, typescript_1.isModuleBlock)(module.body)) {
            return __spreadArray([], module.body.statements, true);
        }
        return [];
    }
}
function getJSDocableNodes(sourceFile, checker) {
    var _a;
    var fileSymbol = checker.getSymbolAtLocation(sourceFile);
    var exportedMembers = fileSymbol
        ? checker.getExportsOfModule(fileSymbol).map(function (s) { return s.getDeclarations(); }).flat()
        : (_a = sourceFile.statements) === null || _a === void 0 ? void 0 : _a.filter(typescript_1.isModuleDeclaration).map(function (node) { return getDeclarationsFromStatement(node, checker); }).flat().filter(function (s) { return s; });
    var nodesCache = new JSDocableNodesCache();
    for (var _i = 0, _b = (0, utils_1.distinct)(exportedMembers !== null && exportedMembers !== void 0 ? exportedMembers : []); _i < _b.length; _i++) {
        var declaration = _b[_i];
        if (declaration.getSourceFile() !== sourceFile)
            continue;
        if ((0, typescript_1.isExportSpecifier)(declaration)) {
            getMembersFromExportSpecifier(nodesCache, checker, declaration);
            continue;
        }
        if ((0, typescript_1.isExportAssignment)(declaration)) {
            getMembersFromExportAssignment(nodesCache, checker, declaration);
            continue;
        }
        if ((0, typescript_1.isTypeAliasDeclaration)(declaration)) {
            nodesCache.add({ node: declaration, isExportedNode: true });
            getMembersFromTypeAliasDeclaration(nodesCache, checker, declaration);
            continue;
        }
        getMembersFromDeclaration(nodesCache, checker, declaration, true);
    }
    return nodesCache
        .nodes()
        .sort(function (a, b) { return b.node.getStart(sourceFile) - a.node.getStart(sourceFile); });
}
function createCollapseFunction(program) {
    var checker = program.getTypeChecker();
    return function (file) { return collapseFileContent(program.getSourceFile(file), checker); };
}
exports.createCollapseFunction = createCollapseFunction;
function collapseFileContent(sourceFile, checker) {
    var _a, _b, _c, _d, _e, _f;
    var nodes = getJSDocableNodes(sourceFile, checker)
        .filter(function (_a) {
        var _b;
        var node = _a.node, isExportedNode = _a.isExportedNode;
        if (!isExportedNode && !((_b = (0, typescript_1.getJSDocTags)(node)) === null || _b === void 0 ? void 0 : _b.length)) {
            return false;
        }
        return true;
    });
    var sourceText = sourceFile.getFullText();
    var contents = [];
    for (var i = 0; i < nodes.length; i += 1) {
        var _g = nodes[i], node = _g.node, isExportedNode = _g.isExportedNode;
        var tags = (0, typescript_1.getJSDocTags)(node);
        var publicName = (0, ts_utils_1.getJSDocTagValue)(tags.find(function (t) { return t.tagName.text === 'publicName'; }));
        var docidTag = tags.find(function (t) { return t.tagName.text === 'docid'; });
        var constTag = tags.find(function (t) { return t.tagName.text === 'const'; });
        var isPrivate = isExportedNode && tags.find(function (t) { return t.tagName.text === 'public'; }) === undefined;
        var deprecatedTag = tags.find(function (t) { return t.tagName.text === 'deprecated'; });
        var isDeprecated = deprecatedTag !== undefined;
        var docid = '';
        if (docidTag || constTag) {
            docid = (0, ts_utils_1.getJSDocTagValue)(docidTag)
                || (0, ts_utils_1.getJSDocTagValue)(constTag)
                || (0, id_1.getFullyQualifiedName)(getNodeSymbol(node));
        }
        if (docid && publicName && publicName.includes('(')) {
            docid = docid.substring(0, docid.lastIndexOf('.') + 1) + publicName;
        }
        docid = patchMemberName(docid);
        var targetNode = (0, typescript_1.isVariableDeclaration)(node) ? node.parent.parent : node;
        var indent = ((_a = tags[0]) === null || _a === void 0 ? void 0 : _a.parent)
            ? new Array(targetNode.getStart() - tags[0].parent.end).join(' ')
            : (_d = (_c = (_b = targetNode
                .getFullText()
                .match(/^(?<indent> *?)\w/m)) === null || _b === void 0 ? void 0 : _b.groups) === null || _c === void 0 ? void 0 : _c.indent) !== null && _d !== void 0 ? _d : '';
        var separator = "\n".concat(indent);
        var deprecatedMessage = docid ? "[depNote:".concat(docid, "]") : (deprecatedTag === null || deprecatedTag === void 0 ? void 0 : deprecatedTag.comment) || '';
        var comments = __spreadArray(__spreadArray(__spreadArray(__spreadArray([
            '/**'
        ], [docid && " * [descr:".concat(docid, "]")], false), [isDeprecated && " * @deprecated ".concat(deprecatedMessage)], false), [isPrivate && " * @deprecated ".concat(INTERNAL_MEMBER_WARNING)], false), [
            ' */',
        ], false).filter(function (s) { return s; });
        var comment = comments.length > 2 ? "".concat(comments.join(separator)).concat(separator) : '';
        var nodePos = targetNode.getStart();
        if (i === 0) {
            contents.push(sourceText.substring(nodePos));
        }
        contents.push(comment);
        contents.push(sourceText.substring(getPrevNodeStart(nodes, i), ((_e = tags[0]) === null || _e === void 0 ? void 0 : _e.parent) ? (_f = tags[0]) === null || _f === void 0 ? void 0 : _f.parent.pos : nodePos));
    }
    return contents.reverse().join('');
    function getPrevNodeStart(allNodes, curIndex) {
        var _a;
        var node = ((_a = allNodes[curIndex + 1]) !== null && _a !== void 0 ? _a : {}).node;
        if (!node) {
            return 0;
        }
        var targetNode = (0, typescript_1.isVariableDeclaration)(node) ? node.parent.parent : node;
        return targetNode.getStart();
    }
    function getNodeSymbol(node) {
        var symbol = checker.getSymbolAtLocation(node);
        if (!symbol) {
            for (var _i = 0, _a = node.getChildren(); _i < _a.length; _i++) {
                var childNode = _a[_i];
                symbol = checker.getSymbolAtLocation(childNode);
                if (symbol)
                    break;
            }
        }
        return symbol;
    }
    function patchMemberName(name) {
        return name
            .replace(/(?<=\w+)(Methods|Events)/m, '');
    }
}
function getMembersFromSymbol(cache, checker, symbol, targetFile) {
    if (!symbol.declarations) {
        return;
    }
    for (var _i = 0, _a = symbol.declarations; _i < _a.length; _i++) {
        var declaration = _a[_i];
        if (targetFile !== declaration.getSourceFile()) {
            continue;
        }
        if (!cache.add({ node: declaration })) {
            continue;
        }
        var propType = checker.getTypeAtLocation(declaration);
        if ((0, ts_utils_1.isStructuredType)(propType)) {
            getMembersFromPropType(cache, checker, propType, declaration.getSourceFile());
        }
    }
}
function getMembersFromDeclaration(cache, checker, declaration, setExported) {
    if (setExported === void 0) { setExported = false; }
    if (!(0, typescript_1.isTypeLiteralNode)(declaration)) {
        cache.add({ node: declaration, isExportedNode: setExported });
    }
    if ((0, typescript_1.isVariableDeclaration)(declaration)
        || (0, typescript_1.isTypeLiteralNode)(declaration)
        || (0, typescript_1.isClassDeclaration)(declaration)
        || (0, typescript_1.isInterfaceDeclaration)(declaration)) {
        (0, ts_utils_1.getNestedSymbols)(checker.getTypeAtLocation(declaration))
            .forEach(function (s) { return getMembersFromSymbol(cache, checker, s, declaration.getSourceFile()); });
    }
}
function getMembersFromTypeAliasDeclaration(cache, checker, declaration) {
    getMembersFromPropType(cache, checker, checker.getTypeAtLocation(declaration.type), declaration.getSourceFile());
}
function getMembersFromPropType(cache, checker, type, targetFile) {
    for (var _i = 0, _a = (0, ts_utils_1.getTypeSymbols)(type); _i < _a.length; _i++) {
        var symbol = _a[_i];
        var declarations = symbol.getDeclarations();
        if (!declarations)
            continue;
        for (var _b = 0, declarations_1 = declarations; _b < declarations_1.length; _b++) {
            var declaration = declarations_1[_b];
            if (targetFile !== declaration.getSourceFile()) {
                continue;
            }
            getMembersFromDeclaration(cache, checker, declaration);
        }
    }
}
function getMembersFromExportExpression(cache, checker, identifier, targetFile) {
    var declarationSymbol = checker.getSymbolAtLocation(identifier);
    if (declarationSymbol) {
        cache.push(declarationSymbol
            .getDeclarations()
            .filter(function (node) { return targetFile === node.getSourceFile()
            && !(0, typescript_1.isImportClause)(node)
            && !(0, typescript_1.isImportSpecifier)(node); })
            .map(function (node) { return ({ node: node, isExportedNode: true }); }));
    }
    getMembersFromPropType(cache, checker, checker.getTypeAtLocation(identifier), targetFile);
}
function getMembersFromExportSpecifier(cache, checker, declaration) {
    if (declaration.propertyName) {
        getMembersFromExportExpression(cache, checker, declaration.propertyName, declaration.getSourceFile());
    }
}
function getMembersFromExportAssignment(cache, checker, declaration) {
    if ((0, typescript_1.isIdentifier)(declaration.expression)) {
        getMembersFromExportExpression(cache, checker, declaration.expression, declaration.getSourceFile());
    }
}
//# sourceMappingURL=collapser.js.map