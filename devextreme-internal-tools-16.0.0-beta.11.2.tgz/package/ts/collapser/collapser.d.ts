import { CompilerOptions, Program } from 'typescript';
export declare function collapse(targetDir: string, exclude: RegExp | undefined, compilerOptions: CompilerOptions | undefined): void;
export declare function collapseJSDocs(content: string, compilerOptions?: CompilerOptions): string;
export declare function createCollapseFunction(program: Program): (file: string) => string;
