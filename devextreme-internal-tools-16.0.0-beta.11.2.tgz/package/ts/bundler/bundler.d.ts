import { CompilerOptions } from 'typescript';
export declare function bundle(paths: {
    scriptsDir: string;
    outputFile: string;
}, exclude: RegExp | undefined, compilerOptions: CompilerOptions | undefined): void;
export declare function processFiles(files: string[], scriptsDir: string, compilerOptions?: CompilerOptions): string;
