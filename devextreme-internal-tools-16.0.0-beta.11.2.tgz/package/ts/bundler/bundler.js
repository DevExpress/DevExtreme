"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.processFiles = exports.bundle = void 0;
var fs_1 = require("fs");
var path_1 = require("path");
var prettier_1 = require("prettier");
var typescript_1 = require("typescript");
var utils_1 = require("../common/utils");
var ts_utils_1 = require("../common/ts-utils");
var collapser_1 = require("../collapser/collapser");
var logging_1 = require("../logging");
var id_1 = require("../common/id");
var GLOBAL_MODULE_NAME = 'global';
function formatFileContent(content) {
    return (0, prettier_1.format)(content, { parser: 'typescript', singleQuote: true });
}
function bundle(paths, exclude, compilerOptions) {
    (0, logging_1.log)('Creating TS bundle');
    var fileNames = (0, utils_1.enumerateFiles)(paths.scriptsDir, '.d.ts', exclude);
    var bundleContent = processFiles(fileNames, paths.scriptsDir, compilerOptions);
    if (bundleContent) {
        (0, fs_1.writeFileSync)(paths.outputFile, bundleContent);
        (0, logging_1.log)("Bundle saved to ".concat(paths.outputFile));
    }
    else {
        (0, logging_1.log)('Nothing to save');
    }
}
exports.bundle = bundle;
function processFiles(files, scriptsDir, compilerOptions) {
    var _a;
    var program = (0, typescript_1.createProgram)(files, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {});
    var checker = program.getTypeChecker();
    var programFiles = files.map(function (f) { return program.getSourceFile(f); });
    var nodesCache = new Set();
    for (var _i = 0, programFiles_1 = programFiles; _i < programFiles_1.length; _i++) {
        var sourceFile = programFiles_1[_i];
        var fileSymbol = checker.getSymbolAtLocation(sourceFile);
        var exportedMembers = checker.getExportsOfModule(fileSymbol);
        for (var _b = 0, exportedMembers_1 = exportedMembers; _b < exportedMembers_1.length; _b++) {
            var member = exportedMembers_1[_b];
            var nodes = [];
            var _loop_1 = function (declaration) {
                if (!(0, typescript_1.isExportAssignment)(declaration)) {
                    nodes.push(declaration);
                }
                else if ((0, typescript_1.isIdentifier)(declaration.expression)) {
                    nodes.push.apply(nodes, (_a = checker.getSymbolAtLocation(declaration.expression)) === null || _a === void 0 ? void 0 : _a.getDeclarations().filter(function (node) { return declaration.getSourceFile() === node.getSourceFile()
                        && !(0, typescript_1.isImportClause)(node)
                        && !(0, typescript_1.isImportSpecifier)(node); }));
                }
            };
            for (var _c = 0, _d = member.declarations; _c < _d.length; _c++) {
                var declaration = _d[_c];
                _loop_1(declaration);
            }
            nodes.forEach(function (declaration) { return processDeclaration(nodesCache, programFiles, checker, declaration, true); });
        }
    }
    return buildBundle(checker, nodesCache, scriptsDir, compilerOptions);
}
exports.processFiles = processFiles;
function buildBundle(checker, nodesCache, scriptsDir, compilerOptions) {
    var bundleContent = buildModules(checker, nodesCache, scriptsDir)
        .map(function (info) {
        var nodesText = info.members.map(function (member) { return member.getText(); }).join('\n');
        var moduleStr = info.name === GLOBAL_MODULE_NAME ? GLOBAL_MODULE_NAME : "module ".concat(info.name);
        return "declare ".concat(moduleStr, " {\n").concat(nodesText, "\n}");
    })
        .join('\n');
    return (0, collapser_1.collapseJSDocs)(formatFileContent(bundleContent), compilerOptions);
}
function getExplicitNodeNamespace(node) {
    return (0, ts_utils_1.getJSDocTagValue)((0, typescript_1.getJSDocTags)(node).find(function (t) { return t.tagName.text === 'namespace'; }));
}
function getModuleName(node, rootPath) {
    var nameDeclaration = (0, typescript_1.isModuleBlock)(node.parent) ? node.parent.parent.name : undefined;
    if (nameDeclaration && (0, typescript_1.isIdentifier)(nameDeclaration)) {
        return nameDeclaration.text;
    }
    return fileNameToModuleName(getModuleFileName(node, nameDeclaration), rootPath);
}
function fileNameToModuleName(fileName, rootPath) {
    var dir = (0, path_1.dirname)((0, path_1.relative)(rootPath, fileName))
        .split(path_1.sep)
        .shift()
        .replace(/_(\w)/, function (_, p1) { return p1.toUpperCase(); });
    return dir && dir !== '.' ? "DevExpress.".concat(dir) : 'DevExpress';
}
function getModuleFileName(node, moduleName) {
    var fileName = node.getSourceFile().fileName;
    return (moduleName && (0, typescript_1.isStringLiteral)(moduleName))
        ? (0, path_1.join)((0, path_1.dirname)(fileName), moduleName.text)
        : fileName;
}
function getSubmoduleNames(node, checker, rootPath) {
    var _a;
    var sourceFile = node.getSourceFile();
    var fileSymbol = checker.getSymbolAtLocation(sourceFile);
    var classDefaultExport = checker
        .getExportsOfModule(fileSymbol)
        .map(getClassDefaultExport)
        .find(function (d) { return d !== undefined; });
    if (classDefaultExport === undefined || classDefaultExport === node) {
        return undefined;
    }
    return [
        getExplicitNodeNamespace(classDefaultExport) || getModuleName(classDefaultExport, rootPath),
        (_a = classDefaultExport.name) === null || _a === void 0 ? void 0 : _a.text,
    ];
    function getClassDefaultExport(symbol) {
        return (0, ts_utils_1.getSymbolDecalartions)(symbol, checker)
            .filter(function (d) { return d.getSourceFile() === sourceFile; })
            .filter(typescript_1.isClassDeclaration)
            .find(function (d) { return isDefaultDeclaration(d, symbol); });
    }
}
function isDefaultDeclaration(declaration, symbol) {
    var _a, _b;
    return !!((_a = declaration.modifiers) === null || _a === void 0 ? void 0 : _a.find(function (m) { return m.kind === typescript_1.SyntaxKind.DefaultKeyword; }))
        || symbol.name === 'default'
        || !!((_b = declaration.name) === null || _b === void 0 ? void 0 : _b.text.match(/^(Base)[A-Z]/));
}
function getNodeText(checker, node, allNodes) {
    var target = (0, typescript_1.isVariableDeclaration)(node.node)
        ? node.node.parent.parent
        : node.node;
    var text = target
        .getFullText()
        .trim()
        .replace(/\s*\/(\/.*?|\*[^*][\s\S]*?\*\/)$/gm, '')
        .replace(/^declare /m, 'export ')
        .replace('export default ', 'export ');
    var renames = getNodeRenames(node, allNodes, checker);
    if ((renames === null || renames === void 0 ? void 0 : renames.length) > 0) {
        renames.forEach(function (_a) {
            var str = _a[0], replacement = _a[1];
            text = text.replace(new RegExp("([,:<(=>|&\\w]\\s*\\b)".concat(str, "\\b(?![?:(])"), 'gm'), "$1".concat(replacement));
        });
    }
    return text;
}
function buildModules(checker, nodesCache, rootDir) {
    var nodes = new Map();
    var modules = new Map();
    nodesCache.forEach(function (node) {
        var _a;
        var nodeNamespace = getExplicitNodeNamespace(node);
        var submoduleNames = !nodeNamespace ? getSubmoduleNames(node, checker, rootDir) : undefined;
        var moduleName = nodeNamespace || (submoduleNames === null || submoduleNames === void 0 ? void 0 : submoduleNames[0]) || getModuleName(node, rootDir);
        var bNode = {
            node: node,
            module: moduleName,
            submodule: (submoduleNames === null || submoduleNames === void 0 ? void 0 : submoduleNames[1]) || undefined,
        };
        nodes.set(node, bNode);
        var moduleNodes = (_a = modules.get(moduleName)) !== null && _a !== void 0 ? _a : [];
        moduleNodes.push(bNode);
        modules.set(moduleName, moduleNodes);
    });
    var modulesInfo = Array.from(modules)
        .map(function (_a) {
        var moduleName = _a[0], moduleNodes = _a[1];
        return ({
            name: moduleName,
            members: getModuleNodes(checker, moduleNodes, nodes)
                .concat(getModuleSubmodules(checker, moduleNodes, nodes))
                .sort(function (a, b) { return String(a.sortName).localeCompare(b.sortName); }),
        });
    })
        .sort(function (a, b) {
        if (a.name === GLOBAL_MODULE_NAME)
            return -1;
        if (b.name === GLOBAL_MODULE_NAME)
            return 1;
        return String(a.name).localeCompare(b.name);
    });
    return modulesInfo;
}
function getModuleNodes(checker, moduleNodes, allNodes) {
    return moduleNodes
        .filter(function (node) { return !node.submodule; })
        .map(function (node) { return ({
        sortName: (0, id_1.getNodeName)(node.node),
        getText: function () { return getNodeText(checker, node, allNodes); },
    }); });
}
function getModuleSubmodules(checker, moduleNodes, allNodes) {
    var submodules = new Map();
    moduleNodes
        .forEach(function (node) {
        var _a;
        if (!node.submodule) {
            return;
        }
        var submoduleNodes = (_a = submodules.get(node.submodule)) !== null && _a !== void 0 ? _a : [];
        submoduleNodes.push(node);
        submodules.set(node.submodule, submoduleNodes);
    });
    return Array.from(submodules).map(function (_a) {
        var submoduleName = _a[0], submoduleNodes = _a[1];
        return ({
            sortName: submoduleName,
            getText: function () {
                var nodesText = submoduleNodes
                    .sort(function (a, b) { return String((0, id_1.getNodeName)(a.node))
                    .localeCompare((0, id_1.getNodeName)(b.node)); })
                    .map(function (node) { return getNodeText(checker, node, allNodes); }).join('\n');
                return "module ".concat(submoduleName, " {\n").concat(nodesText, "\n}");
            },
        });
    });
}
function getNodeRenames(node, allNodes, checker) {
    return (0, utils_1.distinct)((0, ts_utils_1.getReferencedNodes)(node.node, checker)
        .map(function (tsNode) {
        var targetNode = allNodes.get(resolveReferenceNode(tsNode, checker)[0]);
        if (!targetNode || targetNode.module === GLOBAL_MODULE_NAME) {
            return undefined;
        }
        var nodeNS = (0, id_1.buildQualifiedName)(node.module, node.submodule);
        var targetNodeNS = (0, id_1.buildQualifiedName)(targetNode.module, targetNode.submodule);
        var tsNodeName = (0, id_1.getNodeName)(tsNode);
        var targetNodeName = (0, id_1.getNodeName)(targetNode.node);
        if (tsNodeName && (targetNodeNS !== nodeNS || tsNodeName !== targetNodeName)) {
            return [tsNodeName, !nodeNS.startsWith(targetNodeNS) ? "".concat(targetNodeNS, ".").concat(targetNodeName) : targetNodeName];
        }
        return undefined;
    })
        .filter(function (str) { return str; }), function (item) { return item[0]; });
}
function isNodePublic(node) {
    var tags = (0, typescript_1.getJSDocTags)(node);
    if (!(tags === null || tags === void 0 ? void 0 : tags.length)) {
        return false;
    }
    var hasDocidTag = tags.find(function (t) { return t.tagName.text === 'docid'; });
    var hasConstTag = tags.find(function (t) { return t.tagName.text === 'const'; });
    var hasPublicTag = tags.find(function (t) { return t.tagName.text === 'public'; });
    if (hasPublicTag || hasDocidTag || hasConstTag) {
        return true;
    }
    return false;
}
function processDeclaration(cache, programFiles, checker, declaration, checkPublicity) {
    if (checkPublicity === void 0) { checkPublicity = false; }
    if (!programFiles.find(function (f) { return f === declaration.getSourceFile(); })) {
        return;
    }
    if (!(0, typescript_1.isTypeLiteralNode)(declaration)) {
        if (checkPublicity && !isNodePublic(declaration)) {
            return;
        }
        if (cache.has(declaration)) {
            return;
        }
        cache.add(declaration);
    }
    (0, ts_utils_1.getReferencedNodes)(declaration, checker)
        .forEach(function (refNode) { return resolveReferenceNode(refNode, checker)
        .forEach(function (node) { return processDeclaration(cache, programFiles, checker, node); }); });
}
function resolveReferenceNode(node, checker) {
    if ((0, typescript_1.isTypeReferenceNode)(node)) {
        return resolveTypeReference(node, checker);
    }
    if ((0, typescript_1.isExpressionWithTypeArguments)(node)) {
        return (0, ts_utils_1.getSymbolDecalartions)(checker.getSymbolAtLocation(node.expression), checker);
    }
    return [];
}
function resolveTypeReference(typeNode, checker) {
    var parameterDeclaration = (0, ts_utils_1.getGenericParameterDeclaration)(typeNode, checker);
    if (parameterDeclaration) {
        return [parameterDeclaration];
    }
    if ((0, typescript_1.isIdentifier)(typeNode.typeName)) {
        var symbol = checker.getSymbolAtLocation(typeNode.typeName);
        return (0, ts_utils_1.getSymbolDecalartions)(symbol, checker);
    }
    return [];
}
//# sourceMappingURL=bundler.js.map