import { Node } from 'typescript';
export type Level = keyof typeof levels;
declare const levels: {
    readonly trace: 5;
    readonly debug: 4;
    readonly info: 3;
    readonly warn: 2;
    readonly error: 1;
    readonly fatal: 0;
};
declare const log: (msg: string, options?: {
    lvl?: Level;
    node?: Node;
    e?: any;
}) => void, logStart: () => any, setLogDir: (dir: string) => void, setAreaName: (areaName: string) => void;
export { log, logStart, setLogDir, setAreaName, };
