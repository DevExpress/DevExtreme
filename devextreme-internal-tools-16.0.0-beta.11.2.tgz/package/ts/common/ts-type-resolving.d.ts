import { Symbol, TypeChecker, Type, Node, Declaration, TypeReferenceNode } from 'typescript';
import { Typing, TypeDeclaration, PropDeclaration } from '../discoverer/data-model';
export declare function createTypeProcessor(checker: TypeChecker, baseDir: string): (member: Symbol, tsTypes: Record<string, TypeDeclaration>) => void;
export declare function isExternalDeclaration(declaration: Node): boolean;
interface TypeDescriptor {
    declaration: Declaration;
    propSymbols: Symbol[];
}
export declare function buildTypeDescriptor(type: Type): TypeDescriptor;
export declare function isPublicType(symbol: Symbol): boolean;
export declare function getPropDeclaration(checker: TypeChecker, prop: Symbol, baseDir: string, currentDeclaration?: Declaration): PropDeclaration;
export declare function isMember(node: Node, checker: TypeChecker): boolean;
export declare function isDocumentedTypeReference(node: TypeReferenceNode, checker: TypeChecker): boolean;
export declare function findParamTypeSymbol(node: Node, checker: TypeChecker): Symbol | undefined;
export declare function resolveType(node: Node, checker: TypeChecker, baseDir: string): Typing | undefined;
export {};
