"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveNodeType = exports.getFullTypeName = exports.resolveLiteralType = exports.isGenericArgumentType = exports.isLiteralMemberType = exports.isFunctionMemberType = exports.isNumberLiteralMemberType = exports.isStringLiteralMemberType = void 0;
var typescript_1 = require("typescript");
var utils_1 = require("./utils");
var ts_utils_1 = require("./ts-utils");
var logging_1 = require("../logging");
var common_resolving_1 = require("./common-resolving");
var ts_type_resolving_1 = require("./ts-type-resolving");
var data_model_1 = require("../discoverer/data-model");
var id_1 = require("./id");
function isStringLiteralMemberType(type) {
    return type.id === 'string';
}
exports.isStringLiteralMemberType = isStringLiteralMemberType;
function isNumberLiteralMemberType(type) {
    return type.id === 'number';
}
exports.isNumberLiteralMemberType = isNumberLiteralMemberType;
function isFunctionMemberType(memberType) {
    var type = memberType;
    return !!(type.functionParams || type.functionReturnType);
}
exports.isFunctionMemberType = isFunctionMemberType;
function isLiteralMemberType(memberType) {
    return memberType.value !== undefined;
}
exports.isLiteralMemberType = isLiteralMemberType;
function isGenericArgumentType(memberType) {
    return !!memberType.isGenericArgument;
}
exports.isGenericArgumentType = isGenericArgumentType;
function resolveFunctionType(typeNode, checker, baseDir) {
    if ((0, typescript_1.isFunctionTypeNode)(typeNode)
        || (0, typescript_1.isFunctionDeclaration)(typeNode)
        || (0, typescript_1.isMethodDeclaration)(typeNode)
        || (0, typescript_1.isMethodSignature)(typeNode)) {
        var paramsString = typeNode.parameters
            .map(function (p) { return p.name; })
            .filter(typescript_1.isIdentifier)
            .map(function (n) { return n.escapedText.toString(); })
            .join(', ');
        var returnType = resolveNodeType(typeNode.type, checker, baseDir);
        var funcName = (0, typescript_1.isMethodDeclaration)(typeNode) ? typeNode.name.getText() : 'function';
        return {
            id: "".concat(funcName, "(").concat(paramsString, ")"),
            functionParams: typeNode.parameters.map(function (t) { return getFunctionParameter(t, checker, baseDir); }),
            functionReturnType: returnType === null || returnType === void 0 ? void 0 : returnType.id,
            isCallback: (0, typescript_1.isFunctionTypeNode)(typeNode),
        };
    }
    return undefined;
}
function resolveLiteralType(typeNode) {
    if ((0, typescript_1.isLiteralTypeNode)(typeNode)) {
        if ((0, typescript_1.isStringLiteral)(typeNode.literal)) {
            return { id: 'string', value: typeNode.literal.text };
        }
        var numberValue = (0, ts_utils_1.getNumberLiteralValue)(typeNode);
        if (numberValue !== undefined) {
            return { id: 'number', value: numberValue };
        }
        if (typeNode.literal.kind === typescript_1.SyntaxKind.NullKeyword) {
            return { id: 'null' };
        }
        if (typeNode.literal.kind === typescript_1.SyntaxKind.TrueKeyword) {
            return { id: 'true' };
        }
        if (typeNode.literal.kind === typescript_1.SyntaxKind.FalseKeyword) {
            return { id: 'false' };
        }
        throw Error("Literal of unknown type found: ".concat(typeNode.literal.getText()));
    }
    return undefined;
}
exports.resolveLiteralType = resolveLiteralType;
function resolveTypeReference(node, checker, baseDir) {
    var _a, _b, _c, _d;
    if (!(0, typescript_1.isTypeReferenceNode)(node)) {
        return undefined;
    }
    var paramDeclaration = (0, ts_utils_1.getGenericParameterDeclaration)(node, checker);
    if (paramDeclaration) {
        return paramDeclaration.default && (0, typescript_1.isTypeReferenceNode)(paramDeclaration.default)
            ? { id: "<".concat(resolveTypeReference(paramDeclaration.default, checker, baseDir).id, ">") }
            : buildAny();
    }
    var typeArguments = (_b = (_a = node.typeArguments) === null || _a === void 0 ? void 0 : _a.map(function (t) { return resolveNodeType(t, checker, baseDir); })) === null || _b === void 0 ? void 0 : _b.filter(function (t) { return t; });
    var aliasSymbol = (0, ts_utils_1.getAliasSymbol)(checker.getSymbolAtLocation(node.typeName), checker);
    if ((0, typescript_1.isIdentifier)(node.typeName)) {
        var aliasNode = (_c = aliasSymbol.getDeclarations()) === null || _c === void 0 ? void 0 : _c[0];
        if ((aliasNode && (0, ts_utils_1.isEnumTypeNode)(aliasNode)) || checker.getTypeAtLocation(node).isLiteral()) {
            return {
                id: "Enums.".concat((_d = aliasSymbol === null || aliasSymbol === void 0 ? void 0 : aliasSymbol.getEscapedName()) !== null && _d !== void 0 ? _d : node.typeName.getText()),
            };
        }
    }
    var typeName = (0, typescript_1.isIdentifier)(node.typeName)
        ? node.typeName.text
        : node.typeName.getText();
    var fullTypeName = getFullTypeName(aliasSymbol, typeName, checker, baseDir, typeArguments);
    return (typeArguments === null || typeArguments === void 0 ? void 0 : typeArguments.length)
        ? {
            id: fullTypeName,
            typeArguments: typeArguments,
        }
        : {
            id: fullTypeName,
        };
}
function getFullTypeName(symbol, typeName, checker, baseDir, typeArguments) {
    var sep = typeName === 'Record' ? ',' : '|';
    var parameterizedBy = (typeArguments === null || typeArguments === void 0 ? void 0 : typeArguments.length)
        ? "<".concat(typeArguments.map(function (t) { return t === null || t === void 0 ? void 0 : t.id; }).join(sep), ">")
        : '';
    if (!isBuiltInType(symbol, checker) && parameterizedBy) {
        return typeName;
    }
    if ((0, common_resolving_1.hasDocId)(symbol, checker) || (0, ts_type_resolving_1.isExternalDeclaration)(symbol.declarations[0])) {
        return "".concat(typeName).concat(parameterizedBy);
    }
    var module = (0, ts_utils_1.getModule)(symbol.declarations[0], baseDir);
    return "{".concat(module, ".").concat(typeName).concat(parameterizedBy, "}");
}
exports.getFullTypeName = getFullTypeName;
function isBuiltInType(symbol, checker) {
    var isArrayType = checker.isArrayType(checker.getDeclaredTypeOfSymbol(symbol));
    return isArrayType || (0, ts_utils_1.isPromiseType)(symbol);
}
function resolveUnionType(typeNode, checker, baseDir) {
    if ((0, ts_utils_1.isUnionOrIntersectionTypeNode)(typeNode)) {
        var types = typeNode.types
            .map(function (t) { return resolveNodeType(t, checker, baseDir); })
            .filter(function (t) { return t === null || t === void 0 ? void 0 : t.id; });
        var result = {
            id: (0, utils_1.distinct)(types.map(function (t) { return t.id; })).join('|'),
            typeArguments: types,
        };
        return result;
    }
    return undefined;
}
function getFunctionParameter(parameter, checker, baseDir) {
    if ((0, typescript_1.isIdentifier)(parameter.name)) {
        if (!parameter.type) {
            return { id: parameter.name.escapedText.toString() };
        }
        var paramType = resolveNodeType(parameter.type, checker, baseDir);
        var paramTypeIsDocumented = (0, typescript_1.isTypeReferenceNode)(parameter.type)
            && (0, ts_type_resolving_1.isDocumentedTypeReference)(parameter.type, checker);
        return {
            id: "".concat(parameter.name.escapedText, ":").concat(paramType === null || paramType === void 0 ? void 0 : paramType.id),
            fields: !paramTypeIsDocumented
                ? (0, utils_1.undefinedOrNonEmpty)(getParameterFields(parameter.type, checker, baseDir))
                : undefined,
        };
    }
    return undefined;
}
function getParameterFields(paramType, checker, baseDir) {
    var _a;
    if ((0, typescript_1.isTypeLiteralNode)(paramType)) {
        return paramType.members.map(function (member) {
            var _a, _b;
            if ((0, typescript_1.isPropertySignature)(member) && (0, typescript_1.isIdentifier)(member.name)) {
                return {
                    name: (_a = member.name.escapedText) === null || _a === void 0 ? void 0 : _a.toString(),
                    type: (_b = resolveNodeType(member.type, checker, baseDir)) === null || _b === void 0 ? void 0 : _b.id,
                    flags: getMemberFlags(member),
                };
            }
            return undefined;
        }).filter(function (field) { return field !== undefined; });
    }
    if ((0, ts_utils_1.isUnionOrIntersectionTypeNode)(paramType) || (0, ts_utils_1.isTypeLikeDeclaration)(paramType)) {
        var tp = checker.getTypeAtLocation(paramType);
        var properties = tp.getProperties();
        var fields = (_a = properties === null || properties === void 0 ? void 0 : properties.filter(function (prop) { return !prop.declarations.some(ts_type_resolving_1.isExternalDeclaration); })) === null || _a === void 0 ? void 0 : _a.map(function (prop) {
            var symbol = getPropetySymbol(prop, checker);
            var typing = (0, ts_type_resolving_1.resolveType)(symbol.declarations[0], checker, baseDir);
            var typeName = typingName(typing);
            var parameter = getParameter(prop.declarations[0], checker, baseDir);
            return {
                name: prop.escapedName.toString(),
                type: parameter ? "".concat(typeName, "<").concat(parameter, ">") : typeName,
            };
        });
        return fields;
    }
    return undefined;
}
function isNodeWithTypeArguments(node) {
    return 'typeArguments' in node;
}
function getParameter(declaration, checker, baseDir) {
    var _a, _b;
    if (!(0, typescript_1.isPropertySignature)(declaration))
        return undefined;
    if (declaration.type && isNodeWithTypeArguments(declaration.type)) {
        var typeNode = (_a = declaration.type.typeArguments) === null || _a === void 0 ? void 0 : _a[0];
        if (!typeNode)
            return undefined;
        var memberType = resolveNodeType(typeNode, checker, baseDir);
        return (_b = memberType.typeArguments) === null || _b === void 0 ? void 0 : _b.map(function (arg) { return arg.id; }).join('|');
    }
    return undefined;
}
function getPropetySymbol(property, checker) {
    var declaration = property.declarations[0];
    if ((0, typescript_1.isPropertySignature)(declaration) && (0, typescript_1.isTypeReferenceNode)(declaration.type)) {
        return checker.getSymbolAtLocation(declaration.type.typeName);
    }
    return property;
}
function typingName(typing) {
    var _a;
    switch (typing.kind) {
        case data_model_1.TypingKind.Value:
            return typing.id;
        case data_model_1.TypingKind.Reference:
            if (typing.memberId)
                return typing.memberId;
            return typing.id.includes('.') ? "{".concat(typing.id, "}") : typing.id;
        case data_model_1.TypingKind.GenericArgument:
            return (_a = typing.memberId) !== null && _a !== void 0 ? _a : typing.id;
        case data_model_1.TypingKind.Function:
            return 'function';
        case data_model_1.TypingKind.Intersection:
            return typing.types.map(function (t) { return typingName(t); }).join('&');
        case data_model_1.TypingKind.Union:
            return typing.types.map(function (t) { return typingName(t); }).join('|');
        case data_model_1.TypingKind.Literal:
            return typing.value.toString();
        default:
            var n = typing;
            return n;
    }
}
function getMemberFlags(declaration) {
    var flags = [];
    if ((0, ts_utils_1.isReadonlyMember)(declaration))
        flags.push('readonly');
    if ((0, ts_utils_1.isOptionalMember)(declaration))
        flags.push('optional');
    return flags;
}
function resolveArrayType(node, checker, baseDir) {
    if (!(0, typescript_1.isArrayTypeNode)(node))
        return undefined;
    var elementType = resolveNodeType(node.elementType, checker, baseDir);
    return {
        id: "Array<".concat(elementType.id, ">"),
        typeArguments: elementType.typeArguments,
    };
}
function resolveThisType(node, checker) {
    var _a, _b, _c;
    if (!(0, typescript_1.isThisTypeNode)(node))
        return undefined;
    var declaration = (_c = (_b = (_a = checker.getTypeAtLocation(node)) === null || _a === void 0 ? void 0 : _a.getSymbol()) === null || _b === void 0 ? void 0 : _b.getDeclarations()) === null || _c === void 0 ? void 0 : _c[0];
    var name = declaration && (0, id_1.getExportName)(declaration, checker);
    return name ? {
        id: name,
    } : undefined;
}
function resolveNodeType(node, checker, baseDir) {
    if (node === undefined) {
        return undefined;
    }
    try {
        return (0, common_resolving_1.resolveValueType)(node)
            || resolveFunctionType(node, checker, baseDir)
            || resolveNodeType((0, common_resolving_1.getParenthesizedType)(node), checker, baseDir)
            || resolveLiteralType(node)
            || resolveTypeReference(node, checker, baseDir)
            || resolveUnionType(node, checker, baseDir)
            || resolveArrayType(node, checker, baseDir)
            || resolveThisType(node, checker)
            || (0, common_resolving_1.resolveTypeOperator)(node)
            || (0, common_resolving_1.resolveNonSupportedType)(node);
    }
    catch (e) {
        (0, logging_1.log)('Unable to resolve node type', { lvl: 'error', node: node });
        throw e;
    }
}
exports.resolveNodeType = resolveNodeType;
function buildAny() {
    return {
        id: (0, ts_utils_1.getValueType)(typescript_1.SyntaxKind.AnyKeyword),
    };
}
//# sourceMappingURL=type-resolving.js.map