"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateTags = void 0;
var type_resolving_1 = require("../type-resolving");
var parameter_field_tag_1 = require("./parameter-field-tag");
function generateTags(memberType, symbol, generateAcceptValues, checker, baseDir) {
    return memberType ? [
        generateTypeTag(memberType),
        generateFunctionTypeTags(memberType, symbol, checker, baseDir),
        generateAcceptValues ? generateAcceptValuesTag(memberType) : [],
    ].flat() : [];
}
exports.generateTags = generateTags;
function generateTypeTag(memberType) {
    if ((0, type_resolving_1.isFunctionMemberType)(memberType) && !memberType.isCallback)
        return [];
    return [{ name: 'type', value: memberType.id }];
}
function generateFunctionTypeTags(memberType, symbol, checker, baseDir) {
    if ((0, type_resolving_1.isFunctionMemberType)(memberType)) {
        return getFunctionMemberTags(memberType);
    }
    if (memberType.typeArguments) {
        for (var _i = 0, _a = memberType.typeArguments; _i < _a.length; _i++) {
            var typeArgument = _a[_i];
            var result = generateFunctionTypeTags(typeArgument, symbol, checker, baseDir);
            if (result.length)
                return result;
        }
    }
    return [];
}
function generateAcceptValuesTag(memberType) {
    var _a;
    if ((_a = memberType.typeArguments) === null || _a === void 0 ? void 0 : _a.length) {
        var literalArgs = memberType.typeArguments
            .filter(type_resolving_1.isLiteralMemberType)
            .map(function (t) { return t.value; });
        if (literalArgs.length) {
            return [{ name: 'acceptValues', value: literalArgs.map(stringifyEnumValue).join('|') }];
        }
        for (var _i = 0, _b = memberType.typeArguments; _i < _b.length; _i++) {
            var typeArg = _b[_i];
            var result = generateAcceptValuesTag(typeArg);
            if (result.length)
                return result;
        }
    }
    return [];
}
function stringifyEnumValue(value) {
    return typeof value === 'string' ? "'".concat(value, "'") : value.toString();
}
function getFunctionMemberTags(memberType) {
    var _a;
    var paramTypeTag = memberType.isCallback ? 'type_function_param' : 'param';
    var returnTypeTag = memberType.isCallback ? 'type_function_return' : 'return';
    var contextTypeTag = 'type_function_context';
    var hasParams = (_a = memberType.functionParams) === null || _a === void 0 ? void 0 : _a.length;
    var result = [];
    if (hasParams) {
        var firstParam = memberType.functionParams[0];
        var hasContext = firstParam.id.includes('this:');
        if (hasContext) {
            if (!memberType.isCallback) {
                throw new Error("Callback is not expected to have this context: '".concat(memberType.id, "'"));
            }
            memberType.functionParams.shift();
            result.push({ name: contextTypeTag, value: firstParam.id.split(':').pop() });
        }
        result.push.apply(result, memberType.functionParams.flatMap(function (param, i) { return __spreadArray([
            paramTag(param, i)
        ], fieldTags(param, i), true); }));
    }
    if (memberType.functionReturnType) {
        result.push({ name: "".concat(returnTypeTag), value: memberType.functionReturnType });
    }
    return result;
    function paramTag(param, paramIndex) {
        return { name: "".concat(paramTypeTag).concat(paramIndex + 1), value: param.id };
    }
    function fieldTags(param, paramIndex) {
        var _a, _b;
        return ((_a = param.fields) === null || _a === void 0 ? void 0 : _a.length)
            ? (_b = param.fields) === null || _b === void 0 ? void 0 : _b.map(function (field) { return (0, parameter_field_tag_1.buildParamFieldDocTag)(field, "".concat(paramTypeTag).concat(paramIndex + 1, "_")); }) : [];
    }
}
//# sourceMappingURL=generating.js.map