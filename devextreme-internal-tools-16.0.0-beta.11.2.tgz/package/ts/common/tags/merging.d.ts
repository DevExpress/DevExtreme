import { Level } from '../../logging';
import { TagKind } from './comparing';
import { DocTag } from './types';
export declare function mergeTags(declaredTags: DocTag[], generatedTags: DocTag[], reportDuplicate: (message: string, lvl?: Level) => void): DocTag[];
declare function getTagKey(tag: DocTag): string;
declare function equalTagValues(a: string, b: string, kind: TagKind): boolean;
export declare const TESTING: {
    mergeTags: typeof mergeTags;
    equalTagValues: typeof equalTagValues;
    getTagKey: typeof getTagKey;
};
export {};
