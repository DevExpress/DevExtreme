"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TESTING = exports.mergeTags = void 0;
var comparing_1 = require("./comparing");
var utils_1 = require("../utils");
var id_1 = require("../id");
function mergeTags(declaredTags, generatedTags, reportDuplicate) {
    var exTags = declaredTags.reduce(function (acc, tag) {
        var key = getTagKey(tag);
        if (acc[key] !== undefined) {
            reportDuplicate("".concat(acc[key].name, " tag overwrites it's previous declaration:\n")
                + "".concat(acc[key].value, " -> ").concat(tag.value, "}"), 'warn');
        }
        acc[key] = tag;
        return acc;
    }, {});
    var declaredUidParams = declaredTags
        .filter(function (t) { return t.name.match(/^type_function_param\d+$/); })
        .filter(function (t) { return (0, id_1.isEscapedId)(t.value.substring(t.value.indexOf(':') + 1)); })
        .map(function (t) { return t.name; });
    var result = declaredTags.filter((0, utils_1.not)(isHiddenTag));
    var _loop_1 = function (key, tag) {
        if (declaredUidParams.some(function (k) { return key.startsWith(k); })) {
            return "continue";
        }
        var declaredTag = exTags[key];
        if (declaredTag === undefined) {
            result.push(tag);
            return "continue";
        }
        if (equalTagValues(declaredTag.value, tag.value, getTagsKind(declaredTag, tag))) {
            reportDuplicate("\"@".concat(declaredTag.name, " ").concat(declaredTag.value, "\" tag can be deleted.\n")
                + "Generated value: ".concat(tag.value), 'warn');
        }
    };
    for (var _i = 0, _a = generatedTags.map(function (t) { return ({ key: getTagKey(t), tag: t }); }); _i < _a.length; _i++) {
        var _b = _a[_i], key = _b.key, tag = _b.tag;
        _loop_1(key, tag);
    }
    return result;
}
exports.mergeTags = mergeTags;
function isHiddenTag(tag) {
    switch ((0, comparing_1.getTagKind)(tag)) {
        case 'paramField':
            return tag.value.endsWith('::hidden');
        default:
            return false;
    }
}
function getTagsKind(a, b) {
    var aKind = (0, comparing_1.getTagKind)(a);
    var bKind = (0, comparing_1.getTagKind)(b);
    if (aKind !== bKind) {
        throw new Error("Different tags have same key: ".concat(a.name, ", ").concat(b.name));
    }
    return aKind;
}
function getTagKey(tag) {
    switch ((0, comparing_1.getTagKind)(tag)) {
        case 'paramField': {
            var name = paramFieldValueRegex.exec(tag.value).groups.name;
            return "".concat(tag.name, ":").concat(name);
        }
        case 'defaultValue': {
            var target = defaultValueRegex.exec(tag.value).groups.target;
            return target ? "".concat(tag.name, ":").concat(target) : tag.name;
        }
        case 'firedEvent':
            return "".concat(tag.name, ":").concat(tag.value);
        case 'other':
            return tag.name;
    }
}
var defaultValueRegex = /^(?<value>.+?)( .*&(for|prop)\((?<target>.+?)\))?$/;
var paramFieldValueRegex = /^(?<name>.+?)(\(.+?\))?(:.+)*?$/;
function equalTagValues(a, b, kind) {
    switch (kind) {
        case 'paramField':
            return check(function (value) { return value.toLowerCase()
                .replace(/,/g, '|')
                .replace(/ +/g, '')
                .replace(/:optional$/, ''); });
        case 'acceptedValues':
            return check(function (value) { return value.replace(/"/g, "'").replace(/ /g, ''); });
        default:
            return a === b;
    }
    function check(normalize) {
        return normalize(a) === normalize(b);
    }
}
exports.TESTING = {
    mergeTags: mergeTags,
    equalTagValues: equalTagValues,
    getTagKey: getTagKey,
};
//# sourceMappingURL=merging.js.map