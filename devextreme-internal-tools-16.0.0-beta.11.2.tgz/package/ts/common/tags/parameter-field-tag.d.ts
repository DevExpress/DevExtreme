import { DocTag } from './types';
export interface FunctionTypeParamField {
    name: string;
    type: string;
    flags?: string[];
}
export declare function buildParamFieldDocTag({ name, type, flags }: FunctionTypeParamField, prefix: string): DocTag;
