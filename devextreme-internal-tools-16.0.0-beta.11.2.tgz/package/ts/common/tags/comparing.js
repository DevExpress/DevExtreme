"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTagKind = void 0;
function getTagKind(tag) {
    if (tag.name === 'default')
        return 'defaultValue';
    if (tag.name === 'fires')
        return 'firedEvent';
    if (tag.name === 'acceptValues')
        return 'acceptedValues';
    if (fieldTagRegex.test(tag.name))
        return 'paramField';
    return 'other';
}
exports.getTagKind = getTagKind;
var fieldTagRegex = /^(type_function_)?param\d+_field.*/;
//# sourceMappingURL=comparing.js.map