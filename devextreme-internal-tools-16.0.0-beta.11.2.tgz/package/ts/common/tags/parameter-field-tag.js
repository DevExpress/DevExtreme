"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildParamFieldDocTag = void 0;
function buildParamFieldDocTag(_a, prefix) {
    var name = _a.name, type = _a.type, flags = _a.flags;
    return {
        name: "".concat(prefix, "field"),
        value: (flags === null || flags === void 0 ? void 0 : flags.length) ? "".concat(name, ":").concat(type, ":").concat(flags.join('&')) : "".concat(name, ":").concat(type),
    };
}
exports.buildParamFieldDocTag = buildParamFieldDocTag;
//# sourceMappingURL=parameter-field-tag.js.map