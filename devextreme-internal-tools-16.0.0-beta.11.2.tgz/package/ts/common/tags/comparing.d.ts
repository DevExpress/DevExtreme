import { DocTag } from './types';
export type TagKind = ReturnType<typeof getTagKind>;
export declare function getTagKind(tag: DocTag): "other" | "defaultValue" | "firedEvent" | "acceptedValues" | "paramField";
