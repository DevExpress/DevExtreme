import { Symbol, TypeChecker } from 'typescript';
import { MemberType } from '../type-resolving';
import { DocTag } from './types';
export declare function generateTags(memberType: MemberType, symbol: Symbol, generateAcceptValues: boolean, checker: TypeChecker, baseDir: string): DocTag[];
