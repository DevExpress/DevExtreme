import { Node, TypeChecker, Symbol } from 'typescript';
import { FunctionTypeParamField } from './tags/parameter-field-tag';
export interface MemberType {
    id: string;
    typeArguments?: MemberType[];
}
export interface FunctionTypeParam {
    id: string;
    fields?: FunctionTypeParamField[];
}
export interface FunctionMemberType extends MemberType {
    functionParams?: FunctionTypeParam[];
    functionReturnType?: string;
    isCallback?: boolean;
}
export interface StringLiteralMemberType extends MemberType {
    id: 'string';
    value: string;
}
export interface NumberLiteralMemberType extends MemberType {
    id: 'number';
    value: number;
}
interface BooleanLiteralMemberType extends MemberType {
    id: 'false' | 'true';
}
interface NullLiteralMemberType extends MemberType {
    id: 'null';
}
export type LiteralMemberType = StringLiteralMemberType | NumberLiteralMemberType | BooleanLiteralMemberType | NullLiteralMemberType;
export declare function isStringLiteralMemberType(type: LiteralMemberType): type is StringLiteralMemberType;
export declare function isNumberLiteralMemberType(type: LiteralMemberType): type is NumberLiteralMemberType;
export interface GenericArgumentType extends MemberType {
    isGenericArgument: boolean;
}
export declare function isFunctionMemberType(memberType: MemberType): memberType is FunctionMemberType;
export declare function isLiteralMemberType(memberType: MemberType): memberType is StringLiteralMemberType | NumberLiteralMemberType;
export declare function isGenericArgumentType(memberType: MemberType): memberType is GenericArgumentType;
export declare function resolveLiteralType(typeNode: Node): LiteralMemberType | undefined;
export declare function getFullTypeName(symbol: Symbol, typeName: string, checker: TypeChecker, baseDir: string, typeArguments: MemberType[]): string;
export declare function resolveNodeType(node: Node, checker: TypeChecker, baseDir: string): MemberType | undefined;
export {};
