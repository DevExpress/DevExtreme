import { Node, TypeNode, Symbol, TypeChecker } from 'typescript';
import { ValueTyping } from '../discoverer/data-model';
export declare function resolveValueType(node: Node): ValueTyping | undefined;
export declare function resolveNonSupportedType(node: Node): ValueTyping | undefined;
export declare function getParenthesizedType(node: Node): TypeNode | undefined;
export declare function hasTag(symbol: Symbol, tagName: string): boolean;
export declare function hasDocId(symbol: Symbol, checker: TypeChecker): boolean;
export declare function hasDocIdTag(symbol: Symbol): boolean;
export declare function resolveTypeOperator(node: Node): {
    id: string;
} | undefined;
