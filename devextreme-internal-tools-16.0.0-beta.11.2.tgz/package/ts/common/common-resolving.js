"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveTypeOperator = exports.hasDocIdTag = exports.hasDocId = exports.hasTag = exports.getParenthesizedType = exports.resolveNonSupportedType = exports.resolveValueType = void 0;
var typescript_1 = require("typescript");
var data_model_1 = require("../discoverer/data-model");
var ts_utils_1 = require("./ts-utils");
function resolveValueType(node) {
    var id = (0, ts_utils_1.getValueType)(node.kind);
    if (!id)
        return undefined;
    return {
        id: id,
        kind: data_model_1.TypingKind.Value,
    };
}
exports.resolveValueType = resolveValueType;
function resolveNonSupportedType(node) {
    if ((0, typescript_1.isConditionalTypeNode)(node)
        || (0, typescript_1.isIndexedAccessTypeNode)(node)
        || (0, typescript_1.isPropertyDeclaration)(node)) {
        return {
            kind: data_model_1.TypingKind.Value,
            id: (0, ts_utils_1.getValueType)(typescript_1.SyntaxKind.AnyKeyword),
        };
    }
    return undefined;
}
exports.resolveNonSupportedType = resolveNonSupportedType;
function getParenthesizedType(node) {
    return (0, typescript_1.isParenthesizedTypeNode)(node) ? node.type : undefined;
}
exports.getParenthesizedType = getParenthesizedType;
function hasTag(symbol, tagName) {
    return symbol.getJsDocTags().find(function (t) { return t.name === tagName; }) !== undefined;
}
exports.hasTag = hasTag;
function hasDocId(symbol, checker) {
    var _a;
    if (((_a = symbol === null || symbol === void 0 ? void 0 : symbol.declarations) === null || _a === void 0 ? void 0 : _a[0]) === undefined)
        return false;
    if (hasDocIdTag(symbol))
        return true;
    return checker
        .getTypeAtLocation(symbol.declarations[0])
        .getProperties()
        .some(hasDocIdTag);
}
exports.hasDocId = hasDocId;
function hasDocIdTag(symbol) {
    return hasTag(symbol, 'docid');
}
exports.hasDocIdTag = hasDocIdTag;
function resolveTypeOperator(node) {
    if ((0, typescript_1.isTypeOperatorNode)(node)) {
        switch (node.operator) {
            case typescript_1.SyntaxKind.KeyOfKeyword: return { id: 'string' };
        }
    }
    return undefined;
}
exports.resolveTypeOperator = resolveTypeOperator;
//# sourceMappingURL=common-resolving.js.map