"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveType = exports.findParamTypeSymbol = exports.isDocumentedTypeReference = exports.isMember = exports.getPropDeclaration = exports.isPublicType = exports.buildTypeDescriptor = exports.isExternalDeclaration = exports.createTypeProcessor = void 0;
var path_1 = require("path");
var typescript_1 = require("typescript");
var utils_1 = require("./utils");
var ts_utils_1 = require("./ts-utils");
var data_model_1 = require("../discoverer/data-model");
var logging_1 = require("../logging");
var common_resolving_1 = require("./common-resolving");
var id_1 = require("./id");
var utilityTypes = new Set(['Pick', 'Omit']);
function createTypeProcessor(checker, baseDir) {
    var visitedMembers = new Set();
    return function (member, tsTypes) { return processTypes(member, tsTypes, checker, baseDir, visitedMembers); };
}
exports.createTypeProcessor = createTypeProcessor;
function processTypes(member, tsTypes, checker, baseDir, visitedMembers) {
    var _a, _b;
    var declaration = member.declarations[0];
    if (isExternalDeclaration(declaration))
        return;
    if ((checker.getTypeAtLocation(declaration).flags === typescript_1.TypeFlags.Any)) {
        return;
    }
    var fileName = declaration.getSourceFile().fileName;
    var uniqueName = "".concat(fileName, ".").concat(member.escapedName.toString());
    if (visitedMembers.has(uniqueName))
        return;
    visitedMembers.add(uniqueName);
    for (var _i = 0, _c = Object.entries(getTsTypes(checker, member, baseDir, tsTypes, visitedMembers)); _i < _c.length; _i++) {
        var _d = _c[_i], typeKey = _d[0], typeEntry = _d[1];
        if (!utilityTypes.has(typeKey) && (!tsTypes[typeKey] || typeKey.endsWith(".".concat(member.escapedName)))) {
            tsTypes[typeKey] = typeEntry;
        }
    }
    var type = checker.getTypeAtLocation(member.declarations[0]);
    (_b = (_a = type.symbol) === null || _a === void 0 ? void 0 : _a.members) === null || _b === void 0 ? void 0 : _b.forEach(function (m) { return processTypes(m, tsTypes, checker, baseDir, visitedMembers); });
}
function isExternalDeclaration(declaration) {
    return declaration.getSourceFile().fileName.includes('node_modules');
}
exports.isExternalDeclaration = isExternalDeclaration;
function getTsTypes(checker, symbol, baseDir, tsTypes, visitedMembers) {
    var _a;
    var _b, _c, _d, _e;
    var result = {};
    var type = checker.getTypeAtLocation(symbol.declarations[0]);
    if (isExternalDeclaration(symbol.declarations[0])) {
        return result;
    }
    if (type.flags === typescript_1.TypeFlags.Any) {
        return _a = {},
            _a[symbol.escapedName.toString()] = {
                kind: 'object',
                props: {},
            },
            _a;
    }
    if (!(0, ts_utils_1.isTypeLikeDeclaration)((_c = (_b = type.aliasSymbol) === null || _b === void 0 ? void 0 : _b.declarations) === null || _c === void 0 ? void 0 : _c[0])
        && !(0, ts_utils_1.isTypeLikeDeclaration)((_e = (_d = type.symbol) === null || _d === void 0 ? void 0 : _d.declarations) === null || _e === void 0 ? void 0 : _e[0])) {
        return {};
    }
    var descr = buildTypeDescriptor(type);
    var typeId = (0, id_1.getNodeId)(descr.declaration, checker, baseDir);
    if (isExternalDeclaration(descr.declaration) && !utilityTypes.has(typeId)) {
        return {};
    }
    add(typeId, descr, false);
    if ((0, typescript_1.isTypeAliasDeclaration)(symbol.declarations[0])) {
        var aliasId = (0, id_1.getNodeId)(symbol.declarations[0], checker, baseDir);
        add(aliasId, descr, utilityTypes.has(typeId));
    }
    var baseTypes = getBaseTypes(type);
    if (!baseTypes) {
        return result;
    }
    for (var _i = 0, baseTypes_1 = baseTypes; _i < baseTypes_1.length; _i++) {
        var baseType = baseTypes_1[_i];
        if (baseType.aliasSymbol !== undefined) {
            processTypes(baseType.aliasSymbol, tsTypes, checker, baseDir, visitedMembers);
        }
        var baseTypeDescr = buildTypeDescriptor(baseType);
        var baseTypeId = (0, id_1.getNodeId)(baseTypeDescr.declaration, checker, baseDir);
        add(baseTypeId, baseTypeDescr, false);
    }
    return result;
    function add(id, _a, aliasToUtilType) {
        var _b, _c;
        var declaration = _a.declaration, propSymbols = _a.propSymbols;
        if (!(0, ts_utils_1.isTypeDeclaration)(declaration)) {
            var err = new Error('TsType resolver: unexpected declaration type');
            (0, logging_1.log)(err.message, { lvl: 'error', node: declaration });
            throw err;
        }
        var props = (_c = (_b = propSymbols === null || propSymbols === void 0 ? void 0 : propSymbols.filter(function (propSymbol) { return !isIgnoredProp(propSymbol.declarations[0]); })) === null || _b === void 0 ? void 0 : _b.sort(function (a, b) { return a.escapedName.toString().localeCompare(b.escapedName.toString()); })) === null || _c === void 0 ? void 0 : _c.reduce(function (acc, propSymbol) {
            acc[propSymbol.escapedName.toString()] = getPropDeclaration(checker, propSymbol, baseDir, declaration);
            return acc;
        }, {});
        var typeParams = aliasToUtilType
            ? {}
            : { typeParams: getTypeParams(declaration, checker, baseDir) };
        result[id] = __assign({ kind: 'object', props: props }, typeParams);
        function isIgnoredProp(propDeclaration) {
            return (0, typescript_1.isGetAccessorDeclaration)(propDeclaration)
                || (0, typescript_1.isParameter)(propDeclaration);
        }
    }
}
function buildTypeDescriptor(type) {
    var _a;
    return {
        declaration: (_a = (0, ts_utils_1.getTypeSymbol)(type)) === null || _a === void 0 ? void 0 : _a.declarations[0],
        propSymbols: type.getProperties(),
    };
}
exports.buildTypeDescriptor = buildTypeDescriptor;
function getTypeParams(typeDeclaration, checker, baseDir) {
    if (!typeDeclaration.typeParameters)
        return undefined;
    var result = {};
    typeDeclaration.typeParameters.forEach(function (p) {
        var typeName = p.name.escapedText.toString();
        var typeDefault = p.default ? resolveType(p.default, checker, baseDir) : undefined;
        result[typeName] = typeDefault || null;
    });
    return result;
}
function getBaseTypes(typeObject) {
    return typeObject.isIntersection()
        ? typeObject.types.filter(function (t) { var _a; return !(0, typescript_1.isTypeLiteralNode)((_a = (0, ts_utils_1.getTypeSymbol)(t)) === null || _a === void 0 ? void 0 : _a.declarations[0]); })
        : typeObject.getBaseTypes();
}
function isPublicType(symbol) {
    return (0, common_resolving_1.hasTag)(symbol, 'public')
        && !(0, common_resolving_1.hasTag)(symbol, 'docid')
        && ((0, typescript_1.isTypeAliasDeclaration)(symbol.declarations[0])
            || (0, typescript_1.isInterfaceDeclaration)(symbol.declarations[0]));
}
exports.isPublicType = isPublicType;
function getPropDeclaration(checker, prop, baseDir, currentDeclaration) {
    var propDeclaration = prop.declarations[0];
    var currentId = currentDeclaration
        ? (0, id_1.getNodeId)(currentDeclaration, checker, baseDir)
        : undefined;
    if (!(0, typescript_1.isPropertySignature)(propDeclaration)
        && !(0, typescript_1.isPropertyDeclaration)(propDeclaration)
        && !(0, typescript_1.isMethodSignature)(propDeclaration)
        && !(0, typescript_1.isMethodDeclaration)(propDeclaration)) {
        var name = prop.escapedName.toString();
        var msg = "TsType resolver: property '".concat(currentId, ".").concat(name, "' is not a PropertySignature nor MethodSignature");
        (0, logging_1.log)(msg, { lvl: 'error', node: propDeclaration });
        throw new Error(msg);
    }
    var parent = propDeclaration.parent;
    var parentId = parent && !(0, typescript_1.isTypeLiteralNode)(parent)
        ? (0, id_1.getNodeId)(parent, checker, baseDir)
        : undefined;
    var isInherited = currentId && parentId && parentId !== currentId;
    if (isInherited) {
        var type = (0, typescript_1.isPropertySignature)(propDeclaration)
            ? getResolvedArgTypeName(prop, propDeclaration, checker, baseDir)
            : undefined;
        return {
            inheritedFrom: parentId,
            type: type !== null && type !== void 0 ? type : resolveType(propDeclaration, checker, baseDir),
        };
    }
    var optional = (0, ts_utils_1.isOptionalMember)(propDeclaration) || undefined;
    var readonly = (0, ts_utils_1.isReadonlyMember)(propDeclaration) || undefined;
    return {
        type: resolveType(propDeclaration, checker, baseDir),
        optional: optional,
        readonly: readonly,
    };
}
exports.getPropDeclaration = getPropDeclaration;
function getResolvedArgTypeName(prop, propDeclaration, checker, baseDir) {
    var _a;
    var propType = checker.getTypeOfSymbolAtLocation(prop, propDeclaration);
    var hasGenericArg = !!(0, ts_utils_1.getGenericParameterDeclaration)(propDeclaration.type, checker);
    if (!hasGenericArg)
        return undefined;
    var typeDeclaration = (_a = (0, ts_utils_1.getTypeSymbol)(propType)) === null || _a === void 0 ? void 0 : _a.declarations[0];
    return typeDeclaration
        ? resolveType(typeDeclaration, checker, baseDir)
        : getTypeByFlag(propType.flags);
}
function getTypeByFlag(typeFlags) {
    var id;
    if (typeFlags & typescript_1.TypeFlags.Any)
        id = 'any';
    else if (typeFlags & typescript_1.TypeFlags.String)
        id = 'string';
    else if (typeFlags & typescript_1.TypeFlags.Number)
        id = 'number';
    else if (typeFlags & typescript_1.TypeFlags.Boolean)
        id = 'boolean';
    if (!id)
        throw new Error("Unknown type flag: ".concat(typeFlags));
    return {
        kind: data_model_1.TypingKind.Value,
        id: id,
    };
}
function getTypeRefModule(node, name, baseDir) {
    if (!(0, typescript_1.isTypeReferenceNode)(node)
        && !(0, typescript_1.isClassDeclaration)(node)
        && !(0, typescript_1.isInterfaceDeclaration)(node)
        && !(0, typescript_1.isTypeAliasDeclaration)(node)) {
        return undefined;
    }
    for (var _i = 0, _a = node.getSourceFile().statements; _i < _a.length; _i++) {
        var s = _a[_i];
        var module_1 = getModuleByImportDeclaration(node, s, name, baseDir)
            || getModuleByNamedDeclaration(node, s, name, baseDir);
        if (module_1)
            return module_1;
    }
    return undefined;
}
function getModuleByImportDeclaration(node, statement, name, baseDir) {
    if (!(0, typescript_1.isImportDeclaration)(statement))
        return undefined;
    var importName = getImportName(statement, name);
    if (!importName)
        return undefined;
    var currentFolder = (0, path_1.dirname)(node.getSourceFile().fileName);
    var moduleSpecifier = statement.moduleSpecifier.getText().replace(/'/g, '');
    var modulePath = (0, path_1.join)(currentFolder, moduleSpecifier);
    return (0, utils_1.getInnerPath)(modulePath, baseDir);
}
function getModuleByNamedDeclaration(node, statement, name, baseDir) {
    if (!(0, ts_utils_1.isNamedDeclaration)(statement) || statement.name.getText() !== name)
        return undefined;
    return (0, ts_utils_1.getModule)(node, baseDir);
}
function getImportName(importDeclaration, name) {
    var _a, _b, _c;
    if (((_b = (_a = importDeclaration.importClause) === null || _a === void 0 ? void 0 : _a.name) === null || _b === void 0 ? void 0 : _b.escapedText) === name)
        return name;
    if (!((_c = importDeclaration.importClause) === null || _c === void 0 ? void 0 : _c.namedBindings))
        return undefined;
    var importName;
    importDeclaration.importClause.namedBindings.forEachChild(function (nb) {
        var _a;
        if ((0, typescript_1.isImportSpecifier)(nb) && nb.name.escapedText === name) {
            importName = (_a = (nb.propertyName || nb.name)) === null || _a === void 0 ? void 0 : _a.escapedText.toString();
            return true;
        }
        return false;
    });
    return importName;
}
function resolveGenericType(node, checker, baseDir) {
    var _a, _b;
    if (!(0, typescript_1.isTypeReferenceNode)(node) || !((_a = node.typeArguments) === null || _a === void 0 ? void 0 : _a.length))
        return undefined;
    var type = checker.getTypeAtLocation(node);
    var name = (0, id_1.getExportName)(node, checker);
    var args = node.typeArguments.map(function (a) { return resolveType(a, checker, baseDir); });
    var module = (_b = (0, ts_utils_1.getTypeSymbol)(type)) === null || _b === void 0 ? void 0 : _b.declarations.map(function (d) { return (0, ts_utils_1.getModule)(d, baseDir); }).find(function (d) { return !!d; });
    var id = (0, id_1.buildId)(name, module);
    var isGenericArgument = !!(0, ts_utils_1.getGenericParameterDeclaration)(node, checker);
    var kind = isGenericArgument ? data_model_1.TypingKind.GenericArgument : data_model_1.TypingKind.Reference;
    if (needMemberId(node, checker, id, name)) {
        return {
            id: id,
            kind: kind,
            args: args,
            memberId: (0, id_1.getMemberName)(node, name),
        };
    }
    return {
        id: id,
        kind: kind,
        args: args,
    };
}
function resolveReferenceType(node, checker, baseDir) {
    if ((0, typescript_1.isTypeReferenceNode)(node)
        || (0, typescript_1.isClassDeclaration)(node)
        || (0, typescript_1.isInterfaceDeclaration)(node)
        || (0, typescript_1.isTypeParameterDeclaration)(node)
        || (0, typescript_1.isTypeAliasDeclaration)(node)) {
        var name = (0, id_1.getExportName)(node, checker);
        var module_2 = name === 'default'
            ? getModuleForDefaultExport(node, checker, baseDir)
            : getTypeRefModule(node, name, baseDir);
        var id = (0, id_1.buildId)(name, module_2);
        var isGenericArgument = !!(0, ts_utils_1.getGenericParameterDeclaration)(node, checker) || undefined;
        var kind = isGenericArgument ? data_model_1.TypingKind.GenericArgument : data_model_1.TypingKind.Reference;
        if (needMemberId(node, checker, id, name)) {
            return {
                id: id,
                kind: kind,
                memberId: (0, id_1.getNodeName)(node),
            };
        }
        return {
            id: id,
            kind: isGenericArgument ? data_model_1.TypingKind.GenericArgument : data_model_1.TypingKind.Reference,
        };
    }
    return undefined;
}
function isMember(node, checker) {
    if ((0, typescript_1.isTypeAliasDeclaration)(node) || (0, typescript_1.isClassDeclaration)(node) || (0, typescript_1.isInterfaceDeclaration)(node)) {
        var s = checker.getSymbolAtLocation(node.name);
        if ((0, common_resolving_1.hasDocId)(s, checker))
            return true;
    }
    if ((0, typescript_1.isTypeReferenceNode)(node)) {
        return isDocumentedTypeReference(node, checker);
    }
    var type = checker.getTypeAtLocation(node);
    var symbol = (0, ts_utils_1.getTypeSymbol)(type);
    return symbol !== undefined && (0, common_resolving_1.hasDocId)(symbol, checker);
}
exports.isMember = isMember;
function isDocumentedTypeReference(node, checker) {
    var paramTypeSymbol = (0, ts_utils_1.getAliasSymbol)(checker.getSymbolAtLocation(node.typeName), checker);
    return !!paramTypeSymbol && (0, common_resolving_1.hasDocIdTag)(paramTypeSymbol);
}
exports.isDocumentedTypeReference = isDocumentedTypeReference;
function findParamTypeSymbol(node, checker) {
    if ((0, typescript_1.isTypeReferenceNode)(node)) {
        return checker.getSymbolAtLocation(node.typeName);
    }
    return undefined;
}
exports.findParamTypeSymbol = findParamTypeSymbol;
function needMemberId(node, checker, id, name) {
    if (id === name)
        return false;
    return isMember(node, checker);
}
function getModuleForDefaultExport(node, checker, baseDir) {
    var symbol = checker.getTypeAtLocation(node).getSymbol();
    var module = (0, ts_utils_1.getModule)(symbol.declarations[0], baseDir);
    return module;
}
function resolveLiteralType(node) {
    if (!(0, typescript_1.isLiteralTypeNode)(node))
        return undefined;
    var literal = node.literal;
    if ((0, typescript_1.isStringLiteral)(literal))
        return { value: "'".concat(literal.text, "'"), kind: data_model_1.TypingKind.Literal };
    var numberValue = (0, ts_utils_1.getNumberLiteralValue)(node);
    if (numberValue !== undefined) {
        return { value: numberValue, kind: data_model_1.TypingKind.Literal };
    }
    if (node.literal.kind === typescript_1.SyntaxKind.NullKeyword) {
        return { value: null, kind: data_model_1.TypingKind.Literal };
    }
    if (node.literal.kind === typescript_1.SyntaxKind.TrueKeyword) {
        return { value: 'true', kind: data_model_1.TypingKind.Literal };
    }
    if (node.literal.kind === typescript_1.SyntaxKind.FalseKeyword) {
        return { value: 'false', kind: data_model_1.TypingKind.Literal };
    }
    throw new Error('Unknown literal type');
}
function resolveUnionOrIntersectionType(node, checker, baseDir) {
    if (!(0, ts_utils_1.isUnionOrIntersectionTypeNode)(node))
        return undefined;
    return {
        kind: (0, typescript_1.isUnionTypeNode)(node) ? data_model_1.TypingKind.Union : data_model_1.TypingKind.Intersection,
        types: node.types.map(function (t) { return resolveType(t, checker, baseDir); }),
    };
}
function resolveFunctionType(node, checker, baseDir) {
    if (!(0, typescript_1.isFunctionTypeNode)(node)
        && !(0, typescript_1.isFunctionDeclaration)(node)
        && !(0, typescript_1.isMethodSignature)(node)
        && !(0, typescript_1.isMethodDeclaration)(node))
        return undefined;
    var params = {};
    node.parameters.forEach(function (p) {
        var name = p.name.getText();
        params[name] = {
            type: resolveType(p.type, checker, baseDir),
            spread: !!p.dotDotDotToken || undefined,
        };
    });
    var returnType = resolveType(node.type, checker, baseDir);
    return {
        kind: data_model_1.TypingKind.Function,
        params: params,
        returnType: returnType,
    };
}
function resolveArrayType(node, checker, baseDir) {
    if (!(0, typescript_1.isArrayTypeNode)(node))
        return undefined;
    var result = resolveType(node.elementType, checker, baseDir);
    result.array = true;
    return result;
}
function resolvePropertyType(node, checker, baseDir) {
    if (!(0, typescript_1.isPropertySignature)(node)
        && !(0, typescript_1.isPropertyDeclaration)(node)) {
        return undefined;
    }
    return resolveType(node.type, checker, baseDir);
}
function resolveThisType(node, checker, baseDir) {
    var _a, _b, _c;
    if (!(0, typescript_1.isThisTypeNode)(node))
        return undefined;
    var declaration = (_c = (_b = (_a = checker.getTypeAtLocation(node)) === null || _a === void 0 ? void 0 : _a.getSymbol()) === null || _b === void 0 ? void 0 : _b.getDeclarations()) === null || _c === void 0 ? void 0 : _c[0];
    return declaration ? resolveType(declaration, checker, baseDir) : undefined;
}
function resolveImportedType(node, checker, baseDir) {
    if ((0, typescript_1.isImportClause)(node) || (0, typescript_1.isImportSpecifier)(node)) {
        var symbol = checker.getSymbolAtLocation(node.name);
        var aliasedSymbol = checker.getAliasedSymbol(symbol);
        return resolveType(aliasedSymbol.declarations[0], checker, baseDir);
    }
    return undefined;
}
function resolveTypeOperator(node) {
    var value = (0, common_resolving_1.resolveTypeOperator)(node);
    if (!value)
        return undefined;
    return __assign(__assign({}, value), { kind: data_model_1.TypingKind.Value });
}
function resolveType(node, checker, baseDir) {
    if (node === undefined) {
        return undefined;
    }
    var result = resolvePropertyType(node, checker, baseDir)
        || resolveGenericType(node, checker, baseDir)
        || resolveUnionOrIntersectionType(node, checker, baseDir)
        || resolveReferenceType(node, checker, baseDir)
        || resolveLiteralType(node)
        || (0, common_resolving_1.resolveValueType)(node)
        || resolveType((0, common_resolving_1.getParenthesizedType)(node), checker, baseDir)
        || resolveFunctionType(node, checker, baseDir)
        || resolveArrayType(node, checker, baseDir)
        || resolveThisType(node, checker, baseDir)
        || resolveImportedType(node, checker, baseDir)
        || resolveTypeOperator(node)
        || (0, common_resolving_1.resolveNonSupportedType)(node);
    if (!result) {
        (0, logging_1.log)('Cannot resolve type', { lvl: 'error', node: node });
        throw new Error("Cannot resolve type. Node kind ".concat(node.kind));
    }
    return result;
}
exports.resolveType = resolveType;
//# sourceMappingURL=ts-type-resolving.js.map