"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildQualifiedName = exports.getFullyQualifiedName = exports.getExportName = exports.getMemberName = exports.getNodeName = exports.getNodeFilePrefix = exports.isEscapedId = exports.getNodeId = exports.buildId = exports.getIdFromNode = exports.getIdFromSymbol = exports.ID = void 0;
var path_1 = require("path");
var typescript_1 = require("typescript");
var ts_utils_1 = require("./ts-utils");
var utils_1 = require("./utils");
exports.ID = Symbol('id');
function getIdFromSymbol(symbol, baseDir) {
    if (!symbol || symbol.declarations.length === 0) {
        return undefined;
    }
    return getIdFromNode(symbol.declarations[0], baseDir);
}
exports.getIdFromSymbol = getIdFromSymbol;
function getIdFromNode(node, baseDir) {
    var fileName = node === null || node === void 0 ? void 0 : node.getSourceFile().fileName;
    if (!baseDir || !fileName) {
        return undefined;
    }
    var nameWithinFile = getNodeIdParts(node).join('.');
    var filePath = (0, utils_1.removeKnownExtensions)((0, path_1.relative)(baseDir, node.getSourceFile().fileName));
    return "".concat(((0, utils_1.toInvariantPath)(filePath).toLowerCase()), ":").concat(nameWithinFile);
}
exports.getIdFromNode = getIdFromNode;
function getNodeIdParts(node) {
    if (node === undefined) {
        return [];
    }
    var id = getNodeIdPart(node);
    var parentId = getNodeIdParts(node.parent);
    return id ? __spreadArray(__spreadArray([], parentId, true), [id], false) : parentId;
}
var hasOverloads = (0, utils_1.combineGuards)(typescript_1.isMethodDeclaration, typescript_1.isMethodSignature, typescript_1.isFunctionDeclaration, typescript_1.isFunctionDeclaration);
function getNodeIdPart(node) {
    var part = getRawNodeIdPart(node);
    if (hasOverloads(node)) {
        var paramsString = node.parameters.map(function (p) { return p.name.getText(); }).join(',');
        return paramsString
            ? "".concat(part, "(").concat(paramsString, ")")
            : part;
    }
    return part;
}
function getRawNodeIdPart(node) {
    if (!(0, ts_utils_1.isNamedDeclaration)(node) || !node.name) {
        return undefined;
    }
    switch (node.name.kind) {
        case typescript_1.SyntaxKind.Identifier:
        case typescript_1.SyntaxKind.PrivateIdentifier:
        case typescript_1.SyntaxKind.NumericLiteral:
            return node.name.text;
        case typescript_1.SyntaxKind.PropertyAccessExpression:
            return node.name.name.text;
        default:
            return undefined;
    }
}
function buildId(name, module) {
    return module ? "".concat(module, ".").concat(name) : name;
}
exports.buildId = buildId;
function getNodeId(node, checker, baseDir) {
    var name = getExportName(node, checker);
    var module = (0, ts_utils_1.getModule)(node, baseDir);
    return buildId(name, module);
}
exports.getNodeId = getNodeId;
function isEscapedId(value) {
    return /^\{.+\}$/.test(value);
}
exports.isEscapedId = isEscapedId;
function getNodeFilePrefix(node, baseDir) {
    return (0, utils_1.removeKnownExtensions)((0, utils_1.toInvariantPath)((0, path_1.relative)(baseDir, node.getSourceFile().fileName)));
}
exports.getNodeFilePrefix = getNodeFilePrefix;
function getNodeName(node) {
    var targetNode = getTargetNode(node);
    if (!targetNode) {
        throw new Error('Cannot get node name: unknown node type');
    }
    return getName(targetNode);
    function getTargetNode(nd) {
        if ((0, typescript_1.isExpressionWithTypeArguments)(nd)) {
            return nd.expression;
        }
        if ((0, typescript_1.isTypeReferenceNode)(nd)) {
            return nd.typeName;
        }
        if ((0, ts_utils_1.isNamedDeclaration)(nd)) {
            return nd.name;
        }
        return undefined;
    }
    function getName(srcNode) {
        return (srcNode && (0, typescript_1.isIdentifier)(srcNode) && srcNode.text) || undefined;
    }
}
exports.getNodeName = getNodeName;
function getMemberName(node, typeName) {
    if (typeName !== 'default')
        return typeName;
    return getNodeName(node);
}
exports.getMemberName = getMemberName;
function getExportName(node, checker) {
    if (isDefaultExport(node))
        return 'default';
    return getNodeName(node);
    function isDefaultExport(declaration) {
        var defaultExport = declaration.getSourceFile().statements
            .filter(ts_utils_1.isDefaultExportStatement)
            .map(function (e) { return e.expression; })
            .find(typescript_1.isIdentifier);
        var symbol = (0, ts_utils_1.getTypeSymbol)(checker.getTypeAtLocation(declaration));
        return symbol && (symbol.name === 'default' || (defaultExport === null || defaultExport === void 0 ? void 0 : defaultExport.escapedText) === symbol.escapedName);
    }
}
exports.getExportName = getExportName;
function getFullyQualifiedName(member) {
    var currentNode = getNamedDeclaration(member.valueDeclaration || member.declarations[0]);
    var nameParts = [getNodeNamePart(currentNode)];
    currentNode = getNamedDeclaration(currentNode.parent);
    while (currentNode) {
        nameParts.push(getNodeNamePart(currentNode));
        currentNode = getNamedDeclaration(currentNode.parent);
    }
    return nameParts.filter(function (p) { return p; }).reverse().join('.');
    function getNodeNamePart(node) {
        return node.name && (0, typescript_1.isIdentifier)(node.name) ? node.name.text : undefined;
    }
    function getNamedDeclaration(node) {
        var current = node;
        while (current) {
            if ((0, ts_utils_1.isNamedDeclaration)(current)) {
                return current;
            }
            current = current.parent;
        }
        return undefined;
    }
}
exports.getFullyQualifiedName = getFullyQualifiedName;
function buildQualifiedName() {
    var parts = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        parts[_i] = arguments[_i];
    }
    return parts.filter(function (p) { return p; }).join('.');
}
exports.buildQualifiedName = buildQualifiedName;
//# sourceMappingURL=id.js.map