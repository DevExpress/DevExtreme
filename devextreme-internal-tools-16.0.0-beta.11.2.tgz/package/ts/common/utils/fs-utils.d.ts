export declare function walkDirSync(rootDir: string, callback: (f: string) => void): void;
export declare function enumerateFiles(targetDir: string, fileExtensionExpression?: string, exclude?: RegExp): string[];
