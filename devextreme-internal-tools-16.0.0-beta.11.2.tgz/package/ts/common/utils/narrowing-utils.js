"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineGuards = exports.everyOf = void 0;
function everyOf(values, guard) {
    return values.every(guard);
}
exports.everyOf = everyOf;
function combineGuards(guard1, guard2, guard3, guard4) {
    return function (value) { return (!!guard1 && guard1(value))
        || (!!guard2 && guard2(value))
        || (!!guard3 && guard3(value))
        || (!!guard4 && guard4(value)); };
}
exports.combineGuards = combineGuards;
//# sourceMappingURL=narrowing-utils.js.map