"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.revertEscaping = exports.removeKnownExtensions = exports.isEscapedUncPath = exports.toInvariantPath = exports.getInnerPath = exports.resolvePath = void 0;
var path_1 = require("path");
var path_2 = require("path");
Object.defineProperty(exports, "resolvePath", { enumerable: true, get: function () { return path_2.resolve; } });
function getInnerPath(fullPath, baseDir) {
    var result = (0, path_1.relative)(baseDir, fullPath);
    return result.startsWith('..') ? undefined : toInvariantPath(result);
}
exports.getInnerPath = getInnerPath;
function toInvariantPath(path) {
    return path.replace(/\\/g, '/');
}
exports.toInvariantPath = toInvariantPath;
function isEscapedUncPath(path) {
    return path.startsWith('\\'.repeat(4));
}
exports.isEscapedUncPath = isEscapedUncPath;
function removeKnownExtensions(path) {
    return path.replace(/(\.(d|ts|js))*$/, '');
}
exports.removeKnownExtensions = removeKnownExtensions;
function revertEscaping(arg) {
    return arg.replace(/\\\\/g, '\\');
}
exports.revertEscaping = revertEscaping;
//# sourceMappingURL=path-utils.js.map