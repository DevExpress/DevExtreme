"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.not = exports.toSortedRecord = void 0;
function toSortedRecord(obj) {
    return Object.keys(obj).sort()
        .reduce(function (acc, key) { acc[key] = obj[key]; return acc; }, {});
}
exports.toSortedRecord = toSortedRecord;
function not(f) {
    return function (arg) { return !f(arg); };
}
exports.not = not;
//# sourceMappingURL=basic-utils.js.map