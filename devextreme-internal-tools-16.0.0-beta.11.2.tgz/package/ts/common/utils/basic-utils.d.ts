export declare function toSortedRecord<R extends Record<string, unknown>>(obj: R): R;
type Predicate<T> = (arg: T) => boolean;
export declare function not<T>(f: Predicate<T>): Predicate<T>;
export {};
