export declare function mergeArrays<T>(arr: T[][]): T[];
export declare function toArray<T>(iterator: Iterator<T> | undefined): T[] | undefined;
export declare function distinct<T1, T2>(arr: T1[], getKey?: ((item: T1) => T2)): T1[];
export declare function distinctByProperty<T>(array: T[], propertyName: string): T[];
export declare function split<TValue, TGroup extends PropertyKey>(arr: TValue[], spliter: (value: TValue) => TGroup): Record<TGroup, TValue[]>;
export declare function undefinedOrNonEmpty<TArr extends unknown[]>(arr: TArr): TArr;
