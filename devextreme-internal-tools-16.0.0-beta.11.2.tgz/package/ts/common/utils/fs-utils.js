"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.enumerateFiles = exports.walkDirSync = void 0;
var fs_1 = require("fs");
var path_utils_1 = require("./path-utils");
function walkDirSync(rootDir, callback) {
    var remained = [rootDir];
    while (remained.length > 0) {
        var currentDir = remained.shift();
        for (var _i = 0, _a = (0, fs_1.readdirSync)(currentDir); _i < _a.length; _i++) {
            var fileRelPath = _a[_i];
            var fileAbsPath = (0, path_utils_1.resolvePath)(currentDir, fileRelPath);
            if ((0, fs_1.statSync)(fileAbsPath).isDirectory()) {
                remained.push(fileAbsPath);
            }
            else {
                callback(fileAbsPath);
            }
        }
    }
}
exports.walkDirSync = walkDirSync;
function enumerateFiles(targetDir, fileExtensionExpression, exclude) {
    var fileNames = [];
    walkDirSync(targetDir, function (f) { return (!fileExtensionExpression || f.match(new RegExp("".concat(fileExtensionExpression, "$"))))
        && !(exclude === null || exclude === void 0 ? void 0 : exclude.test((0, path_utils_1.toInvariantPath)(f)))
        && fileNames.push(f); });
    return fileNames;
}
exports.enumerateFiles = enumerateFiles;
//# sourceMappingURL=fs-utils.js.map