type Guard<T, TNarrowed extends T> = (value: T) => value is TNarrowed;
export declare function everyOf<T, TNarrowed extends T>(values: T[], guard: Guard<T, TNarrowed>): values is TNarrowed[];
export declare function combineGuards<T, T1 extends T, T2 extends T>(guard1: Guard<T, T1>, guard2: Guard<T, T2>): Guard<T, T1 | T2>;
export declare function combineGuards<T, T1 extends T, T2 extends T, T3 extends T>(guard1: Guard<T, T1>, guard2: Guard<T, T2>, guard3: Guard<T, T3>): Guard<T, T1 | T2 | T3>;
export declare function combineGuards<T, T1 extends T, T2 extends T, T3 extends T, T4 extends T>(guard1: Guard<T, T1>, guard2: Guard<T, T2>, guard3: Guard<T, T3>, guard4: Guard<T, T4>): Guard<T, T1 | T2 | T3 | T4>;
export {};
