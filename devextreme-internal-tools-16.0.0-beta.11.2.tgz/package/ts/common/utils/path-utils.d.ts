export { resolve as resolvePath, } from 'path';
export declare function getInnerPath(fullPath: string, baseDir: string): string | undefined;
export declare function toInvariantPath(path: string): string;
export declare function isEscapedUncPath(path: string): boolean;
export declare function removeKnownExtensions(path: string): string;
export declare function revertEscaping(arg: string): string;
