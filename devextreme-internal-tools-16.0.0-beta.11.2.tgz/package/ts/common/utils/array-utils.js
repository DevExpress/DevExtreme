"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.undefinedOrNonEmpty = exports.split = exports.distinctByProperty = exports.distinct = exports.toArray = exports.mergeArrays = void 0;
function mergeArrays(arr) {
    return Array.prototype.concat.apply([], arr);
}
exports.mergeArrays = mergeArrays;
function toArray(iterator) {
    var _a;
    if (iterator === undefined)
        return undefined;
    var result = [];
    var _b = iterator.next(), value = _b.value, done = _b.done;
    while (!done) {
        result.push(value);
        (_a = iterator.next(), value = _a.value, done = _a.done);
    }
    return result;
}
exports.toArray = toArray;
function distinct(arr, getKey) {
    if (getKey === void 0) { getKey = (function (item) { return item; }); }
    if (arr === undefined) {
        return undefined;
    }
    var set = new Set();
    return arr.filter(function (item) {
        var key = getKey(item);
        if (set.has(key)) {
            return false;
        }
        set.add(key);
        return true;
    });
}
exports.distinct = distinct;
function distinctByProperty(array, propertyName) {
    return distinct(array, function (item) { return item[propertyName]; });
}
exports.distinctByProperty = distinctByProperty;
function split(arr, spliter) {
    return arr === null || arr === void 0 ? void 0 : arr.reduce(function (acc, val) {
        var _a;
        var key = spliter(val);
        ((_a = acc[key]) !== null && _a !== void 0 ? _a : (acc[key] = [])).push(val);
        return acc;
    }, {});
}
exports.split = split;
function undefinedOrNonEmpty(arr) {
    return (arr === null || arr === void 0 ? void 0 : arr.length) ? arr : undefined;
}
exports.undefinedOrNonEmpty = undefinedOrNonEmpty;
//# sourceMappingURL=array-utils.js.map