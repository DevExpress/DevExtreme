"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TAG_OPTIONS = exports.getSymbolType = exports.normalizeDocTags = exports.getSymbolTags = exports.hasTag = exports.buildMemberTags = exports.getSignatureDeclarationTags = exports.normalizeTag = void 0;
var typescript_1 = require("typescript");
var type_resolving_1 = require("./type-resolving");
var ts_utils_1 = require("./ts-utils");
var logging_1 = require("../logging");
var generating_1 = require("./tags/generating");
var merging_1 = require("./tags/merging");
var utils_1 = require("./utils");
var id_1 = require("./id");
function normalizeTag(tag) {
    return { name: tag.tagName.text, value: (0, ts_utils_1.getJSDocTagValue)(tag) };
}
exports.normalizeTag = normalizeTag;
function getSignatureDeclarationTags(checker, declaration, baseDir) {
    var signature = checker.getSignatureFromDeclaration(declaration);
    var tags = getSignatureDocTags(declaration, signature);
    if (!tags.some(isIdTag))
        return [];
    return normalizeDocTags(tags, checker.getTypeAtLocation(declaration).getSymbol(), getSignatureType(signature, checker, baseDir), checker, baseDir);
}
exports.getSignatureDeclarationTags = getSignatureDeclarationTags;
function buildMemberTags(rawDocTags) {
    var tags = {};
    var normalizedTags = rawDocTags
        .filter(function (tag) { return tag.name !== 'name'; })
        .map(function (tag) { return ({ name: convertName(tag.name), value: convertValue(tag.value) }); });
    for (var _i = 0, _a = normalizedTags.sort(function (a, b) { return a.name.localeCompare(b.name); }); _i < _a.length; _i++) {
        var _b = _a[_i], name = _b.name, value = _b.value;
        if (!tags[name])
            tags[name] = [];
        tags[name].push(value);
    }
    if (tags.deprecated) {
        var emptyValueIndex = tags.deprecated.indexOf('');
        if (emptyValueIndex >= 0)
            tags.deprecated.splice(emptyValueIndex, 1);
    }
    if (tags.docid && tags.docid.length > 1)
        throw new Error("Multiple docid values are not allowed: ".concat(JSON.stringify(tags.docid)));
    for (var _c = 0, _d = Object.keys(tags); _c < _d.length; _c++) {
        var name = _d[_c];
        tags[name] = tags[name].sort();
    }
    return (0, utils_1.toSortedRecord)(tags);
}
exports.buildMemberTags = buildMemberTags;
function convertName(name) {
    if (name === 'publicName')
        return 'name';
    return name;
}
function convertValue(value) {
    if (value === undefined)
        return '';
    return value.replace(/`/g, '"');
}
function hasTag(symbol, tagName) {
    return symbol.getJsDocTags().find(function (t) { return t.name === tagName; }) !== undefined;
}
exports.hasTag = hasTag;
function getSymbolTags(checker, symbol, baseDir) {
    var tags = getDocTags(symbol);
    if (!tags.some(isIdTag))
        return [];
    return normalizeDocTags(tags, symbol, getSymbolType(symbol, checker, baseDir), checker, baseDir);
}
exports.getSymbolTags = getSymbolTags;
function isIdTag(tag) {
    return tag.name === 'docid' || tag.name === 'const';
}
function normalizeDocTags(rawTags, symbol, memberType, checker, baseDir) {
    var tags = __spreadArray([], rawTags, true);
    var idTag = tags.find(isIdTag);
    if (idTag.value === undefined) {
        idTag.value = (0, id_1.getFullyQualifiedName)(symbol);
    }
    if (!memberType)
        return tags;
    var generateAcceptValues = !tags.find(function (t) { return t.name === 'type'; });
    return (0, merging_1.mergeTags)(tags, (0, generating_1.generateTags)(memberType, symbol, generateAcceptValues, checker, baseDir), function (message, lvl) {
        if (lvl === void 0) { lvl = 'warn'; }
        (0, logging_1.log)(message, { lvl: lvl, node: symbol.declarations[0] });
    });
}
exports.normalizeDocTags = normalizeDocTags;
function getDocTags(target) {
    return target.getJsDocTags().map(toDocTag);
}
function getSignatureDocTags(node, signature) {
    var ownTags = new Set((0, typescript_1.getJSDocTags)(node).map(function (t) { return t.tagName.text; }));
    return signature.getJsDocTags()
        .filter(function (t) { return ownTags.has(t.name); })
        .map(toDocTag);
}
function toDocTag(tagInfo) {
    return { name: tagInfo.name, value: (0, ts_utils_1.getJSDocTagInfoValue)(tagInfo) };
}
function getSignatureType(signature, checker, baseDir) {
    var declaration = signature === null || signature === void 0 ? void 0 : signature.declaration;
    if (!declaration)
        return undefined;
    return (0, type_resolving_1.resolveNodeType)(declaration, checker, baseDir);
}
function getSymbolType(symbol, checker, baseDir) {
    var ignored = typescript_1.SymbolFlags.Interface | typescript_1.SymbolFlags.Class;
    if (symbol.flags & ignored) {
        return undefined;
    }
    if (symbol.flags & typescript_1.SymbolFlags.Alias) {
        return getSymbolType(checker.getAliasedSymbol(symbol), checker, baseDir);
    }
    var symbolDeclaration = symbol.declarations[0];
    if ((0, ts_utils_1.isNodeWithType)(symbolDeclaration) && symbolDeclaration.type !== undefined) {
        return (0, type_resolving_1.resolveNodeType)(symbolDeclaration.type, checker, baseDir);
    }
    if ((0, ts_utils_1.isNodeWithType)(symbolDeclaration) && symbolDeclaration.type === undefined) {
        var typeNode = checker.typeToTypeNode(checker.getTypeAtLocation(symbolDeclaration), symbolDeclaration, undefined);
        return (0, type_resolving_1.resolveNodeType)(typeNode, checker, baseDir);
    }
    return (0, type_resolving_1.resolveNodeType)(symbolDeclaration, checker, baseDir);
}
exports.getSymbolType = getSymbolType;
exports.TAG_OPTIONS = 'options';
//# sourceMappingURL=tags.js.map