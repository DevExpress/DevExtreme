"use strict";
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isStatementWithModifiers = exports.getJSDocTagInfoValue = exports.getJSDocTagValue = exports.hasFlag = exports.isTypeDeclaration = exports.isTypeLikeDeclaration = exports.isReadonlyMember = exports.isOptionalMember = exports.getNumberLiteralValue = exports.getReferencedNodes = exports.getGenericParameterDeclaration = exports.getModule = exports.createProgram = exports.isDefaultExportStatement = exports.getSymbolDecalartions = exports.getAliasSymbol = exports.getValueType = exports.getNestedSymbols = exports.getTypeSymbol = exports.getTypeSymbols = exports.isOptional = exports.isNamedDeclaration = exports.isNodeWithType = exports.isEnumTypeNode = exports.isPromiseType = exports.BUILT_IN_TYPES = exports.isSubstitutionType = exports.isObjectType = exports.isTypeReference = exports.isUnionOrIntersectionTypeNode = exports.isUnionOrIntersectionType = exports.isStructuredType = void 0;
var path_1 = require("path");
var typescript_1 = require("typescript");
var utils_1 = require("./utils");
function isStructuredType(type) {
    return type.flags === typescript_1.TypeFlags.Object
        || (type.flags & typescript_1.TypeFlags.UnionOrIntersection) !== 0;
}
exports.isStructuredType = isStructuredType;
function isUnionOrIntersectionType(type) {
    return (type.flags & typescript_1.TypeFlags.UnionOrIntersection) !== 0;
}
exports.isUnionOrIntersectionType = isUnionOrIntersectionType;
function isUnionOrIntersectionTypeNode(node) {
    return (0, typescript_1.isUnionTypeNode)(node) || (0, typescript_1.isIntersectionTypeNode)(node);
}
exports.isUnionOrIntersectionTypeNode = isUnionOrIntersectionTypeNode;
function isTypeReference(type) {
    return isObjectType(type) && !!(type.objectFlags & typescript_1.ObjectFlags.Reference);
}
exports.isTypeReference = isTypeReference;
function isObjectType(type) {
    return !!(type.flags & typescript_1.TypeFlags.Object);
}
exports.isObjectType = isObjectType;
function isSubstitutionType(type) {
    return !!(type.flags & typescript_1.TypeFlags.Substitution);
}
exports.isSubstitutionType = isSubstitutionType;
exports.BUILT_IN_TYPES = {
    Promise: 'Promise',
};
function isPromiseType(symbol) {
    return symbol.getEscapedName() === exports.BUILT_IN_TYPES.Promise;
}
exports.isPromiseType = isPromiseType;
function isEnumTypeNode(node) {
    function isEnumNode(typeNode) {
        if (!(0, typescript_1.isUnionTypeNode)(typeNode)) {
            return false;
        }
        var literals = typeNode.types.filter(typescript_1.isLiteralTypeNode).map(function (nd) { return nd.literal; });
        return (literals.length === typeNode.types.length
            && (literals.every(typescript_1.isNumericLiteral) || literals.every(typescript_1.isStringLiteral)));
    }
    return isEnumNode(node) || (isNodeWithType(node) && isEnumNode(node.type));
}
exports.isEnumTypeNode = isEnumTypeNode;
function isNodeWithType(node) {
    switch (node.kind) {
        case typescript_1.SyntaxKind.GetAccessor:
        case typescript_1.SyntaxKind.Parameter:
        case typescript_1.SyntaxKind.PropertyDeclaration:
        case typescript_1.SyntaxKind.PropertySignature:
        case typescript_1.SyntaxKind.TypeAliasDeclaration:
        case typescript_1.SyntaxKind.VariableDeclaration:
            return true;
    }
    return false;
}
exports.isNodeWithType = isNodeWithType;
function isNamedDeclaration(node) {
    switch (node.kind) {
        case typescript_1.SyntaxKind.ExportSpecifier:
        case typescript_1.SyntaxKind.PropertyAssignment:
        case typescript_1.SyntaxKind.PropertySignature:
        case typescript_1.SyntaxKind.PropertyDeclaration:
        case typescript_1.SyntaxKind.MethodSignature:
        case typescript_1.SyntaxKind.MethodDeclaration:
        case typescript_1.SyntaxKind.GetAccessor:
        case typescript_1.SyntaxKind.SetAccessor:
        case typescript_1.SyntaxKind.VariableDeclaration:
        case typescript_1.SyntaxKind.FunctionDeclaration:
        case typescript_1.SyntaxKind.ClassDeclaration:
        case typescript_1.SyntaxKind.InterfaceDeclaration:
        case typescript_1.SyntaxKind.TypeAliasDeclaration:
        case typescript_1.SyntaxKind.TypeParameter:
            return true;
    }
    return false;
}
exports.isNamedDeclaration = isNamedDeclaration;
function isOptional(symbol) {
    return !!(symbol.flags & typescript_1.SymbolFlags.Optional);
}
exports.isOptional = isOptional;
function getTypeSymbols(type) {
    var _a;
    if (isUnionOrIntersectionType(type)) {
        return type.types.map(getTypeSymbols).flat();
    }
    if (isTypeReference(type) && ((_a = type.target.symbol) === null || _a === void 0 ? void 0 : _a.name) === 'Array' && type.typeArguments.length === 1) {
        return getTypeSymbols(type.typeArguments[0]);
    }
    return type.symbol ? [type.symbol] : [];
}
exports.getTypeSymbols = getTypeSymbols;
function getTypeSymbol(type) {
    return type.aliasSymbol || type.symbol;
}
exports.getTypeSymbol = getTypeSymbol;
function getNestedSymbols(type) {
    var _a, _b, _c;
    var nestedSymbols = __spreadArray([], type.getProperties(), true);
    var staticMethods = (_c = (0, utils_1.toArray)((_b = (_a = type.symbol) === null || _a === void 0 ? void 0 : _a.exports) === null || _b === void 0 ? void 0 : _b.values())) === null || _c === void 0 ? void 0 : _c.filter(function (s) { return !(s.flags & typescript_1.SymbolFlags.Prototype); });
    if (staticMethods)
        nestedSymbols.push.apply(nestedSymbols, staticMethods);
    return nestedSymbols;
}
exports.getNestedSymbols = getNestedSymbols;
function getValueType(kind) {
    switch (kind) {
        case typescript_1.SyntaxKind.BooleanKeyword:
            return 'boolean';
        case typescript_1.SyntaxKind.NumberKeyword:
            return 'number';
        case typescript_1.SyntaxKind.StringKeyword:
            return 'string';
        case typescript_1.SyntaxKind.AnyKeyword:
            return 'any';
        case typescript_1.SyntaxKind.ObjectKeyword:
        case typescript_1.SyntaxKind.TypeLiteral:
            return 'object';
        case typescript_1.SyntaxKind.VoidKeyword:
            return 'void';
        case typescript_1.SyntaxKind.NeverKeyword:
            return 'never';
        case typescript_1.SyntaxKind.UnknownKeyword:
            return 'unknown';
        case typescript_1.SyntaxKind.UndefinedKeyword:
            return 'undefined';
    }
    return undefined;
}
exports.getValueType = getValueType;
function getAliasSymbol(symbol, checker) {
    return ((symbol === null || symbol === void 0 ? void 0 : symbol.flags) & typescript_1.SymbolFlags.Alias
        ? checker.getAliasedSymbol(symbol)
        : symbol);
}
exports.getAliasSymbol = getAliasSymbol;
function getSymbolDecalartions(symbol, checker) {
    var _a, _b;
    return (_b = ((symbol === null || symbol === void 0 ? void 0 : symbol.flags) & typescript_1.SymbolFlags.Alias
        ? (_a = checker.getAliasedSymbol(symbol)) === null || _a === void 0 ? void 0 : _a.getDeclarations()
        : symbol === null || symbol === void 0 ? void 0 : symbol.getDeclarations())) !== null && _b !== void 0 ? _b : [];
}
exports.getSymbolDecalartions = getSymbolDecalartions;
function isDefaultExportStatement(statement) {
    return (0, typescript_1.isExportAssignment)(statement) && statement.isExportEquals === undefined;
}
exports.isDefaultExportStatement = isDefaultExportStatement;
function isStringArray(array) {
    return typeof array[0] === 'string';
}
function createProgram(files, compilerOptions) {
    if (isStringArray(files)) {
        return (0, typescript_1.createProgram)(files, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {});
    }
    return createProgramInMemory(files);
}
exports.createProgram = createProgram;
function createProgramInMemory(sourceFiles, compilerOptions) {
    var rootNames = sourceFiles.map(function (file) { return file.fileName; });
    var host = (0, typescript_1.createCompilerHost)({});
    var getSourceFile = host.getSourceFile.bind(host);
    host.getSourceFile = function (fileName) {
        var rest = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            rest[_i - 1] = arguments[_i];
        }
        var file = sourceFiles.find(function (f) { return (0, path_1.normalize)(f.fileName) === (0, path_1.normalize)(fileName); });
        return file !== null && file !== void 0 ? file : getSourceFile.apply(void 0, __spreadArray([fileName], rest, false));
    };
    return (0, typescript_1.createProgram)(rootNames, compilerOptions !== null && compilerOptions !== void 0 ? compilerOptions : {}, host);
}
function getModule(node, baseDir) {
    var modulePath = node.getSourceFile().fileName;
    return getModuleName(modulePath, baseDir);
}
exports.getModule = getModule;
function getModuleName(filePath, baseDir) {
    var _a;
    return (_a = (0, utils_1.getInnerPath)(filePath, baseDir)) === null || _a === void 0 ? void 0 : _a.replace(/(\.d)?\.tsx?$/, '');
}
function getGenericParameterDeclaration(typeNode, checker) {
    var _a;
    var typeSymbol = (_a = getTypeAtLocation(typeNode, checker)) === null || _a === void 0 ? void 0 : _a.getSymbol();
    return typeSymbol === null || typeSymbol === void 0 ? void 0 : typeSymbol.declarations.find(typescript_1.isTypeParameterDeclaration);
}
exports.getGenericParameterDeclaration = getGenericParameterDeclaration;
function getTypeAtLocation(typeNode, checker) {
    var type = checker.getTypeAtLocation(typeNode);
    if (type && isSubstitutionType(type)) {
        return type.baseType;
    }
    return type;
}
function getReferencedNodes(node, checker) {
    var nodes = [];
    findRefs(node);
    return (0, utils_1.distinct)(nodes);
    function findRefs(n) {
        var _a, _b;
        if ((0, typescript_1.isTypeReferenceNode)(n)) {
            if (getGenericParameterDeclaration(n, checker)) {
                return;
            }
            nodes.push(n);
            (_a = n.typeArguments) === null || _a === void 0 ? void 0 : _a.forEach(function (c) { return findRefs(c); });
        }
        else {
            if (((0, typescript_1.isClassDeclaration)(n) || (0, typescript_1.isInterfaceDeclaration)(n)) && ((_b = n.heritageClauses) === null || _b === void 0 ? void 0 : _b.length)) {
                nodes.push.apply(nodes, n.heritageClauses.map(function (hc) { return __spreadArray([], hc.types, true); }).flat());
            }
            n.getChildren().forEach(function (c) { return findRefs(c); });
        }
    }
}
exports.getReferencedNodes = getReferencedNodes;
function getNumberLiteralValue(node) {
    var literal = node.literal;
    if ((0, typescript_1.isNumericLiteral)(literal)) {
        return +node.literal.getText();
    }
    if ((0, typescript_1.isPrefixUnaryExpression)(literal)) {
        var text = literal.operand.getText();
        if (literal.operator === typescript_1.SyntaxKind.MinusToken) {
            return -text;
        }
    }
    return undefined;
}
exports.getNumberLiteralValue = getNumberLiteralValue;
function isObjectMemberDeclaration(declaration) {
    return (0, typescript_1.isPropertyDeclaration)(declaration)
        || (0, typescript_1.isPropertySignature)(declaration)
        || (0, typescript_1.isMethodDeclaration)(declaration)
        || (0, typescript_1.isMethodSignature)(declaration);
}
function isOptionalMember(declaration) {
    return isObjectMemberDeclaration(declaration) && !!declaration.questionToken;
}
exports.isOptionalMember = isOptionalMember;
function isReadonlyMember(declaration) {
    var _a;
    return (isObjectMemberDeclaration(declaration))
        && !!((_a = declaration.modifiers) === null || _a === void 0 ? void 0 : _a.some(function (m) { return m.kind === typescript_1.SyntaxKind.ReadonlyKeyword; }));
}
exports.isReadonlyMember = isReadonlyMember;
function isTypeLikeDeclaration(node) {
    return node !== undefined && (isTypeDeclaration(node)
        || (0, typescript_1.isTypeReferenceNode)(node));
}
exports.isTypeLikeDeclaration = isTypeLikeDeclaration;
function isTypeDeclaration(node) {
    return node !== undefined && ((0, typescript_1.isTypeAliasDeclaration)(node)
        || (0, typescript_1.isInterfaceDeclaration)(node)
        || (0, typescript_1.isClassDeclaration)(node));
}
exports.isTypeDeclaration = isTypeDeclaration;
function hasFlag(symbol, flag) {
    return !!(symbol.flags & flag);
}
exports.hasFlag = hasFlag;
function getJSDocTagValue(tag) {
    if ((tag === null || tag === void 0 ? void 0 : tag.comment) === undefined) {
        return undefined;
    }
    return typeof (tag.comment) === 'string'
        ? tag.comment
        : tag.comment.map(function (p) { return p.text; }).join('');
}
exports.getJSDocTagValue = getJSDocTagValue;
function getJSDocTagInfoValue(_a) {
    var _b;
    var parts = _a.text;
    return (_b = parts === null || parts === void 0 ? void 0 : parts.map(function (p) { return p.text; })) === null || _b === void 0 ? void 0 : _b.join('');
}
exports.getJSDocTagInfoValue = getJSDocTagInfoValue;
function isStatementWithModifiers(statement) {
    return (0, typescript_1.isClassDeclaration)(statement) || (0, typescript_1.isEnumDeclaration)(statement)
        || (0, typescript_1.isExportAssignment)(statement) || (0, typescript_1.isExportDeclaration)(statement)
        || (0, typescript_1.isFunctionDeclaration)(statement) || (0, typescript_1.isImportDeclaration)(statement)
        || (0, typescript_1.isImportEqualsDeclaration)(statement) || (0, typescript_1.isInterfaceDeclaration)(statement)
        || (0, typescript_1.isModuleDeclaration)(statement) || (0, typescript_1.isTypeAliasDeclaration)(statement)
        || (0, typescript_1.isVariableStatement)(statement);
}
exports.isStatementWithModifiers = isStatementWithModifiers;
//# sourceMappingURL=ts-utils.js.map