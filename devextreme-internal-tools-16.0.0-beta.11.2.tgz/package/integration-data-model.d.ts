export interface IModel {
    commonReexports: Record<string, string[]>;
    customTypes: ICustomType[];
    meta: IMeta;
    widgets: IWidget[];
}
export interface IMeta {
    scriptsRevision: string;
    toolsVersion: string;
}
export interface IWidget {
    complexOptions: IComplexProp[];
    exportPath: string;
    hasTranscludedContent: boolean;
    isEditor: boolean;
    isExtension: boolean;
    name: string;
    nesteds: IComponentRef[];
    options: IProp[];
    optionsTypeParams: string[];
    reexports?: string[];
    templates: string[];
}
export interface IProp {
    firedEvents: string[];
    isDeprecated: boolean;
    isSubscribable: boolean;
    name: string;
    props: IProp[];
    types: ITypeDescr[];
}
export interface IComplexProp {
    isCollectionItem: boolean;
    name: string;
    nesteds: IComponentRef[];
    optionName: string;
    owners: string[];
    predefinedProps: Record<string, any>;
    props: IProp[];
    templates: string[];
}
export interface IComponentRef {
    componentName: string;
    isCollectionItem: boolean;
    optionName: string;
}
export interface ICustomType {
    module: string;
    name: string;
    props: IProp[];
    templates: string[];
    types: ITypeDescr[];
}
export interface ITypeDescr {
    acceptableValues: string[];
    acceptableValueType: string;
    importPath: string;
    isCustomType: boolean;
    isImportedType: boolean;
    type: string;
    typeParams: string[];
}
export interface IArrayDescr extends ITypeDescr {
    itemTypes: ITypeDescr[];
}
export interface IFunctionDescr extends ITypeDescr {
    params: {
        name: string;
        types: ITypeDescr[];
    }[];
    returnValueTypes: ITypeDescr[];
}
export interface IObjectDescr extends ITypeDescr {
    fields: {
        name: string;
        types: ITypeDescr[];
    }[];
}
